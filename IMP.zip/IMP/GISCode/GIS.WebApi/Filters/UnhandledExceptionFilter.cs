﻿using System.Web;
using System.Net;
using System.Net.Http;
using System.Web.Http.Filters;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.Common;

namespace Capgemini.GroupProduction.GIS.WebApi.Filters
{
    /// <summary>
    /// Global UnhandledExceptionFilter.
    /// </summary>
    public class UnhandledExceptionFilter : ExceptionFilterAttribute
    {
        /// <summary>
        /// Logs exception to Elmah and send custom error response to client.
        /// </summary>
        /// <param name="context"></param>
        public override void OnException(HttpActionExecutedContext context)
        {
            context.Response = context.Request.CreateResponse(HttpStatusCode.OK,
                new CustomMessage() { MessageType = (int)MessageType.Unhandled, 
                    Message ="Error while processing request"});

            string messageHeader =  MessageType.Unhandled.ToString();
            context.Response.Headers.Add(messageHeader, messageHeader);

            Elmah.ErrorLog.GetDefault(HttpContext.Current).Log(new Elmah.Error(context.Exception));
        }
    }

}
