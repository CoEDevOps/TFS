﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Web;

namespace Capgemini.GroupProduction.GIS.WebApi.Helpers
{
    /// <summary>
    /// Service Now Helper Api
    /// </summary>
    public class ServiceNowApiHelper
    {
        /// <summary>
        /// Get Data from SNOW Api
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="url"></param>
        /// <returns></returns>
        public static T GetDataFromApi<T>(string url, string snowUrl, string uname, string pwd) where T : class
        {
            var baseApiUrl = snowUrl;

            HttpClientHandler restHandler = new HttpClientHandler { Credentials = new NetworkCredential(uname, pwd) };
            HttpClient client = new HttpClient(restHandler);
            client.Timeout = System.TimeSpan.FromMilliseconds(1800000);
            baseApiUrl += url;
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var response = client.GetAsync(
                baseApiUrl
                );
            var responseMessage = response.Result;
            return responseMessage.Content.ReadAsAsync<T>().Result;
        }

        /// <summary>
        /// Push Data to SNOW Api
        /// </summary>
        /// <typeparam name="PType"></typeparam>
        /// <typeparam name="T"></typeparam>
        /// <param name="url"></param>
        /// <param name="postData"></param>
        /// <returns></returns>
        public static T PostDataToApi<PType, T>(string url, PType postData, string snowUrl, string uname, string pwd)
        {
            var baseApiUrl = snowUrl;

            HttpClientHandler restHandler = new HttpClientHandler { Credentials = new NetworkCredential(uname, pwd) };
            HttpClient client = new HttpClient(restHandler);

            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.Timeout = System.TimeSpan.FromMilliseconds(1800000);
            baseApiUrl += url;

            JsonMediaTypeFormatter jsonFormat = new JsonMediaTypeFormatter();
            jsonFormat.SerializerSettings.NullValueHandling = Newtonsoft.Json.NullValueHandling.Ignore;
            jsonFormat.SerializerSettings.Formatting = Formatting.None;

            var responseMessage = client.PostAsync<PType>(
                 baseApiUrl, postData, jsonFormat
                 ).Result;

            return responseMessage.Content.ReadAsAsync<T>().Result;
        }

        /// <summary>
        /// Delete Record
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="url"></param>
        /// <returns></returns>
        public static T DeleteDataFromApi<T>(string url, string snowUrl, string uname, string pwd) where T : class
        {
            var baseApiUrl = snowUrl;
            HttpClientHandler restHandler = new HttpClientHandler { Credentials = new NetworkCredential(uname, pwd) };
            HttpClient client = new HttpClient(restHandler);
            client.Timeout = System.TimeSpan.FromMilliseconds(1800000);
            baseApiUrl += url;
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var response = client.DeleteAsync(
                baseApiUrl
                );
            var responseMessage = response.Result;
            return responseMessage.Content.ReadAsAsync<T>().Result;
        }
    }
}