﻿using Capgemini.GroupProduction.GIS.Common;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.Repository;
using Capgemini.GroupProduction.GIS.Service;
using Capgemini.GroupProduction.GIS.ServiceInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Capgemini.GroupProduction.Base.WebApi
{
    public class MasterData : IMasterData
    {
        public IEnumerable<RoleAccess> GetRoleAccess(long userID)
        {
            IUserManagmentBO m_userService = new UserManagmentBO(new UserManagementDO());
             return m_userService.GetRoleAccessAll(userID);
        }
    }
}