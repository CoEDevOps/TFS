﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.ServiceInterface;
using Capgemini.GroupProduction.GIS.Service;
using Capgemini.GroupProduction.GIS.Repository;
using Capgemini.GroupProduction.GIS.WebApi.ActionFilters;
using System.Text.RegularExpressions;
using Capgemini.GroupProduction.GIS.ValueObject;
using System;
using Capgemini.GroupProduction.GIS.Common;
using System.Collections;
using System.Web.Http;
using System.Web;
using Capgemini.GroupProduction.GIS.Service.Common;
using Newtonsoft.Json;
using System.IO;
using System.Configuration;



namespace Capgemini.GroupProduction.GIS.WebApi.Controllers.WorkorderManagement
{
    [AuthorizationRequired]
    public class WorkorderManagementController : ApiController
    {
        public readonly IWorkorderManagementBO m_workorderMgmtService;
        public readonly ICommonBO m_commonService;
        public readonly IEmailManagementBO m_emailMgmtService;
        public readonly IUserManagmentBO m_userMgmtService;
        
        /// <summary>
        /// Constructor
        /// </summary>
        public WorkorderManagementController()
        {
            m_workorderMgmtService = new WorkorderManagementBO(new WorkorderManagementDO(), new CommonDO());
            m_commonService = new CommonBO(new CommonDO());
            m_emailMgmtService = new EmailManagementBO(new EmailManagementDO());
            m_userMgmtService = new UserManagmentBO(new UserManagementDO());
        }
        
        /// <summary>
        /// Search Engagement Codes
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ActionName("searchcode")]
        [HttpGet]
        public HttpResponseMessage SearchEngagementCode(string id)
        {
            var regex = @"^[A-Za-z0-9_]*$";
            var match = Regex.Match(id, regex, RegexOptions.IgnoreCase);
            if (match.Success == true)
            {
                IEnumerable<EngagementCodeVO> engmtList = m_workorderMgmtService.SearchEngagementCodes(id);
                if (engmtList.Any())
                    return Request.CreateResponse(HttpStatusCode.OK, engmtList);
                return Request.CreateResponse(HttpStatusCode.OK, m_commonService.GetMessage("SearchEnagementCode"));
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid Search Keyword");
            }
        }

        /// <summary>
        /// Get Engagement Details
        /// </summary>
        /// <param name="id"></param>
        /// <param name="sender"></param>
        /// <returns></returns>
        [HttpGet]
        [ActionName("getworkorderdetails")]
        public HttpResponseMessage GetWorkOrderDetails(string id, Int64 sender)
        {
            WorkOrderDetailsVO woDetails = m_workorderMgmtService.GetWorkOrderDetails(id, sender);
            if (woDetails != null)
                return Request.CreateResponse(HttpStatusCode.OK, woDetails);
            return Request.CreateErrorResponse(HttpStatusCode.OK, woDetails.Message);
        }

        /// <summary>
        /// Get Service Master List
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// 
        [HttpGet]
        [ActionName("getservicedetails")]
        public HttpResponseMessage GetServiceDetails(int id)
        {
            IEnumerable<ServiceMasterVO> serviceList = m_workorderMgmtService.GetServiceList(id);
            if (serviceList.Any())
                return Request.CreateResponse(HttpStatusCode.OK, serviceList);
            return Request.CreateResponse(HttpStatusCode.OK, m_commonService.GetMessage("ServiceDetails"));
        }
        
        /// <summary>
        /// Get Service Master List
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// 
        [HttpGet]
        [ActionName("getworkorderallservicemaster")]
        public HttpResponseMessage GetWorkorderAllServiceMaster(string id)
        {
            WorkOrder workOrder = m_workorderMgmtService.GetWorkOrderAllServiceMaster(id);
            return Request.CreateResponse(HttpStatusCode.OK, workOrder);
        }

        /// </summary>
        /// <param name="woDetails"></param>
        /// <returns></returns>
        [HttpGet]
        [ActionName("getworkorder")]
        public HttpResponseMessage GetWorkOrder(Int64 id)
        {
            CustomMessage errorMessage = new CustomMessage();

            WorkOrderVO workOrderVo = m_workorderMgmtService.GetSavedWorkOrderService(id);
   
            return Request.CreateResponse(HttpStatusCode.OK, workOrderVo);

        }

        /// <summary>
        /// Write WorkOrder and Service Related information in Json file 
        /// </summary>
        [HttpPost]
        [ActionName("writeinputjsondata")]
        public void WriteInputJsonData(WorkOrderServiceDetails WOServiceDtl)
        {
            WorkOrderVO wo = m_workorderMgmtService.GetSavedWorkOrderService(WOServiceDtl.WorkOrder.WorkOrderId.Value);
            WorkOrderServiceMasterVO WOObj = new WorkOrderServiceMasterVO();
            Log Jsonlog = new Log();

            try
            {
                User User = m_userMgmtService.GetUserName(wo.WorkOrderService[0].CreatedBy);
                WOObj.workordernumber = wo.WorkOrder.WorkOrderNumber;
                WOObj.engagementcode = wo.WorkOrder.EngagementCode;
                WOObj.engagementname = wo.WorkOrder.EngagementName;
                WOObj.projectmanager = wo.WorkOrder.ProjectManager;
                WOObj.customername = wo.WorkOrder.CustomerName;

                if (wo.WorkOrder.StartDate.HasValue)
                {
                    string StartDateStr = wo.WorkOrder.StartDate.Value.ToString("MM/dd/yyyy");
                    WOObj.startdate = StartDateStr;
                }

                if (wo.WorkOrder.EndDate.HasValue)
                {
                    string EndDateStr = wo.WorkOrder.EndDate.Value.ToString("MM/dd/yyyy");
                    WOObj.enddate = EndDateStr;
                }

                WOObj.createdby = User.UserName;
                WOObj.username = User.Name;

                if (wo.WorkOrderService[0].CreatedDate.HasValue)
                {
                    string CreatedDateStr = wo.WorkOrderService[0].CreatedDate.Value.ToString("MM/dd/yyyy");
                    WOObj.createddate = CreatedDateStr;
                }
               
                WOObj.servicename = wo.WorkOrderService[0].ServiceName;
                WOObj.remarks = wo.WorkOrderService[0].Remarks;

                if (!string.IsNullOrEmpty(wo.WorkOrderService[0].FileName))
                {
                    string filepath = ConfigurationManager.AppSettings["FileUploadPath"].ToString() + "\\" + wo.WorkOrderService[0].FileName;
                    WOObj.file = "\\" + Path.GetFullPath(filepath).Replace("\\\\", "\\");
                }
                else
                {
                    WOObj.file = "";
                }

                string json = JsonConvert.SerializeObject(WOObj, Formatting.Indented);

                string JsonFilePath = wo.WorkOrderService[0].InputFilePath + "\\" + wo.WorkOrder.WorkOrderNumber + "_IN.json";

                File.WriteAllText(JsonFilePath, json);

                //Write Json Log
                Jsonlog.WriteErrorLog(json);

                //Send out a mail to factory manager        
                m_emailMgmtService.NotifyFMNewWorkOrder(wo.WorkOrder.WorkOrderId.Value);
                
                //Send out an acknowledgement mail to uer
                m_emailMgmtService.NotifyUserNewWorkOrder(wo.WorkOrder.WorkOrderId.Value);
            }
            catch (Exception ex)
            {
                Elmah.ErrorLog.GetDefault(HttpContext.Current).Log(new Elmah.Error(ex));
            }
        }

        /// <summary>
        /// Get Service Master List
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        [ActionName("getworkorderselservice")]
        public HttpResponseMessage GetWorkorderWithSelectedService(WorkOrder workOrder)
        {
            WorkOrderServiceDetails workOrderVOService = m_workorderMgmtService.GetWorkOrderWithSelectedService(workOrder);

            return Request.CreateResponse(HttpStatusCode.OK, workOrderVOService);
        }

        /// <summary>
        /// Create Work Order - Draft
        /// </summary>
        /// <param name="woDetails"></param>
        /// <returns></returns>
        [HttpPost]
        [ActionName("createworkorder")]
        public HttpResponseMessage CreateWorkorder(WorkOrder woDetails)
        {
            if (woDetails != null)
            {
                if (HttpContext.Current.Items["UserId"] != null)
                {
                    woDetails.UserId = Convert.ToInt64(HttpContext.Current.Items["UserId"]);
                    if (!string.IsNullOrEmpty(woDetails.EngagementCode) && woDetails.StartDate != null && woDetails.EndDate != null)
                    {
                        Int64 newWO = m_workorderMgmtService.AddWorkOrderDetails(woDetails);
                        if (newWO == 0)
                        {
                            return Request.CreateResponse(HttpStatusCode.OK, m_commonService.GetMessage("WorkOrderAddFailure"));
                        }
                        return Request.CreateResponse(HttpStatusCode.OK, newWO);
                    }
                }
            }

            //Get the custom message from database.           
            CustomMessage customMessage = m_commonService.GetMessage("WorkOrderDetails");

            return Request.CreateResponse(HttpStatusCode.OK, customMessage);
        }
        
        /// </summary>
        /// <param name="woDetails"></param>
        /// <returns></returns>
        [HttpPost]
        [ActionName("createworkorderservice")]
        public HttpResponseMessage CreateWorkOrderService(IEnumerable<WorkOrderService> woDetails)
        {
            CustomMessage errorMessage = new CustomMessage();

            //Add Services Selected
            if (woDetails.Count() > 0)
            {
                WorkOrderServiceDetails workOrderVoService = m_workorderMgmtService.AddWorkOrderServiceDetails(woDetails);

                return Request.CreateResponse(HttpStatusCode.OK, workOrderVoService);

            }

            CustomMessage customMessage = m_commonService.GetMessage("ServiceSelection");
            errorMessage.MessageType = (int)MessageType.Success;
            errorMessage.Message = customMessage.Message;
            return Request.CreateResponse(HttpStatusCode.OK, errorMessage);
        }

        /// <summary>
        /// Get My Work Orders
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ActionName("getmyworkorders")]
        public HttpResponseMessage GetMyWorkOrders()
        {
            IEnumerable<WorkOrder> workOrderList = m_workorderMgmtService.GetMyWorkOrders(Convert.ToString(HttpContext.Current.Items["UserId"]));
            return Request.CreateResponse(HttpStatusCode.OK, workOrderList);
        }

        /// <summary>
        /// Get My Work Orders
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ActionName("getqueueworkorders")]
        public HttpResponseMessage GetQueueWorkOrders()
        {
            IEnumerable<WorkOrder> workOrderList = m_workorderMgmtService.GetQueueWorkOrders(Convert.ToString(HttpContext.Current.Items["UserId"]));
            return Request.CreateResponse(HttpStatusCode.OK, workOrderList);
        }
                
        /// <summary>
        /// Update the work order service status with the operation success or failure message.
        /// </summary>
        /// <param name="serviceVO">service object.</param>
        /// <returns>Work order service response.</returns>
        [HttpPost]
        [ActionName("updateworkorderservicestatus")]
        public HttpResponseMessage UpdatServiceStatus(WorkOrderServiceVO serviceVO)
        {
            WorkOrderServiceVO workOrderServiceVO = m_workorderMgmtService.UpdateWorkOrderServiceStatus(serviceVO);

            if (workOrderServiceVO.WorkOrderServiceId > 0)
            {
                workOrderServiceVO.Message = m_commonService.GetMessage("ServiceStatusUpdateSuccess");

                //Send mail to user
                EmailStatus woStatus = new EmailStatus();
                woStatus.WorkOrderServiceId = workOrderServiceVO.WorkOrderServiceId;
                woStatus.WorkOrderId = workOrderServiceVO.WorkOrderID;
                woStatus.Status = workOrderServiceVO.Status;
                m_emailMgmtService.NotifyUserStatusChange(woStatus);
            }
            else
            {
                workOrderServiceVO.Message = m_commonService.GetMessage("ServiceStatusUpdateFailure");
            }
            return Request.CreateResponse(HttpStatusCode.OK, workOrderServiceVO.Message);
        }
        
        /// <summary>
        ///  Update the work order status with the operation success or failure message.
        /// </summary>
        /// <param name="workOrderVO">work order object.</param>
        /// <returns>Work order service response.</returns>
        [HttpPost]
        [ActionName("updateworkorderstatus")]
        public HttpResponseMessage UpdatWorkOrderStatus(WorkOrderDetailsVO workOrderVO)
        {
            WorkOrderDetailsVO workOrderDetailsVO = m_workorderMgmtService.UpdateWorkOrderStatus(workOrderVO);

            CustomMessage customMessage;
            if (workOrderDetailsVO.WorkOrderId > 0)
            {
                customMessage = m_commonService.GetMessage("WorkOrderStatusSuccess");

                //Send mail to user
                EmailStatus woStatus = new EmailStatus();
                woStatus.WorkOrderId = workOrderDetailsVO.WorkOrderId;
                woStatus.Status = workOrderDetailsVO.Status;
                m_emailMgmtService.NotifyUserStatusChange(woStatus);
            }
            else
            {
                customMessage = m_commonService.GetMessage("WorkOrderStatusFailure");
            }
            return Request.CreateResponse(HttpStatusCode.OK, customMessage);
        }
        
    }
}
