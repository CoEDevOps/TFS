﻿using System.Net;
using System.Net.Http;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.ServiceInterface;
using Capgemini.GroupProduction.GIS.Service;
using Capgemini.GroupProduction.GIS.Repository;
using Capgemini.GroupProduction.GIS.WebApi.ActionFilters;
using Capgemini.GroupProduction.GIS.ValueObject;
using System;
using Capgemini.GroupProduction.GIS.Common;
using System.Web.Http;

namespace Capgemini.GroupProduction.GIS.WebApi.Controllers.EmailManagement
{
    [AuthorizationRequired]
    public class EmailManagementController : ApiController
    {
        public readonly IEmailManagementBO m_emailMgmtService;

        /// <summary>
        /// Constructor
        /// </summary>
        public EmailManagementController()
        {
            m_emailMgmtService = new EmailManagementBO(new EmailManagementDO());            
        }

        /// <summary>
        /// Notify Factory Manager on New Work Order
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ActionName("notifyFMNewWorkOrder")]
        [HttpGet]
        public HttpResponseMessage NotifyFMNewWorkOrder(Int64 id)
        {
            string result = m_emailMgmtService.NotifyFMNewWorkOrder(id);
            return Request.CreateResponse(HttpStatusCode.OK, result);            
        }

        /// <summary>
        /// Acknowledgement on new work order
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ActionName("notifyUserNewWorkOrder")]
        [HttpGet]
        public HttpResponseMessage NotifyUserNewWorkOrder(Int64 id)
        {
            string result  = m_emailMgmtService.NotifyUserNewWorkOrder(id);
            return Request.CreateResponse(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Notify on Work Order status change
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ActionName("notifyUserWOStatusChange")]
        [HttpGet]
        public HttpResponseMessage NotifyUserStatusChange(EmailStatus updatedStatus)
        {
            m_emailMgmtService.NotifyUserStatusChange(updatedStatus);
            return Request.CreateResponse(HttpStatusCode.OK, true);
        }        
    }
}
