﻿using System.Net;
using System.Net.Http;
using Capgemini.GroupProduction.GIS.ServiceInterface;
using Capgemini.GroupProduction.GIS.Service;
using Capgemini.GroupProduction.GIS.Repository;
using Capgemini.GroupProduction.GIS.WebApi.ActionFilters;
using System;
using System.Web.Http;
using Capgemini.GroupProduction.GIS.ServiceNow.ValueObject;
using System.IO;
using System.Web;
using Capgemini.GroupProduction.GIS.ServiceNow.Entity;


namespace Capgemini.GroupProduction.GIS.WebApi.Controllers.ServiceNowManagement
{
    /// <summary>
    /// Service Now Management Api Controller
    /// </summary>
    /// 
    [AuthorizationRequired]
    public class ServiceNowManagementController : ApiController
    {
        public readonly IServiceNowManagementBO m_servicenowMgmtService;
        public ServiceNowManagementController()
        {
            m_servicenowMgmtService = new ServiceNowManagementBO(new ServiceNowManagementDO());
        }
               

        /// <summary>
        /// Generate Work Order File to be pused to service now
        /// </summary>
        /// <param name="woDetails"></param>
        /// <returns></returns>        
        [HttpPost]
        [ActionName("generateWOFileforSnow")]
        public HttpResponseMessage GenerateWorkOrderFileForSnow(ServiceWorkOrderVO woDetails)
        {
            try
            {
                string woFilePath = woDetails.SnowFilePath + woDetails.WorkOrderNumber + ".txt";
                using (StreamWriter sw = File.AppendText(woFilePath))
                {
                    sw.WriteLine(woDetails.WorkOrderId + "|" + woDetails.WorkOrderNumber);
                    return Request.CreateResponse(HttpStatusCode.OK, "success");
                }
            }
            catch (Exception ex)
            {
                //Log Error
                Elmah.ErrorLog.GetDefault(HttpContext.Current).Log(new Elmah.Error(ex));

                //reset Work Order Number Flags if file generation fails
                m_servicenowMgmtService.ResetWorkOrderReferenceFlags(woDetails.WorkOrderId);
                return Request.CreateResponse(HttpStatusCode.OK, "failure");
            }
        }

        /// <summary>
        /// Get Snow Instance Details
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [ActionName("getServiceNowInstance")]        
        public HttpResponseMessage GetServiceNowInstanceDetails(Int64 id)
        {
            ServiceNowInstance objSnowInstance = m_servicenowMgmtService.GetServiceNowInstanceDetails(id);
            return Request.CreateResponse(HttpStatusCode.OK, objSnowInstance);
        }
    }
}
