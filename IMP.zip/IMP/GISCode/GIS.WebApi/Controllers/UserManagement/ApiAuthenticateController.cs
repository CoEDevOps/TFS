﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using AttributeRouting.Web.Http;
using System.Net.Http.Headers;
using System.Collections.Generic;
using Capgemini.GroupProduction.VTF.Service;
using Capgemini.GroupProduction.VTF.ServiceInterface;
using Capgemini.GroupProduction.VTF.Repository;
using Capgemini.GroupProduction.VTF.WebApi.Filters;
using Capgemini.GroupProduction.VTF.Entity;
using Capgemini.GroupProduction.VTF.WebApi.ActionFilters;
using System.Web;

namespace Capgemini.GroupProduction.VTF.WebApi.Controllers
{
    [AuthenticationRequiredAttribute]
    public class ApiAuthenticateController : ApiController
    {
        #region Private variable.


        private readonly IUserManagmentBO m_userService;

        #endregion

        #region Public Constructor

        /// <summary>
        /// Public constructor to initialize product service instance
        /// </summary>
        public ApiAuthenticateController(UserManagmentBO userService)
        {
            m_userService = userService;
        }

        /// <summary>
        /// Public constructor to initialize product service instance
        /// </summary>
        public ApiAuthenticateController()
        {
            m_userService = new UserManagmentBO(new UserManagementDO());
        }

        #endregion

        
        /// <summary>
        /// Authenticate request
        /// </summary>
        /// <returns></returns>     
        [HttpPost]
        [ActionName("Authenticate")]
        public HttpResponseMessage Authenticate()
        {
            var user = HttpContext.Current.Items["CurrentUser"];
            if (user != null)
            {
                return Request.CreateResponse(HttpStatusCode.OK, (User)user);
            }
            return new HttpResponseMessage(HttpStatusCode.Unauthorized); ;

        }

        /// <summary>
        /// Returns auth token for the validated user.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private HttpResponseMessage GetAuthToken()
        {
            var token = m_userService.GenerateSession();
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, "Authorized");
            List<CookieHeaderValue> lstcookie = new List<CookieHeaderValue>();
            CookieHeaderValue sessionCookie = new CookieHeaderValue("ASP.NET_SessionId", token.SessionID);
            sessionCookie.Expires = token.Expires;
            sessionCookie.HttpOnly = true;
            lstcookie.Add(sessionCookie);
            response.Headers.AddCookies(lstcookie);
            return response;
        }
    }
}
