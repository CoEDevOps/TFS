﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.ServiceInterface;
using Capgemini.GroupProduction.GIS.Service;
using Capgemini.GroupProduction.GIS.Repository;
using Capgemini.GroupProduction.GIS.WebApi.ActionFilters;
using System.Text.RegularExpressions;
using Capgemini.GroupProduction.GIS.ValueObject;
using System;
using Capgemini.GroupProduction.GIS.Common;
using System.Collections;
using System.Web.Http;
using System.Web;
using Capgemini.GroupProduction.GIS.Service.Common;
using Capgemini.GroupProduction.GIS.Report.ValueObject;

namespace Capgemini.GroupProduction.GIS.WebApi.Controllers.ReportManagement
{
    public class ReportManagementController : ApiController
    {
        public readonly IReportManagementBO _reportMgmtService;
        public ReportManagementController()
        {
            _reportMgmtService = new ReportManagementBO(new ReportManagementDO());
        }

        [HttpGet]
        [ActionName("GetPieChart")]
        public HttpResponseMessage GetPieChart()
        {
            try
            {
                IEnumerable<PieChartVO> piechart = _reportMgmtService.GetPieChart().ToList();
                return Request.CreateResponse(HttpStatusCode.OK, piechart);
            }
            catch (Exception ex)
            {
                //Log Error
                Elmah.ErrorLog.GetDefault(HttpContext.Current).Log(new Elmah.Error(ex));
                return Request.CreateResponse(HttpStatusCode.OK, "failure");
            }
        }

        [HttpGet]
        [ActionName("GetBarChart")]
        public HttpResponseMessage GetBarChart()
        {
            try
            {
                IEnumerable<BarChartVO> barchart = _reportMgmtService.GetBarChart().ToList();
                return Request.CreateResponse(HttpStatusCode.OK, barchart);
            }
            catch (Exception ex)
            {
                //Log Error
                Elmah.ErrorLog.GetDefault(HttpContext.Current).Log(new Elmah.Error(ex));
                return Request.CreateResponse(HttpStatusCode.OK, "failure");
            }
        }
    }
}