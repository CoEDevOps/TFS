﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Collections.Generic;
using Capgemini.GroupProduction.GIS.Service;
using Capgemini.GroupProduction.GIS.ServiceInterface;
using Capgemini.GroupProduction.GIS.Repository;
using Capgemini.GroupProduction.GIS.Entity;
using System.Linq;
using System;
using Capgemini.GroupProduction.GIS.WebApi.ActionFilters;
using Capgemini.GroupProduction.GIS.Entity.Test;
using System.Web.Http.ModelBinding;
using Capgemini.GroupProduction.GIS.WebApi.Helpers;

namespace Capgemini.GroupProduction.GIS.WebApi.Controllers.Test
{
    [AuthorizationRequired]
    public class TestController : ApiController
    {
        
        //
        // GET: /Test/
        [HttpPost]
        [ActionName("Test")]
        public HttpResponseMessage Test(Student student)
        {           
            return Request.CreateResponse(HttpStatusCode.OK, "Ok");
        }

    }
}
