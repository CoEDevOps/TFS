﻿using System.Linq;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Routing;
using Newtonsoft.Json;
using Capgemini.GroupProduction.GIS.WebApi.App_Start;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.WebApi.Helpers;
using Capgemini.GroupProduction.GIS.Common;
using System.Web.Http.ModelBinding.Binders;
using Capgemini.GroupProduction.GIS.Entity.Binders;

namespace Capgemini.GroupProduction.GIS.WebApi
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class WebApiApplication : System.Web.HttpApplication
    {       
        protected void Application_Start()
        {            

            WebApiConfig.Register(GlobalConfiguration.Configuration);
           // FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
           // RouteConfig.RegisterRoutes(RouteTable.Routes);
           
            //Define Formatters
            var formatters = GlobalConfiguration.Configuration.Formatters;
            var jsonFormatter = formatters.JsonFormatter;
            var settings = jsonFormatter.SerializerSettings;
            settings.Formatting = Formatting.Indented;            
            var appXmlType = formatters.XmlFormatter.SupportedMediaTypes.FirstOrDefault(t => t.MediaType == "application/xml");
            formatters.XmlFormatter.SupportedMediaTypes.Remove(appXmlType);

            //Add CORS Handler
            GlobalConfiguration.Configuration.MessageHandlers.Add(new CorsHandler());
            var provider = new SimpleModelBinderProvider(
            typeof(CustomDateTime), new CustomDateTimeModelBinderApi());
           
        }
    }
}