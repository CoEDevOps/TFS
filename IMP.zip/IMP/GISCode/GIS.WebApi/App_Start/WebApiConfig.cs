﻿using Capgemini.GroupProduction.GIS.WebApi.Filters;
using System.Web.Http;

namespace Capgemini.GroupProduction.GIS.WebApi
{
    /// <summary>
    /// WebApiConfig
    /// </summary>
    public static class WebApiConfig
    {
        /// <summary>
        /// Api routing
        /// </summary>
        /// <param name="config"></param>
        public static void Register(HttpConfiguration config)
        {
            // To handle routes like `/api/VTRouting/route`
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{action}/{id}/{sender}",
                defaults: new { id = RouteParameter.Optional, sender  =RouteParameter.Optional }
            );

            config.Filters.Add(new UnhandledExceptionFilter());  
        }
    }
}
