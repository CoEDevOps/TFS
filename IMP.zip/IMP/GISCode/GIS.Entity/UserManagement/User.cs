﻿
using System;
namespace Capgemini.GroupProduction.GIS.Entity
{
    /// <summary>
    /// User information is persisted in the user entity.
    /// </summary>
    public class User
    {
        /// <summary>
        /// User ID. 
        /// </summary>
        public Int64 UserID { get; set; }

        /// <summary>
        /// User name.
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// First name + Last Name of the user.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// User Email Id 
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// User Email Id 
        /// </summary>
        public string RoleIds { get; set; }

    }
}
