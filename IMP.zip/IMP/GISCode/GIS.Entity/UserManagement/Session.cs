﻿using System;

namespace Capgemini.GroupProduction.GIS.Entity
{
    /// <summary>
    /// Session information are stored in the enitity.
    /// </summary>
    public class Session
    {
        /// <summary>
        /// Session ID
        /// </summary>
        public string SessionID { get; set; }

        /// <summary>
        /// Session created date time.
        /// </summary>
        public DateTime Created { get; set; }

        /// <summary>
        /// Session expiration date time.
        /// </summary>
        public DateTime Expires { get; set; }

        /// <summary>
        /// Session locked date time.
        /// </summary>
        public DateTime LockDate { get; set; }

        /// <summary>
        /// Session local system date time
        /// </summary>
        public DateTime LockDateLocal { get; set; }

        /// <summary>
        /// Lock session cookie.
        /// </summary>
        public int LockCookie { get; set; }

        /// <summary>
        /// Session timeout.
        /// </summary>
        public int Timeout { get; set; }

        /// <summary>
        /// Session locked.
        /// </summary>
        public bool Locked { get; set; } 
     
        /// <summary>
        /// Session flag.
        /// </summary>
        public int Flags { get; set; }       
    }
}
