﻿
namespace Capgemini.GroupProduction.GIS.ValueObject
{
    /// <summary>
    /// LDAPUser
    /// </summary>
    public class LDAPUser
    {        
        /// <summary>
        /// User name.
        /// </summary>
        public string UserName { get; set; }        

        /// <summary>
        /// LDAP Server
        /// </summary>
        public string LDAPUrl { get; set; }
    }
}
