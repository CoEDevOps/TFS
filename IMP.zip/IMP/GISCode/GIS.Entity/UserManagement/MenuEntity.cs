﻿
namespace Capgemini.GroupProduction.GIS.Entity
{
    /// <summary>
    /// MenuEntity
    /// </summary>
    public class MenuEntity
    {
        /// <summary>
        /// Menu Name
        /// </summary>
        public string MenuName { get; set; }

        /// <summary>
        /// Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Contoller
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// Action
        /// </summary>
       // public string ActionName { get; set; }

        /// <summary>
        /// ManuOrder
        /// </summary>
        public int MenuOrder { get; set; }
    }
}
