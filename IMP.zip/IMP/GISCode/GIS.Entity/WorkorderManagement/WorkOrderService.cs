﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace Capgemini.GroupProduction.GIS.Entity
{
   
    /// <summary>
    /// Work Order Services
    /// </summary>
    ///   
    [DataContract]
    public class WorkOrderService
    {

        /// <summary>
        /// Service Id
        /// </summary>
        ///   
        [DataMember(IsRequired = true)]
        public long WorkOrderID { get; set; }

        /// <summary>
        /// Service Id
        /// </summary>
        ///   
         [DataMember(IsRequired = true)] 
        public int ServiceId { get; set; }

        /// <summary>
        /// Service Name
        /// </summary>
        /// 
         [DataMember(IsRequired = true)] 
        public string ServiceName { get; set; }

        /// <summary>
        /// Service Short Description
        /// </summary>
        /// 
       // [Required(ErrorMessage = "Please enter the StartDate.")]
        [DataMember(IsRequired = true)]
        //[DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public Nullable<DateTime> StartDate { get; set; }

        /// <summary>
        /// Service Long Decsription
        /// </summary>
        /// 
        //[Required(ErrorMessage = "Please enter the EndDate.")] 
        [DataMember(IsRequired = true)]
       // [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public Nullable<DateTime> EndDate { get; set; }

        /// <summary>
        /// Service Long Decsription
        /// </summary>
        /// 
         [DataMember(IsRequired = true)] 
        public string FileName { get; set; }

        [DataMember(IsRequired = true)] 
        public string DisplayFileName { get; set; }

        [DataMember(IsRequired = true)] 
        public Int64 UserID { get; set; }

        [DataMember(IsRequired = true)]
        public string Remarks { get; set; }

    }
}
