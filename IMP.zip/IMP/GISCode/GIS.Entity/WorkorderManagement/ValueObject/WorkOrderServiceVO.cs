﻿using Capgemini.GroupProduction.GIS.Entity;
using System;

namespace Capgemini.GroupProduction.GIS.ValueObject
{
    /// <summary>
    /// Work Order Services
    /// </summary>
    /// 
    public class WorkOrderServiceVO
    {

        /// <summary>
        /// Workorder Id
        /// </summary>
        ///          
        public long WorkOrderID { get; set; }

        public long WorkOrderServiceId { get; set; }

        /// <summary>
        /// Service Id
        /// </summary>
        /// 
        ///          
        public int ServiceId { get; set; }

        public string ServiceReferenceNumber { get; set; }

        /// <summary>
        /// Service Name
        /// </summary>
        ///         
        public string ServiceName { get; set; }

        /// <summary>
        /// Service Start Date
        /// </summary>
        ///         
        public Nullable<DateTime> StartDate { get; set; }
        /// <summary>
        /// Service End Date
        /// </summary>
        public Nullable<DateTime> EndDate { get; set; }
        /// <summary>
        /// Service Created Date
        /// </summary>
        public Nullable<DateTime> CreatedDate { get; set; }
        /// <summary>
        /// Service Filename
        /// </summary>
        public string FileName { get; set; }
        /// <summary>
        /// Display FileName
        /// </summary>
        public string DisplayFileName { get; set; }
        /// <summary>
        /// Service Createdby
        /// </summary>
        public int CreatedBy { get; set; }
        /// <summary>
        /// Service Status
        /// </summary>
        public int Status { get; set; }
        /// <summary>
        /// Service Message
        /// </summary>
        public CustomMessage Message { get; set; }
        /// <summary>
        /// Service Remarks
        /// </summary>
        public string Remarks { get; set; }
        /// <summary>
        /// Service Comments
        /// </summary>
        public string Comments { get; set; }
        /// <summary>
        /// Service URL
        /// </summary>
        public string URL { get; set; }
        /// <summary>
        /// Input Json File Path
        /// </summary>
        public string InputFilePath { get; set; }
        
    }
}
