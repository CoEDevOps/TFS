﻿
namespace Capgemini.GroupProduction.GIS.ValueObject
{
    /// <summary>
    /// Service Master Details
    /// </summary>
    public class ServiceMasterVO
    {
        /// <summary>
        /// Service Id
        /// </summary>
        public int ServiceId { get; set; }

        /// <summary>
        /// Service Name
        /// </summary>
        public string ServiceName { get; set; }
        /// <summary>
        /// Service Short Name
        /// </summary>
        public string ServiceShortName { get; set; }
        /// <summary>
        /// Service Short Description
        /// </summary>
        public string ShortDescription { get; set; }

        /// <summary>
        /// Service Features 
        /// </summary>
        public string Features { get; set; }

        /// <summary>
        /// Service Eligibility 
        /// </summary>
        public string Eligibility { get; set; }
        /// <summary>
        /// Eligibility Short Description 
        /// </summary>
        public string EligibilityDescription { get; set; }
        /// <summary>
        /// Service Pricing 
        /// </summary>
        public string Pricing { get; set; }
        /// <summary>
        /// Support id 
        /// </summary>
        public string Support { get; set; }
        
    }
}
