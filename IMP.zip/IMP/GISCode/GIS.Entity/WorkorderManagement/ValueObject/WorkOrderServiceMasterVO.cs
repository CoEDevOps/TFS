﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.GIS.ValueObject
{
    public class WorkOrderServiceMasterVO
    {
        /// <summary>
        /// Work Order Number
        /// </summary>
        public string workordernumber { get; set; }
        /// <summary>
        /// Engagement Code
        /// </summary>
        public string engagementcode { get; set; }

        /// <summary>
        /// Engagement Name
        /// </summary>
        public string engagementname { get; set; }
        /// <summary>
        /// Project Manager
        /// </summary>
        public string projectmanager { get; set; }
        /// <summary>
        /// Customer Name
        /// </summary>
        public string customername { get; set; }
        /// <summary>
        /// Start Date
        /// </summary>
        public string startdate { get; set; }
        /// <summary>
        /// End Date 
        /// </summary>
        public string enddate { get; set; }
        /// <summary>
        /// Created By
        /// </summary>
        public string createdby { get; set; }
        /// <summary>
        /// User Name
        /// </summary>
        public string username { get; set; }
        /// <summary>
        /// Created Date
        /// </summary>
        public string createddate { get; set; }
        /// <summary>
        /// Service Name
        /// </summary>
        public string servicename { get; set; }
        /// <summary>
        /// Remark 
        /// </summary>
        public string remarks { get; set; }
        /// <summary>
        /// File Name
        /// </summary>
        public string file { get; set; }
    }
}
