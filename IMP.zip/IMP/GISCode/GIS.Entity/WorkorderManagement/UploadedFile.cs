﻿
namespace Capgemini.GroupProduction.GIS.Entity.ServiceManagement
{
    /// <summary>
    /// UploadFile
    /// </summary>
    public class UploadFile
    {

        public string FileName { get; set; }

        public string DisplayFileName { get; set; }

        public int FileSize { get; set; }
        public string FileType { get; set; }
    }
}
