﻿using Capgemini.GroupProduction.GIS.Entity.LocalResource.Test;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Resources;
using System.Linq;
using System.Text;


namespace Capgemini.GroupProduction.GIS.Entity.Test
{
    public class Student
    {
        [Display(Name = "FirstName", ResourceType = typeof(StudentResource))]  
       // [Required(ErrorMessageResourceName = "RequiredFirstName", ErrorMessageResourceType = typeof(StudentResource))]
        public string FirstName { get; set; }

        [Display(Name = "LastName", ResourceType = typeof(StudentResource))]  
        public string LastName { get; set; }

        [Display(Name = "EnrolledDate", ResourceType = typeof(StudentResource))]
        public CustomDateTime EnrolledDate { get; set; }
    }
}
