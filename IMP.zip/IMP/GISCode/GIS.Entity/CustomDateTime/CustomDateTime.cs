﻿using Capgemini.GroupProduction.GIS.Entity.Binders;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web.Http.ModelBinding;

namespace Capgemini.GroupProduction.GIS.Entity
{
    [ModelBinder(typeof(CustomDateTimeModelBinderApi))]
    public class CustomDateTime 
    {
        private string value;
        private DateTime valueAsPerFormat;
        private bool isValidDate;

        public CustomDateTime(string value)
        {
            this.value = value;   
           
            /* Validate the date as per the UI culture set.
             * In case the date is not valid then the isValidDate variable is set to false.
             * That means the client has send the invalid date.
             * When the date is valid then the date is initilized as per the server culture.
             */
            DateTime dateTime;
            isValidDate = DateTime.TryParse(value, Thread.CurrentThread.CurrentUICulture, DateTimeStyles.None, out dateTime);
           
            DateTime minDate = new DateTime(1953, 1, 1); 
           
            if(isValidDate)
            {
                //In case the datetime is less then min date then is considered is not validdate.
                if (dateTime < minDate)
                {
                    isValidDate = false;
                    return;
                }
                // When the date is valid then the date is initilized as per the server  culture.
                valueAsPerFormat = new DateTime(dateTime.Year, dateTime.Month, dateTime.Day);
            }

        }

        public static implicit operator CustomDateTime(string value)
        {
            return new CustomDateTime(value);
        }

        public static string CurrentDateUICulture
        {
            get
            {
                var date = DateTime.Now.ToString(Thread.CurrentThread.CurrentUICulture.DateTimeFormat.ShortDatePattern);
                date = date.Replace("-", "/");
                return date;                
            }
        }

        public override string ToString()
        {
            return value;
        }
      

        public bool IsValidDate
        {
            get
            {
                return isValidDate;
            }
        }

        public DateTime DateServerCulture
        {
            get
            {
                return valueAsPerFormat;
            }
        }
    }
}
