﻿using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.Entity.LocalResource.Test;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.ModelBinding;
using System.Web.Http.ValueProviders;

namespace Capgemini.GroupProduction.GIS.Entity.Binders
{
    public class CustomDateTimeModelBinderApi : System.Web.Http.ModelBinding.IModelBinder
    {
        public bool BindModel(HttpActionContext actionContext, System.Web.Http.ModelBinding.ModelBindingContext bindingContext)
        {
            if (bindingContext.ModelType != typeof(CustomDateTime))
            {
                return false;
            }

            System.Web.Http.ValueProviders.ValueProviderResult val = bindingContext.ValueProvider.GetValue(
                bindingContext.ModelName);
            if (val == null)
            {
                return false;
            }


            CustomDateTime customDateTime = new CustomDateTime(val.AttemptedValue);

            if (!customDateTime.IsValidDate)
            {
                bindingContext.ModelState.AddModelError(bindingContext.ModelName, ModelValidationResources.InvalidDate);
                return false;
            }

            bindingContext.Model = customDateTime;
            return true;
        }
       
    }
}