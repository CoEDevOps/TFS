﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.GIS.ValueObject
{
    public class EmailStatus
    {
        /// <summary>
        /// Work Order Id
        /// </summary>
        public Int64? WorkOrderId { get; set; }

        /// <summary>
        /// Work Order Service Id
        /// </summary>
        public Int64? WorkOrderServiceId { get; set; }        

        /// <summary>
        /// Status
        /// </summary>
        public int Status { get; set; }
    }

}
