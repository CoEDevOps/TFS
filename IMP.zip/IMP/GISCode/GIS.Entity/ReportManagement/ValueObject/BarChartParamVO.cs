﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.GIS.Report.ValueObject
{
    public class BarChartParamVO
    {
        /// <summary>
        /// X Axis Parameter
        /// </summary>
        public int XAxisParameter { get; set; }

        /// <summary>
        /// Y Axis Parameter
        /// </summary>
        public string YAxisParameter { get; set; }
    }
}
