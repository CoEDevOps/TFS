﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.GIS.Report.ValueObject
{
    public class BarChartVO
    {
        /// <summary>
        /// Service Count
        /// </summary>
        public int ServiceCount { get; set; }

        /// <summary>
        /// Service Name
        /// </summary>
        public string ServiceName { get; set; }
    }
}
