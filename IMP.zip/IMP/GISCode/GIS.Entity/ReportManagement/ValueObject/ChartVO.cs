﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.GIS.Report.ValueObject
{
    public class ChartVO
    {
        /// <summary>
        /// Pie Chart Collection
        /// </summary>
        public List<PieChartParamVO> PieChart { get; set; }
        /// <summary>
        /// Bar Chart Collection
        /// </summary>
        public List<BarChartParamVO> BarChart { get; set; }

    }
}
