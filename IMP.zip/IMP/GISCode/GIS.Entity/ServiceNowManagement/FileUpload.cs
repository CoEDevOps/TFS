﻿using Newtonsoft.Json;

namespace Capgemini.GroupProduction.GIS.ServiceNow.Entity
{
    /// <summary>
    /// FileUpload : ecc_queue
    /// </summary>   
    public class FileUpload
    {
        /// <summary>
        /// Topic
        /// </summary>
        [JsonProperty(PropertyName = "topic")]
        public string Topic { get; set; }

        /// <summary>
        /// Id Pk
        /// </summary>
        [JsonProperty(PropertyName = "sys_id")]
        public string FileId { get; set; }

        /// <summary>
        /// Base64 string
        /// </summary>
        [JsonProperty(PropertyName = "payload")]
        public string FileData { get; set; }

        /// <summary>
        /// Agent
        /// </summary>
        [JsonProperty(PropertyName = "agent")]
        public string Agent { get; set; }

        /// <summary>
        /// Tablename: Sysid pk
        /// </summary>
        [JsonProperty(PropertyName = "source")]
        public string Source { get; set; }

        /// <summary>
        /// File Name
        /// </summary>
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        /// <summary>
        /// Error Message
        /// </summary>
        [JsonProperty(PropertyName = "error_string")]
        public string ErrorMsg { get; set; }
    }
}

