﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.GIS.ServiceNow.Entity
{
    /// <summary>
    /// Service Now Instance
    /// </summary>
    public class ServiceNowInstance
    {
        /// <summary>
        /// Instance Id
        /// </summary>
        public int InstanceId { get; set; }

        /// <summary>
        /// Instance Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Factory Id
        /// </summary>
        public int FactoryId { get; set; }

        /// <summary>
        /// Service Now URL
        /// </summary>
        public string SnowURL { get; set; }

        /// <summary>
        /// Service Now User Name
        /// </summary>
        public string SnowUserName { get; set; }

        /// <summary>
        /// Service Now Password
        /// </summary>
        public string SnowPassword { get; set; }

        /// <summary>
        /// Service Now Time Diff
        /// </summary>
        public string TimeDiff { get; set; }

        /// <summary>
        /// Servie Now Active Flag
        /// </summary>
        public bool Active { get; set; }

    }
}
