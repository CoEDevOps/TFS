﻿using Newtonsoft.Json;

namespace Capgemini.GroupProduction.GIS.ServiceNow.Entity
{
    /// <summary>
    /// Category Item -- VTF Service
    /// </summary>
    public class CategoryItem
    {
        /// <summary>
        /// Category
        /// </summary>
        [JsonProperty(PropertyName = "category")]
        public KeyVal CategoryId { get; set; }

        /// <summary>
        /// Item Price
        /// </summary>
        [JsonProperty(PropertyName = "price")]
        public string CategoryItemPrice { get; set; }

        /// <summary>
        /// Active
        /// </summary>
        [JsonProperty(PropertyName = "active")]
        public string Active { get; set; }        

        /// <summary>
        /// Name
        /// </summary>
        [JsonProperty(PropertyName = "sys_name")]
        public string CategoryItemName { get; set; }

        /// <summary>
        /// Id Pk
        /// </summary>
        [JsonProperty(PropertyName = "sys_id")]
        public string CategoryItemId { get; set; }        

        /// <summary>
        /// Catalog
        /// </summary>
        [JsonProperty(PropertyName = "sc_catalogs")]
        public string CatalogId { get; set; }

        /// <summary>
        /// VTF Equivalent Service Id
        /// </summary>
        [JsonProperty(PropertyName = "u_vtfserviceid")]
        public string VTFServiceId { get; set; }        
    }
}
