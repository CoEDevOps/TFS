﻿using System.Collections.Generic;
using Capgemini.GroupProduction.GIS.ServiceNow.Entity;
using Newtonsoft.Json;

namespace Capgemini.GroupProduction.GIS.ServiceNow.ValueObject
{
    /// <summary>
    /// Category Get 
    /// </summary>
    public class CategoryItemVO
    {
        /// <summary>
        /// Category List
        /// </summary>
        [JsonProperty(PropertyName = "result")]
        public List<CategoryItem> CategoryItemList { get; set; }
    }
}
