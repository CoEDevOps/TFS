﻿using Capgemini.GroupProduction.GIS.ServiceNow.Entity;
using Newtonsoft.Json;

namespace Capgemini.GroupProduction.GIS.ServiceNow.ValueObject
{
    /// <summary>
    /// New Service Request Item
    /// </summary>
    public class ServiceRequestItemVO
    {
        [JsonProperty(PropertyName = "result")]
        public NewServiceRequestItem serviceRequestItem { get; set; }
    }

    /// <summary>
    /// New Service Request Item
    /// </summary>
    public class NewServiceRequestItem
    {
        /// <summary>
        /// Catalog Link::Value
        /// </summary>
        [JsonProperty(PropertyName = "sc_catalog")]
        public KeyVal CatalogId { get; set; }        

        /// <summary>
        /// Service Request , Link :: Value
        /// </summary>
        [JsonProperty(PropertyName = "request")]
        public KeyVal ServiceRequestId { get; set; }             

        /// <summary>
        /// number
        /// </summary>
        [JsonProperty(PropertyName = "number")]
        public string RequestItemNumber { get; set; }

        /// <summary>
        /// Category Item, Link :: Value
        /// </summary>
        [JsonProperty(PropertyName = "cat_item")]
        public KeyVal CategoryItemId { get; set; }       

        /// <summary>
        /// sys_id
        /// </summary>
        [JsonProperty(PropertyName = "sys_id")]
        public string ServiceRequestItemId { get; set; }

        /// <summary>
        /// comments
        /// </summary>
        [JsonProperty(PropertyName = "comments")]
        public string Comments { get; set; }
    }
}
