﻿using System;

namespace Capgemini.GroupProduction.GIS.ServiceNow.ValueObject
{
    public class ServiceWorkOrderVO
    {
        /// <summary>
        /// WorkOrderId
        /// </summary>
        public Int64 WorkOrderId { get; set; }

        /// <summary>
        /// WorkOrderNumber
        /// </summary>
        public string WorkOrderNumber { get; set; }

        /// <summary>
        /// FactoryId
        /// </summary>
        public int FactoryId { get; set; }

        /// <summary>
        /// SnowFilePath
        /// </summary>
        public string SnowFilePath { get; set; }

        ///// <summary>
        ///// Work Order Details
        ///// </summary>
        //public NewWorkOrderVO WorkOrder { get; set; }

        ///// <summary>
        ///// Work Order service selected
        ///// </summary>
        //public List<WorkOrderService> WorkOrderService { get; set; }

        ///// <summary>
        ///// SNOW URL
        ///// </summary>
        //public string SnowUrl { get; set; }

        ///// <summary>
        ///// SNOW User Name
        ///// </summary>
        //public string SnowUserName { get; set; }

        ///// <summary>
        ///// Snow Password
        ///// </summary>
        //public string SnowPassword { get; set; }

        ///// <summary>
        ///// File Path
        ///// </summary>
        //public string FilePath { get; set; }
    }
}
