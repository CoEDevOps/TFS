﻿using Capgemini.GroupProduction.GIS.ServiceNow.Entity;
using Newtonsoft.Json;

namespace Capgemini.GroupProduction.GIS.ServiceNow.ValueObject
{
    public class FileUploadVO
    {
        [JsonProperty(PropertyName = "result")]
        public FileUpload SnowFile { get; set; }
    }
}
