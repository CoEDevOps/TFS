﻿using System.ComponentModel;

namespace Capgemini.GroupProduction.GIS.Entity
{
    public enum MessageType
    {
        Unhandled = 1,
        Success = 2,
        Failure = 3
    }

    public enum GenericCompareOperator
    {
        GreaterThan,
        GreaterThanOrEqual,
        LessThan,
        LessThanOrEqual
    }


    /// <summary>
    /// Work Order Status
    /// </summary>
  /*  public enum WorkorderStatus
    {       
        [Description("Pending")]
        Pending = 0,

        [Description("Submitted")]
        Submitted = 1,

        [Description("Approved")]
        Approved = 2,

        [Description("Rejected")]
        Rejected = 3
    }*/


    /// <summary>
    /// Work Order Priority
    /// </summary>
    public enum WorkorderPriority
    {
        [Description("Select")]
        Select = 0,

        [Description("High")]
        High = 1,

        [Description("Medium")]
        Medium = 2,

        [Description("Low")]
        Low = 3
    }

    //public enum ServiceStatus
    //{
    //    Analyze_Requirement = 0,
    //    Capacity_Planning = 1,
    //    Estimation = 2,
    //    Analyze_Service_Request = 3,
    //    Assign_Rmg_Team = 4,
    //    OnBoarding = 5,
    //    Delivery = 6,
    //    Incomplete = 7,
    //    Complete = 8,

    //}

    //public enum WorkorderStatus
    //{
    //    Pending_For_Estimation = 0,
    //    Approved  = 1,
    //    Rejected = 2,
    //    Incomplete  = 3,
    //    Delivered = 4
    //}

    public enum ServiceStatus
    {
        Created = 0,
        Work_in_Progress = 1,
        Cancelled = 2,
        Failed = 3,
        Completed = 4
    }

    public enum WorkorderStatus
    {
        Created = 0,
        Work_in_Progress = 1,
        Cancelled = 2,
        Failed = 3,
        Completed = 4
    }

    public enum StatusType
    {
        WorkOrder = 1,
        Service = 2
    }

    public enum UserRole
    {
        Admin = 1,
        Factory_Manager = 2,
        Enagement_Manager = 3
    }

   /* /// <summary>
    /// Work Order Priority
    /// </summary>
    public enum ServiceStatus
    {
        Pending = 1,

        Waiting = 2
    }*/
}
