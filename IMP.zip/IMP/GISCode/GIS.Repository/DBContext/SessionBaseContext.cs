﻿using System.Data.Entity;
using Capgemini.GroupProduction.GIS.Common;
using System.Configuration;

namespace Capgemini.GroupProduction.GIS.Database.DBContext
{
    /// <summary>
    /// Session Database conext class. Manages the operation with Session Database. 
    /// </summary>
    internal class SessionBaseContext : DbContext
    {
        internal SessionBaseContext()
            : base(ConfigurationManager.ConnectionStrings["SessionEntities"].ToString())
        {
            System.Data.Entity.Database.SetInitializer<SessionBaseContext>(null);
        }
    }
}
