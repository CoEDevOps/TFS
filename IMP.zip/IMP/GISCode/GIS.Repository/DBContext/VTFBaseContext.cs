﻿using System.Data.Entity;
using Capgemini.GroupProduction.GIS.Common;
using System.Configuration;

namespace Capgemini.GroupProduction.GIS.Database.DBContext
{
    /// <summary>
    /// Base conext class.
    /// </summary>
    /// <typeparam name="TContext"></typeparam>
    internal class VTFBaseContext : DbContext
    {
        internal VTFBaseContext()
            : base(ConfigurationManager.ConnectionStrings["VTFEntities"].ToString())
        {
            // Set the intializer to null. Its is initialized as per 
            // connection string.
            System.Data.Entity.Database.SetInitializer<VTFBaseContext>(null);
        }
        
    }
}
