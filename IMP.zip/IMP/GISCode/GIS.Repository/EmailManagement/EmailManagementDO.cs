﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Capgemini.GroupProduction.GIS.Database.DBContext;
using Capgemini.GroupProduction.GIS.RepositoryInterface;
using Capgemini.GroupProduction.GIS.Repository;
using Capgemini.GroupProduction.GIS.ValueObject;
using System.Data.SqlClient;

namespace Capgemini.GroupProduction.GIS.Repository
{
    public class EmailManagementDO : IEmailManagementDO
    {
        /// <summary>
        /// Private Constructor
        /// </summary>
        public EmailManagementDO()
        {
            //
        }

        /// <summary>
        /// Get New Order Details to be sent via email
        /// </summary>
        /// <param name="workOrderId"></param>
        /// <returns></returns>
        public NewWorkOrderVO GetNewWorkOrderDetails(Int64 workOrderId)
        {
            NewWorkOrderVO newwodet = new NewWorkOrderVO();
            using (VTFBaseContext vtfContext = new VTFBaseContext())            
            {
                var woidParameter = new SqlParameter("workorderId", workOrderId);
                newwodet = vtfContext.Database.SqlQuery<NewWorkOrderVO>("sp_GetNewWorkOrderDetails @workorderId", woidParameter).FirstOrDefault();
            }
            return newwodet;
        }
    }
}
