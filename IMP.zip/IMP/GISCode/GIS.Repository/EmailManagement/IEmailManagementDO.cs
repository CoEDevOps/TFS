﻿using Capgemini.GroupProduction.GIS.ValueObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.GIS.RepositoryInterface
{
    public interface IEmailManagementDO
    {
        /// <summary>
        /// Get New Order Details to be sent via email
        /// </summary>
        /// <param name="workOrderId"></param>
        /// <returns></returns>
        NewWorkOrderVO GetNewWorkOrderDetails(Int64 workOrderId);        
    }
}
