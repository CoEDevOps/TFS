﻿using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using Capgemini.GroupProduction.GIS.Database.DBContext;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.RepositoryInterface;
using System;

namespace Capgemini.GroupProduction.GIS.Repository
{
    /// <summary>
    /// User management repository.
    /// </summary>
    public class UserManagementDO : IUserManagementDO
    {
        private readonly VTFBaseContext m_VtfDataBaseContext;
        private readonly SessionBaseContext m_SessionBaseContext;    

        public UserManagementDO()
        {
            m_VtfDataBaseContext = new VTFBaseContext();
            m_SessionBaseContext = new SessionBaseContext();          
        }

        /// <summary>
        /// Get user details from database.
        /// </summary>
        /// <param name="userName">User name</param>
        /// <param name="password">Password</param>
        /// <returns>User entity for the credentials provided.Null in case user not found</returns>
        public User GetUser(string userName, string password)
        {
            var userNameParameter = userName != null ?
                            new SqlParameter("userName", userName) :
                            new SqlParameter("userName", typeof(string));

            var passwordParameter = password != null ?
                            new SqlParameter("password", password) :
                            new SqlParameter("password", typeof(string));

            return this.m_VtfDataBaseContext.Database.SqlQuery<User>("sp_GetUser @userName, @password", userNameParameter, passwordParameter).FirstOrDefault();
        }

        /// <summary>
        /// Get UserName from database.
        /// </summary>
        /// <param name="UserID">UserID</param>
        /// <returns>UserName</returns>
        public User GetUserName(int UserID)
        {
            var userIDParameter = new SqlParameter("UserID", UserID);

            return this.m_VtfDataBaseContext.Database.SqlQuery<User>("sp_GetUserName @UserID", userIDParameter).FirstOrDefault();
        }

        /// <summary>
        /// Get session details from database.
        /// </summary>
        /// <param name="sessionID">session id</param>
        /// <returns>Session entity for the particular SessionID</returns>
        public Session GetSession(string sessionID)
        {
            var authTokenParameter = new SqlParameter("SessionToken", sessionID);

            return this.m_SessionBaseContext.Database.SqlQuery<Session>("sp_GetSession @SessionToken", authTokenParameter).FirstOrDefault();
        }

        /// <summary>
        /// Add session entity in database.
        /// </summary>
        /// <param name="sessionEntity">Session entity.</param>
        /// <returns>Session entity added to database.</returns>
        public Session AddSession(Session tokenEntity)
        {
            var sessionIdParameter = new SqlParameter("SessionId", tokenEntity.SessionID);
            var createdParameter = new SqlParameter("Created", tokenEntity.Created);
            var expiresParameter = new SqlParameter("Expires", tokenEntity.Expires);
            var lockDateParameter = new SqlParameter("LockDate", tokenEntity.LockDate);
            var lockDateLocalParameter = new SqlParameter("LockDateLocal", tokenEntity.LockDateLocal);
            var lockedParameter = new SqlParameter("Locked", tokenEntity.Locked);
            var timeoutParameter = new SqlParameter("Timeout", tokenEntity.Timeout);
            var lockCookieParameter = new SqlParameter("LockCookie", tokenEntity.LockCookie);
            var flagsParameter = new SqlParameter("Flags", tokenEntity.Flags);


            return this.m_SessionBaseContext.Database.SqlQuery<Session>("sp_InsertSessionToken @SessionId, @Created, @Expires, @LockDate, @LockDateLocal, @Locked, @Timeout, @LockCookie, @Flags"
                , sessionIdParameter, createdParameter, expiresParameter, lockDateParameter, lockDateLocalParameter,
                lockedParameter, timeoutParameter, lockCookieParameter, flagsParameter).FirstOrDefault();           
        }

        /// <summary>
        /// Get Menu Items
        /// </summary>
        /// <returns></returns>
        public IEnumerable<MenuEntity> GetMenuItem()
        {
            return this.m_VtfDataBaseContext.Database.SqlQuery<MenuEntity>("spGetMenu");
        }

        /// <summary>
        /// Add New user
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="name"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        public User AddUser(string userName, string name,string email)
        {
            var userNameParameter = userName != null ?
                            new SqlParameter("userName", userName) :
                            new SqlParameter("userName", typeof(string));

            var nameParameter = name != null ?
                            new SqlParameter("name", name) :
                            new SqlParameter("name", typeof(string));

            var emailParameter = email != null ?
                            new SqlParameter("email", email) :
                            new SqlParameter("email", typeof(string));

            return this.m_VtfDataBaseContext.Database.SqlQuery<User>("sp_AddNewUser @userName, @name, @email", userNameParameter, nameParameter, emailParameter).FirstOrDefault();
        }


        /// <summary>
        /// Get menu items based on the role of the user.
        /// </summary>
        /// <param name="userID">User id.</param>       
        /// <returns>Menu items based on user role.</returns>
        public IEnumerable<MenuEntity> GetRoleMenuItem(Int64 userID)
        {
            var userIDParameter = new SqlParameter("UserID", userID);

            return this.m_VtfDataBaseContext.Database.SqlQuery<MenuEntity>("sp_GetRoleMenu @UserID", userIDParameter);
        }


        /// <summary>
        /// Get role access based on the role of the user.
        /// </summary>
        /// <param name="userID">User id.</param>       
        /// <returns>RoleAccess items based on user role.</returns>
        public IEnumerable<RoleAccess> GetRoleAccess(Int64 userID)
        {
            var userIDParameter = new SqlParameter("UserID", userID);

            return this.m_VtfDataBaseContext.Database.SqlQuery<RoleAccess>("sp_GetRoleControllerAction @UserID", userIDParameter).ToList();

        }

    }
}
