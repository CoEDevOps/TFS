﻿using System.Collections.Generic;
using Capgemini.GroupProduction.GIS.Database.DBContext;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.RepositoryInterface;
using System.Data.SqlClient;
using Capgemini.GroupProduction.GIS.ValueObject;
using System.Linq;
using System;
using System.Data;
using System.IO;
using System.Xml.Serialization;


namespace Capgemini.GroupProduction.GIS.Repository
{
    /// <summary>
    /// Service Management Repository : Implements IServiceMgmtRepository
    /// </summary>
    public class WorkorderManagementDO : IWorkorderManagementDO
    {
        
        /// <summary>
        /// Constructor : Sets DB context
        /// </summary>
        public WorkorderManagementDO()
        {
            //m_VtfDataBaseContext = new VTFBaseContext();
        }

        /// <summary>
        /// Returns Engagement Code/Name based on serached keyword
        /// </summary>
        /// <param name="searchKeyword"></param>
        /// <returns></returns>
        public IEnumerable<EngagementCodeVO> SearchEngagementCodes(string searchKeyword)
        {
            IEnumerable<EngagementCodeVO> engmtCodes;
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
                var codeParameter = new SqlParameter("code", searchKeyword);                

                engmtCodes = vtfContext.Database.SqlQuery<EngagementCodeVO>("sp_GetEngagementDetails @code", codeParameter).ToList();                
               
            }

            return engmtCodes;
        }

        /// <summary>
        /// Get work order details with Engagement Details
        /// </summary>
        /// <param name="engmtCode"></param>
        /// <param name="workOrderId"></param>
        /// <returns></returns>
        public WorkOrderDetailsVO GetWorkOrderDetails(string engmtCode, Int64 workOrderId)
        {
            WorkOrderDetailsVO workOrderDet;
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
                var codeParameter = new SqlParameter("code", engmtCode);
                var workOrderIdParameter = new SqlParameter("WorkOrderId", System.Data.SqlDbType.BigInt);
                workOrderIdParameter.IsNullable = true;
                workOrderIdParameter.Value = workOrderId;
                workOrderDet = vtfContext.Database.SqlQuery<WorkOrderDetailsVO>("sp_GetEngagementDetailsforWO @code, @WorkOrderId", codeParameter, workOrderIdParameter).FirstOrDefault();
                
            }
            return workOrderDet;
        }

        /// <summary>
        /// Get Service List
        /// </summary>
        /// <param name="serviceId"></param>
        /// <returns></returns>
        public IEnumerable<ServiceMasterVO> GetServiceList(int serviceIds)
        {
            IEnumerable<ServiceMasterVO> serviceDet;
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
                var serviceIdParameter = new SqlParameter("serviceIds", serviceIds);
                serviceIdParameter.DbType = DbType.String;
               
                serviceDet = vtfContext.Database.SqlQuery<ServiceMasterVO>("[dbo].[sp_GetServiceMasterList] @serviceIds", serviceIdParameter).ToList();
                
            }
            return serviceDet;
        }

        /// <summary>
        /// Get Service List
        /// </summary>
        /// <param name="serviceId"></param>
        /// <returns></returns>
        public IEnumerable<ServiceMasterVO> GetServiceList(IEnumerable<int> serviceIds)
        {
            IEnumerable<ServiceMasterVO> serviceDet;
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
                var serviceIdParameter = new SqlParameter("serviceIds", serviceIds);                

                using (StringWriter sw = new StringWriter())
                {
                    XmlSerializer xs = new XmlSerializer(typeof(List<int>));
                    xs.Serialize(sw, serviceIds.ToList());

                    string xml = sw.ToString().Replace("utf-16", "utf-8");

                    serviceIdParameter.Value = xml;
                }                

                serviceDet = vtfContext.Database.SqlQuery<ServiceMasterVO>("[dbo].[sp_GetServiceMasterByIds] @serviceIds", serviceIdParameter).ToList();
            }
            return serviceDet;
        }

        /// <summary>
        /// Add Work Order Details
        /// </summary>
        /// <param name="workOrderDetails"></param>
        /// <returns></returns>
        public Int64 AddWorkOrderDetails(WorkOrder workOrderDetails)
        {
            Int64 result;
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
               
                //var workOrderNumberParameter = new SqlParameter("WorkOrderNumber", string.Empty);
                var engmtCodeParameter = new SqlParameter("EngagementCode", workOrderDetails.EngagementCode);
                var priorityParameter = new SqlParameter("Priority", workOrderDetails.Priority);
                var startdtParameter = new SqlParameter("StartDate", workOrderDetails.StartDate);
                var enddateParameter = new SqlParameter("EndDate", workOrderDetails.EndDate);
                var statusParameter = new SqlParameter("Status", workOrderDetails.Status);
                var userParameter = new SqlParameter("User", workOrderDetails.UserId);               

                result = vtfContext.Database.SqlQuery<Int64>("sp_AddWorkOrderDetails @EngagementCode,@Priority,@StartDate,@EndDate,@Status,@User",
                    engmtCodeParameter, priorityParameter, startdtParameter, enddateParameter, statusParameter, userParameter
                    ).First();               
                       
       
            }          
            return result;  
        }

        /// <summary>
        /// Add Work Order Services
        /// </summary>
        /// <param name="workOrderServices"></param>
        /// <param name="workOrderId"></param>
        public WorkOrderServiceDetails AddWorkOrderServiceDetails(IEnumerable<WorkOrderService> workOrderServices)
        {
            WorkOrderServiceDetails workOrderService = new WorkOrderServiceDetails();           

            if (workOrderServices.Count() == 0)
            {
                workOrderService.Transaction = 0;
                workOrderService.Message = "No Service";
                return workOrderService;
            }

            workOrderService.WorkOrder = new WorkOrderDetailsVO();
            workOrderService.WorkOrder.WorkOrderId = workOrderServices.FirstOrDefault().WorkOrderID;
               
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
                SqlParameter services = new SqlParameter("Services", string.Empty);

                using (StringWriter sw = new StringWriter())
                {
                    XmlSerializer xs = new XmlSerializer(typeof(List<WorkOrderService>));
                    xs.Serialize(sw, workOrderServices);

                    string xml = sw.ToString().Replace("utf-16", "utf-8");

                    services.Value = xml;
                }
               

                SqlParameter msgParameter = new SqlParameter("Message", workOrderService.Message);
                msgParameter.Direction = ParameterDirection.Output;
                msgParameter.SqlDbType = SqlDbType.VarChar;
                msgParameter.Size = 500;

                SqlParameter transaction = new SqlParameter("Transaction", workOrderService.Transaction);
                transaction.Direction = ParameterDirection.Output;
                transaction.SqlDbType = SqlDbType.Int;

                SqlParameter workOrderNum = new SqlParameter("WorkOrderNumber", string.Empty);
                workOrderNum.Direction = ParameterDirection.Output;
                workOrderNum.SqlDbType = SqlDbType.VarChar;
                workOrderNum.Size = 10;

                var result = vtfContext.Database.SqlQuery<int>("sp_AddWorkOrderAllServices @Services, @Message OUTPUT, @Transaction OUTPUT, @WorkOrderNumber OUTPUT", services, msgParameter, transaction, workOrderNum).First();

                string message = msgParameter.Value.ToString();
                workOrderService.Message = message;
                workOrderService.WorkOrder.WorkOrderNumber = workOrderNum.Value.ToString();
                workOrderService.Transaction = (int)transaction.Value;
            }

            return workOrderService;
        }

        /// <summary>
        /// Get Service List
        /// </summary>
        /// <param name="serviceId"></param>
        /// <returns></returns>
        public IEnumerable<WorkOrderServiceVO> GetServiceByWorkOrderId(Int64 workerId)
        {
            IEnumerable<WorkOrderServiceVO> serviceDet;
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
                var workerIdParameter = new SqlParameter("WorkOrderID", workerId);
                serviceDet = vtfContext.Database.SqlQuery<WorkOrderServiceVO>("sp_GetServiceByWorkOrderId @WorkOrderID", workerIdParameter).ToList();
            }
            return serviceDet;
        }

        /// <summary>
        /// Get My Work Orders
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public IEnumerable<WorkOrder> GetMyWorkOrders(string userId)
        {
            IEnumerable<WorkOrder> myWorkOrders;
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
                var codeParameter = new SqlParameter("User", userId);
                myWorkOrders = vtfContext.Database.SqlQuery<WorkOrder>("sp_GetMyWorkOrders @User", codeParameter).ToList();
            }
            return myWorkOrders;
        }

        /// <summary>
        /// Get My Work Orders
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public IEnumerable<WorkOrder> GetQueueWorkOrders(string userId)
        {
            IEnumerable<WorkOrder> myWorkOrders;
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
                var codeParameter = new SqlParameter("User", userId);
                myWorkOrders = vtfContext.Database.SqlQuery<WorkOrder>("sp_GetQueueWorkOrders @User", codeParameter).ToList();
            }
            return myWorkOrders;
        }

        /// <summary>
        /// Update the work order service status.
        /// </summary>
        /// <param name="serviceVO">Service object.</param>
        /// <returns>WorkOrder service with updated status.</returns>
        public WorkOrderServiceVO UpdateWorkOrderServiceStatus(WorkOrderServiceVO serviceVO)
        {
            WorkOrderServiceVO workOrderService;
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
                var serviceIDParameter = new SqlParameter("WorkOrderServiceID", serviceVO.WorkOrderServiceId);
                var statusParameter = new SqlParameter("Status", serviceVO.Status);
                var userParameter = new SqlParameter("UserID", serviceVO.CreatedBy);

                workOrderService = vtfContext.Database.SqlQuery<WorkOrderServiceVO>("sp_UpdateWorkOrderServiceStatus @workOrderServiceID, @Status, @UserID ", serviceIDParameter, statusParameter, userParameter).First();
            }
            return workOrderService;
        }

        /// <summary>
        /// Update the work order status.
        /// </summary>
        /// <param name="workOrderVO">work order object.</param>
        /// <returns>WorkOrder with updated status.</returns>
        public WorkOrderDetailsVO UpdateWorkOrderStatus(WorkOrderDetailsVO workOrderVO)
        {
            WorkOrderDetailsVO workOrder;
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
                var workOrderIDParameter = new SqlParameter("WorkOrderID", workOrderVO.WorkOrderId);
                var statusParameter = new SqlParameter("Status", workOrderVO.Status);
                var userParameter = new SqlParameter("UserID", workOrderVO.UserID);

                workOrder = vtfContext.Database.SqlQuery<WorkOrderDetailsVO>("sp_UpdateWorkOrderStatus @workOrderID, @Status, @UserID ", workOrderIDParameter, statusParameter, userParameter).First();
            }
            return workOrder;
        }
    }
}
