﻿using System.Collections.Generic;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.ValueObject;
using System;

namespace Capgemini.GroupProduction.GIS.RepositoryInterface
{
    /// <summary>
    /// Service Management Interface
    /// </summary>
    public interface IWorkorderManagementDO
    {
        /// <summary>
        /// Search Engagement Codes
        /// </summary>
        /// <returns></returns>
        IEnumerable<EngagementCodeVO> SearchEngagementCodes(string searchKeyword);

        /// <summary>
        /// Get Work Order details with engagement details
        /// </summary>
        /// <param name="engmtCode"></param>
        /// <param name="woroOrderId"></param>
        /// <returns></returns>
        WorkOrderDetailsVO GetWorkOrderDetails(string engmtCode, Int64 woroOrderId);
        
        /// <summary>
        /// Get Service List
        /// </summary>
        /// <param name="serviceId"></param>
        /// <returns></returns>
        IEnumerable<ServiceMasterVO> GetServiceList(int serviceId);

        /// <summary>
        /// Get Service List
        /// </summary>
        /// <param name="serviceId"></param>
        /// <returns></returns>
        IEnumerable<ServiceMasterVO> GetServiceList(IEnumerable<int> serviceIds);

        /// <summary>
        /// Add Work Order Details
        /// </summary>
        /// <param name="workOrderDetails"></param>
        /// <returns></returns>
        Int64 AddWorkOrderDetails(WorkOrder workOrderDetails);

        /// <summary>
        /// Add Work Order Service Details
        /// </summary>
        /// <param name="workOrderServiceDetails"></param>
        /// <param name="workOrderId"></param>
        /// <returns></returns>
        WorkOrderServiceDetails AddWorkOrderServiceDetails(IEnumerable<WorkOrderService> workOrderServiceDetails);

        IEnumerable<WorkOrderServiceVO> GetServiceByWorkOrderId(Int64 workerId);

        /// <summary>
        /// Get My Work Orders
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        IEnumerable<WorkOrder> GetMyWorkOrders(string userId);

        /// <summary>
        /// Get My Work Orders
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        IEnumerable<WorkOrder> GetQueueWorkOrders(string userId);

        /// <summary>
        /// Update the work order service status.
        /// </summary>
        /// <param name="serviceVO">Service object.</param>
        /// <returns>WorkOrder service with updated status.</returns>
        WorkOrderServiceVO UpdateWorkOrderServiceStatus(WorkOrderServiceVO serviceVO);

        /// <summary>
        /// Update the work order status.
        /// </summary>
        /// <param name="workOrderVO">work order object.</param>
        /// <returns>WorkOrder with updated status.</returns>
        WorkOrderDetailsVO UpdateWorkOrderStatus(WorkOrderDetailsVO workOrderVO);
    }
}
