﻿using System.Collections.Generic;
using Capgemini.GroupProduction.GIS.Database.DBContext;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.RepositoryInterface;
using System.Data.SqlClient;
using System.Linq;
using System;
using System.Data;
using System.IO;
using Capgemini.GroupProduction.GIS.Report.ValueObject;

namespace Capgemini.GroupProduction.GIS.Repository
{
    public class ReportManagementDO : IReportManagementDO
    {
        public ReportManagementDO()
        { 
            
        }
        public IEnumerable<PieChartVO> GetPieChart()
        {
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
                return vtfContext.Database.SqlQuery<PieChartVO>("spWorkOrderVsServiceReport").ToList();
            }
        }

        public IEnumerable<BarChartVO> GetBarChart()
        {
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
                return vtfContext.Database.SqlQuery<BarChartVO>("spWorkOrderVsServiceReport").ToList();
            }
        }

    }
}
