﻿using Capgemini.GroupProduction.GIS.Database.DBContext;
using Capgemini.GroupProduction.GIS.RepositoryInterface;
using Capgemini.GroupProduction.GIS.ServiceNow.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.GIS.Repository
{
    public class ServiceNowManagementDO : IServiceNowManagementDO
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public ServiceNowManagementDO()
        { 
            
        }

        /// <summary>
        /// Update service reference Ids from SNOW to VTF
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="requestNumber"></param>
        /// <param name="workOrderId"></param>
        public void UpdateWorkOrderReferenceIds(string requestId, string requestNumber, Int64 workOrderId)
        {
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
                var requestIdParameter = new SqlParameter("RequestId", requestId);
                var requestNumberParameter = new SqlParameter("RequestNumber", requestNumber);
                var workOrderIdParameter = new SqlParameter("WorkOrderId", workOrderId);
                var result = vtfContext.Database.SqlQuery<int>("sp_UpdateWorkOrderReferenceIds @RequestId, @RequestNumber, @WorkOrderId", requestIdParameter, requestNumberParameter, workOrderIdParameter).First();
            }
        }

        /// <summary>
        /// Update work order reference Ids from SNOW to VTF 
        /// </summary>
        /// <param name="serviceRequestId"></param>
        /// <param name="serviceRequestNumber"></param>
        /// <param name="workOrderId"></param>
        /// <param name="serviceId"></param>
        public void UpdateServiceReferencIds(string serviceRequestId, string serviceRequestNumber, Int64 workOrderId, Int64 serviceId)
        {
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
                var serviceRequestIdParameter = new SqlParameter("ServiceRequestId", serviceRequestId);
                var serviceRequestNumberParameter = new SqlParameter("ServiceRequestNumber", serviceRequestNumber);
                var workOrderIdParameter = new SqlParameter("WorkOrderId", workOrderId);
                var ServiceIdParameter = new SqlParameter("ServiceId", serviceId);
                var result = vtfContext.Database.SqlQuery<int>("sp_UpdateServiceReferencIds @ServiceRequestId, @ServiceRequestNumber, @WorkOrderId, @ServiceId ", serviceRequestIdParameter, serviceRequestNumberParameter, workOrderIdParameter, ServiceIdParameter).First();
            }
        }

        /// <summary>
        /// Reset Work Order Number and other reference Ids if snow push process fails
        /// </summary>
        /// <param name="workOrderId"></param>
        public void ResetWorkOrderReferenceFlags(Int64 workOrderId)
        {
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
                var workOrderIdParameter = new SqlParameter("WorkOrderId", workOrderId);
                var result = vtfContext.Database.SqlQuery<int>("sp_ResetWorkOrderReferencIds @WorkOrderId", workOrderIdParameter).First();
            }
        }

        /// <summary>
        /// Get Snow Instance Details
        /// </summary>
        /// <param name="workOrderId"></param>
        /// <returns></returns>
        public ServiceNowInstance GetServiceNowInstanceDetails(Int64 workOrderId)
        {
            ServiceNowInstance result = null;
            using (VTFBaseContext vtfContext = new VTFBaseContext())
            {
                var factoryIdIdParameter = new SqlParameter("factoryId", -1);
                var workOrderIdParameter = new SqlParameter("WorkOrderId", workOrderId);
                result = vtfContext.Database.SqlQuery<ServiceNowInstance>("sp_GetServiceNowInstance @factoryId, @WorkOrderId ", factoryIdIdParameter, workOrderIdParameter).First();
            }
            return result;
        }
    }
}
