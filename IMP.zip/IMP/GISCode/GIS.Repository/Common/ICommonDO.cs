﻿using Capgemini.GroupProduction.GIS.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.GIS.Repository
{
    /// <summary>
    /// Common bussiness components
    /// </summary>
    public interface ICommonDO
    {
        /// <summary>
        /// Get the message by key. 
        /// </summary>
        /// <param name="messageKey">message key name.</param>
        /// <returns>Custom message details fetched by key name.</returns>
        CustomMessage GetMessage(string messageKey);

        /// <summary>
        /// Get the message collection by group. 
        /// </summary>
        /// <param name="messageGroups">message groups.</param>
        /// <returns>Custom message colection fetched by groups.</returns>
        CustomMessageList GetMessageByGroup(string messageGroups);
    }
}
