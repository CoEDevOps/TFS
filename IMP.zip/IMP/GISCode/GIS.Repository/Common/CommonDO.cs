﻿using Capgemini.GroupProduction.GIS.Database.DBContext;
using Capgemini.GroupProduction.GIS.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.GIS.Repository
{
    /// <summary>
    /// Common bussiness components
    /// </summary>
    public class CommonDO : ICommonDO
    {
        private readonly VTFBaseContext m_VtfDataBaseContext;

        public CommonDO()
        {
            m_VtfDataBaseContext = new VTFBaseContext();                
        }

        /// <summary>
        /// Get the message by key. 
        /// </summary>
        /// <param name="messageKey">message key name.</param>
        /// <returns>Custom message details fetched by key name.</returns>
        public CustomMessage GetMessage(string messageKey)
        {
            var messageKeyParameter = new SqlParameter("MessageKey", messageKey);

            return m_VtfDataBaseContext.Database.SqlQuery<CustomMessage>("[sp_GetMessage] @MessageKey", messageKeyParameter).FirstOrDefault();
    

        }

        /// <summary>
        /// Get the message collection by group. 
        /// </summary>
        /// <param name="messageGroups">message groups.</param>
        /// <returns>Custom message colection fetched by groups.</returns>
        public CustomMessageList GetMessageByGroup(string messageGroups)
        {
            var messageKeyParameter = new SqlParameter("MessageGroups", messageGroups);
            var msgList = m_VtfDataBaseContext.Database.SqlQuery<CustomMessage>("[sp_GetMessageByGroups] @MessageGroups", messageKeyParameter).ToList();
            CustomMessageList customMsgList = new CustomMessageList(msgList);
            return customMsgList;


        }
    }
}
