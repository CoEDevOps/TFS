﻿using System.Web.Mvc;
using System.Web.Mvc.Html;


namespace Capgemini.GroupProduction.GIS.Web.Helpers
{
    /// <summary>
    /// Menu extension.
    /// </summary>
    public static class MenuExtensions
    {
        /// <summary>
        /// MenuItem
        /// </summary>
        /// <param name="htmlHelper"></param>
        /// <param name="text"></param>
        /// <param name="action"></param>
        /// <param name="controller"></param>
        /// <param name="menuOrder"></param>
        /// <param name="selectedMenu"></param>
        /// <returns></returns>
        public static MvcHtmlString MenuItem(this HtmlHelper htmlHelper, string text, string url,int menuOrder, int  selectedMenu)
        {
           // string link = System.Web.Mvc.Html.LinkExtensions.ActionLink(htmlHelper, text, action, controller).ToHtmlString();
            var li = new TagBuilder("li");
            
            var anchor = new TagBuilder("a");

            if (text.Contains("Contact Us"))
               anchor.Attributes["href"] =  "#";
            else
              anchor.Attributes["href"] = "/" + url;
            
            if (selectedMenu == menuOrder)
            {
                anchor.AddCssClass("selected");               
            }

            anchor.SetInnerText(text);
            li.InnerHtml = anchor.ToString();
            return MvcHtmlString.Create(li.ToString());
        }
    }
}