﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace Capgemini.GroupProduction.GIS.Web.Helpers
{
    public static class JsGlobalVariableExtension
    {
       
        public static MvcHtmlString GlobalJSVariable(this HtmlHelper htmlHelper)
        {
            var script = new TagBuilder("script");
            script.Attributes.Add("type", "text/javascript");

            StringBuilder sb = new StringBuilder();
            sb.Append("window.VTF = {};");           
            sb.AppendFormat("window.VTF.JSVersion = {0};", System.Configuration.ConfigurationManager.AppSettings["JSVersion"].ToString());
            sb.AppendFormat("window.VTF.currentUICulture = '{0}';", Thread.CurrentThread.CurrentUICulture.Name);
            sb.AppendFormat("window.VTF.shortDatePatternUICulture = '{0}';", Thread.CurrentThread.CurrentUICulture.DateTimeFormat.ShortDatePattern);

            script.InnerHtml = sb.ToString();

            return MvcHtmlString.Create(script.ToString());
        }
    }
}