﻿using Capgemini.GroupProduction.GIS.Entity;
using System;
using System.Configuration;
using System.DirectoryServices;

namespace Capgemini.GroupProduction.GIS.Web.Helpers
{
    /// <summary>
    /// LDAP autentication of the logged in user.
    /// </summary>
    public class LDAPAuthention
    {        
        private string m_ldapUrl;

        /// <summary>
        /// 
        /// </summary>
        public LDAPAuthention()
        {
            m_ldapUrl = ConfigurationManager.AppSettings.Get("LDAPUrl");
        }



        /// <summary>
        /// LDAP Authentication
        /// </summary>       
        /// <returns>User ldap information of the logged in User.</returns>
        public User LDAPAuthenticate()
        {
            User user = new User();
            string userName = CurrentUser.Split('\\')[1];

            if (!string.IsNullOrEmpty(userName))
            {

                string strFname = string.Empty;
                string strLname = string.Empty;
                string strEmail = string.Empty;
                DirectoryEntry entry = new DirectoryEntry(m_ldapUrl);
                object obj = entry.NativeObject;
                DirectorySearcher search = new DirectorySearcher(entry);
                search.Filter = "(SAMAccountName= " + userName + ")";
                search.PropertiesToLoad.Add("cn");
                SearchResult result = search.FindOne();
                DirectoryEntry dsresult = result.GetDirectoryEntry();
                strFname = Convert.ToString(dsresult.Properties["givenName"][0]);
                strLname = Convert.ToString(dsresult.Properties["sn"][0]);
                strEmail = Convert.ToString(dsresult.Properties["mail"][0]);
                // user = m_userRepository.AddUser(userName, strFname + " " + strLname, strEmail);
                user.Name = strFname + " " + strLname;
                user.UserName = userName;
                user.Email = strEmail;
            }
            return user;
        }

        /// <summary>
        /// Windows user name of the logged in user.
        /// </summary>
        public string CurrentUser
        {
            get

            {
#if DEBUG
                return "IGATECORP\\vinijais";
#else
                return System.Web.HttpContext.Current.Request.ServerVariables.Get("LOGON_USER"); 
#endif
            }
        }
    }
}