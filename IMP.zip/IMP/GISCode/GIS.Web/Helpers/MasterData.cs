﻿using Capgemini.GroupProduction.GIS.Common;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.Web.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Capgemini.GroupProduction.Base.Web.Helpers
{
    public class MasterData : IMasterData
    {
        public IEnumerable<RoleAccess> GetRoleAccess(long userID)
        {
             HttpClientHelper m_clientHelper = new HttpClientHelper();
             return m_clientHelper.GetDataFromApi<IEnumerable<RoleAccess>>("/UserManagement/AllRoleAccess/" + userID);
        }
    }
}