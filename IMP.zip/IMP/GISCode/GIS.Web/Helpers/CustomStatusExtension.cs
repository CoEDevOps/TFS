﻿using Capgemini.GroupProduction.GIS.Common;
using Capgemini.GroupProduction.GIS.Entity;
using System.Collections.Generic;
using System.Web.Mvc;

namespace Capgemini.GroupProduction.GIS.Web.Helpers
{
    /// <summary>
    /// Custom Status control.
    /// </summary>
    public static class CustomStatusExtension
    {


       /// <summary>
       /// Display status helper.
       /// </summary>
       /// <param name="htmlHelper">helper object.</param>
       /// <param name="customStatusType">Type status.</param>
       /// <param name="status">status</param>
       /// <param name="showText">If true then show status text.</param>
       /// <returns>Html string of the div control.</returns>
        public static MvcHtmlString DispayStatus(this HtmlHelper htmlHelper, StatusType customStatusType, int status, bool showText)
        {
            var divOuter = new TagBuilder("div");

            if (customStatusType == StatusType.Service)
            {
                var serviceStatus = (ServiceStatus)status;
                var servideStatusStr = serviceStatus.ToString().Replace("_", " ");

                string strClassName = "grid-service-pending";
                switch (serviceStatus)
                {
                    case ServiceStatus.Work_in_Progress:                    
                        strClassName = "grid-service-waiting";
                        break;
                    case ServiceStatus.Completed:
                        strClassName = "grid-service-delivered";
                        break;
                    default:
                        strClassName = "grid-service-pending";
                        break;
                }

                RenderInnerDiv(divOuter, strClassName, servideStatusStr, showText);
                             
            }
            else
            {
                var worOrderStatus = (WorkorderStatus)status;
                var workOrderStatusStr = worOrderStatus.ToString().Replace("_", " ");

                string strClassName = "grid-service-pending";
                switch (worOrderStatus)
                {
                    case WorkorderStatus.Cancelled:
                    case WorkorderStatus.Failed:  
                       strClassName = "grid-service-waiting";
                        break;
                    case WorkorderStatus.Completed:
                        strClassName = "grid-service-delivered";
                        break;
                    default:
                        strClassName = "grid-service-pending";
                        break;
                }

                RenderInnerDiv(divOuter, strClassName, workOrderStatusStr, showText);
               
            }

            return MvcHtmlString.Create(divOuter.ToString());
        }

        /// <summary>
        /// Render the inner div with text.
        /// </summary>
        /// <param name="divOuter">Outer div object.</param>
        /// <param name="strClassName">style class name.</param>
        /// <param name="strStatus">Status text name.</param>
        /// <param name="showText">If true then show status text.</param>
        private static void RenderInnerDiv(TagBuilder divOuter, string strClassName, string strStatus, bool showText)
        {
            var divIcon = new TagBuilder("div");
            divIcon.AddCssClass(strClassName);
            divIcon.Attributes.Add(new KeyValuePair<string, string>("title", strStatus));
            divIcon.InnerHtml = "&nbsp;";

            if (showText)
            {
                var divText = new TagBuilder("div");
                divText.SetInnerText(strStatus);
                divText.AddCssClass("grid-status");
                divOuter.InnerHtml = divIcon.ToString(TagRenderMode.Normal) + divText.ToString(TagRenderMode.Normal);

            }
            else
            {
                divOuter.InnerHtml = divIcon.ToString(TagRenderMode.Normal);
            }
        }
    }
}