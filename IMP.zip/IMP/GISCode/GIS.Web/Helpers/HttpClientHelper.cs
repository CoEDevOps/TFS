﻿using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Configuration;
using System.Web;
using System.Linq;
using Capgemini.GroupProduction.GIS.Common;

namespace Capgemini.GroupProduction.GIS.Web.Helpers
{
    /// <summary>
    /// Helper class to connect to the client.
    /// </summary>
    public class HttpClientHelper
    {
        private string m_baseApiUrl;
        private string m_baseApiDomainName;
        private TimeSpan m_TimeOut;
       // private string m_sessionID;

        /// <summary>
        /// 
        /// </summary>
        public HttpClientHelper()
        {
            m_baseApiUrl = ConfigurationManager.AppSettings["baseApiUrl"];
            
            string[] domainArray = m_baseApiUrl.Split('/');
            if (domainArray.Length > 2)
            {
                string domainServer = domainArray[2].Split(':')[0];
                m_baseApiDomainName = domainServer;
            }

            m_TimeOut = System.TimeSpan.FromMilliseconds(1800000);
          //  m_sessionID = HttpContext.Current.Session.SessionID;
        }

        public string BaseApiUrl
        {
            get
            {
                return m_baseApiUrl;
            }
        }

        public string BaseApiDomainName
        {           
            get
            {
                return m_baseApiDomainName;
            }
        }

        /// <summary>
        /// Get the the data from WebApi.
        /// </summary>        
        /// <param name="url">Base Api url to connect.</param>
        /// <param name="appendSession">Append session id in request.</param>
        /// <returns>Get the HttpResponseMessage from WebApi.</returns>
        public HttpResponseMessage GetDataFromApi(string url, bool appendSession = true)
        { 
            var responseMessage = GetReponseMessage(m_baseApiUrl + url, appendSession);      

            return responseMessage;         

        }


        /// <summary>
        /// Get the the data from WebApi.
        /// </summary>
        /// <typeparam name="T">HttpResponseMessage of Type T from WebApi.</typeparam>
        /// <param name="url">Base Api url to connect.</param>
        /// <param name="appendSession">Append session id in request.</param>
        /// <returns>Get the HttpResponseMessage from WebApi.</returns>
        public T GetDataFromApi<T>(string url, bool appendSession = true) where T : class
        {
            var responseMessage = GetReponseMessage(m_baseApiUrl + url, appendSession);

            return responseMessage.Content.ReadAsAsync<T>().Result;  

        }

        /// <summary>
        /// Get the the data from Url.
        /// </summary>
        /// <typeparam name="T">HttpResponseMessage of Type T from Url.</typeparam>
        /// <param name="url">Base Api url to connect.</param>
        /// <param name="appendSession">Append session id in request.</param>
        /// <returns>Get the HttpResponseMessage from WebApi.</returns>
        public T GetDataFromAbsoulteUrl<T>(string url, bool appendSession = true) where T : class
        {
            var responseMessage = GetReponseMessage(url, appendSession);

            return responseMessage.Content.ReadAsAsync<T>().Result;

        }

        /// <summary>
        ///  Add session cookie in handler.
        /// </summary>
        /// <param name="url">Url of the request.</param>
        /// <returns></returns>
        private HttpClientHandler AddSessionCookie(string url)
        {
            CookieContainer cookies = new CookieContainer();
            HttpClientCookie httpCookie = new HttpClientCookie();
            string value = HttpContext.Current.Session.SessionID;           
           
            /* VN2: 
             * Need to change as per the URL domain Name  
             */
            //string[] domainArray = ConfigurationManager.AppSettings["baseApiUrl"].Split('/');
            
            cookies.Add(httpCookie.CreateSessionCookie(value, m_baseApiDomainName));

            Int64 userID = Convert.ToInt64(HttpContext.Current.Session["UserID"]);
            string roleIdsArray = string.Empty;
            if(HttpContext.Current.Session["RoleIDs"] != null)
            {
                roleIdsArray = HttpContext.Current.Session["RoleIDs"].ToString();
            }

           /* moCookie = new Cookie("userid", Convert.ToString(HttpContext.Current.Session["UserID"]));
            moCookie.Domain = domainServer;
            cookies.Add(moCookie);
            */
            string userToken = userID + "_" + roleIdsArray;            
            cookies.Add(httpCookie.CreateApiUserTokenCookie(EncyrptDecrypt.Encrypt(userToken, false),
                m_baseApiDomainName));

            HttpClientHandler handler = new HttpClientHandler();
            handler.CookieContainer = cookies;

            return handler;
        }

        /// <summary>
        /// Post datat to the WebApi.
        /// </summary>
        /// <typeparam name="PType">Type of data to post WebApi.</typeparam>       
        /// <param name="url">Url</param>
        /// <param name="postData">data to post WebApi.</param>
        /// <param name="appendSession">Append session id in request.</param>
        /// <returns>return HttpResponseMessage</returns>
        public HttpResponseMessage PostDataToApi<PType>(string url, PType postData, bool appendSession = true)
        {
            var responseMessage = PostReponseMessage(m_baseApiUrl + url, postData, appendSession);    

            return responseMessage;
        }

        /// <summary>
        /// Post datat to the WebApi.
        /// </summary>
        /// <typeparam name="PType">Type of data to post WebApi.</typeparam>
        /// <typeparam name="T">Type of data from WebApi.</typeparam>
        /// <param name="url">Url</param>
        /// <param name="postData">data to post WebApi.</param>
        /// <param name="appendSession">Append session id in request.</param>
        /// <returns>return HttpResponseMessage of type T.</returns>
        public T PostDataToApi<PType, T>(string url, PType postData, bool appendSession = true)
        {
            var responseMessage = PostReponseMessage(m_baseApiUrl + url, postData, appendSession);    

            return responseMessage.Content.ReadAsAsync<T>().Result;  
        }


        /// <summary>
        /// Get the Response message
        /// </summary>
        /// <param name="url">url of the httpmessage.</param>
        /// <param name="appendSession">Append session id in request.</param>
        /// <returns>HttpResponseMessage </returns>
        private HttpResponseMessage GetReponseMessage(string url, bool appendSession)
        {
            HttpClient client = CreateHttpClient(url, appendSession);

            var response = client.GetAsync(url);

            return response.Result;  
        }

        /// <summary>
        /// Post data to the WebApi.
        /// </summary>       
        /// <typeparam name="PType">Type of data from WebApi.</typeparam>
        /// <param name="url">Url</param>
        /// <param name="postData">data to post WebApi.</param>
        /// <param name="appendSession">Append session id in request.</param>
        /// <returns>return HttpResponseMessage.</returns>
        private HttpResponseMessage PostReponseMessage<PType>(string url, PType postData, bool appendSession)
        {
            HttpClient client = CreateHttpClient(url, appendSession);

            var responseMessage = client.PostAsJsonAsync<PType>(
                 url, postData
                 ).Result;

            return responseMessage;
        }

        /// <summary>
        /// Creates the HttpClient.
        /// </summary>
        /// <param name="url">Url</param>
        /// <param name="appendSession">Append session id in request.</param>
        /// <returns></returns>
        private HttpClient CreateHttpClient(string url, bool appendSession)
        {
            string sessionID = HttpContext.Current.Session.SessionID;
            HttpClient client = null;
            if (!appendSession || sessionID == null || sessionID.Length == 0)
            {
                client = new HttpClient();
            }
            else 
            {
                client = new HttpClient(AddSessionCookie(url));
            }

            //client.Timeout = new System.TimeSpan(600000); 
            //Time out 3 min
            client.Timeout = m_TimeOut;            

            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            return client;

        }
    }
}