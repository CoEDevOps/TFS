﻿using Capgemini.GroupProduction.GIS.Entity.ServiceManagement;
using System;
using System.Configuration;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.SessionState;
using System.Linq;
using Capgemini.GroupProduction.GIS.Web.Helpers;
using Capgemini.GroupProduction.GIS.Common;
using System.Collections.Generic;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.Base.Web.Helpers;

namespace Capgemini.GroupProduction.GIS.WebApi.Handler
{
    /// <summary>
    /// Summary description for FileUploader
    /// </summary>
    public class FileUploader : IHttpHandler, IRequiresSessionState
    {
        private int m_startIndex = 0;
        private string m_uploadPath;
        private string m_redirectUrl = "~/WorkOrderManagement/UploadStatus";
        private string m_endExpression = string.Empty;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public void ProcessRequest(HttpContext context)
        {
            m_uploadPath = ConfigurationManager.AppSettings["FileUploadPath"].ToString();

            context.Response.ContentType = "text/HTML";

            //Unathorixed cannot upload.
            Int64 userID = Convert.ToInt64(context.Session["UserID"]);
            if(context.Session["UserID"] == null)
            {
                //context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;                 
                HttpContext.Current.Response.Redirect(m_redirectUrl + "?status=5");
                return;
            }

            string roleIds = (string)context.Session["RoleIds"];
            User user = new User();
            user.UserID = userID;
            user.RoleIds = roleIds;
            UserAuthorization urlAuthorization = new UserAuthorization(user);
            IEnumerable<RoleAccess> roleAccess = MemCacheHelper.GetAllRoleAccess(userID, new MasterData());

            string[] fileUploadUrl = context.Request.Url.AbsoluteUri.Split('/');

            if (!urlAuthorization.IsUrlAuthorized(fileUploadUrl[fileUploadUrl.Length - 1], roleAccess))
            {
                //context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;                 
                HttpContext.Current.Response.Redirect(m_redirectUrl + "?status=6");
                return;
            }

            IServiceProvider provider = (IServiceProvider)context;
            HttpWorkerRequest _workerRequest = (HttpWorkerRequest)provider.GetService(
                typeof(HttpWorkerRequest));

            HttpContext downloadContext = HttpContext.Current;
           
            FileStream fStream = null;           
            try
            {
                // Check if body contains data

                if (_workerRequest.HasEntityBody())
                {
                    // get the total body length
                    int requestLength = _workerRequest.GetTotalEntityBodyLength();
                   
                    /*if (downloadContext.Session["UserID"] == null)
                    {
                        //downloadContext.Response.Redirect()
                        downloadContext.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                        downloadContext.Response.Write("Invalid Request");
                        return;

                    }*/

                    UploadFile uploadFile = null;

                    if (!_workerRequest.IsEntireEntityBodyIsPreloaded())
                    { 
                        string zipFileName = string.Empty;
                        string originalZipName = string.Empty;

                       
                        // Set the received bytes to initial bytes before start reading
                        int receivedBytes, bytesToRead;
                        receivedBytes = _workerRequest.GetPreloadedEntityBodyLength();
                        if (receivedBytes > 0)
                        {
                            byte[] preloadedBytes = _workerRequest.GetPreloadedEntityBody();

                            uploadFile = GetFileUploadInfo(preloadedBytes, Encoding.UTF8, downloadContext.Request);
                           
                            if(!ValidateFile(uploadFile, downloadContext.Response))
                            {                               
                                return;
                            }
                           
                            //Need to add validation for ProjectID and UserID
                            SetFileStream(preloadedBytes, uploadFile, out fStream);                           
                        }                       

                        while (requestLength > receivedBytes)
                        {
                            byte[] buffer = new byte[512000];

                            /* When client browser is not active that means the user has clsoed the browser
                             * so the upload is not complete. So in this case close the file and break.
                             */
                            if (!_workerRequest.IsClientConnected())
                            {
                                string path = m_uploadPath + "\\" + uploadFile.FileName;
                                if (File.Exists(path))
                                {
                                    File.Delete(path);
                                }
                                break;
                            }

                            bytesToRead = requestLength - receivedBytes;
                            int bytesRead;
                            if (bytesToRead <= buffer.Length)
                            {
                                bytesRead = _workerRequest.ReadEntityBody(buffer, bytesToRead); 
                            }
                            else
                            {
                                bytesRead = _workerRequest.ReadEntityBody(buffer, buffer.Length);
                            }                            

                            // Write the chunks to the physical file
                            fStream.Write(buffer, 0, bytesRead);
                            fStream.Flush();
                            // Update the received bytes
                            receivedBytes += bytesRead;
                        }
                      
                        if (!_workerRequest.IsClientConnected())
                        {
                            return;
                        }

                        fStream.SetLength(fStream.Length - m_endExpression.Length - 2);
                        fStream.Close();
                      
                        downloadContext.Response.Redirect(m_redirectUrl + "?status=4&disfileName=" +uploadFile.DisplayFileName + "&fileName=" + uploadFile.FileName);   
                    }
                    else
                    {
                        //in case the body is fully preloaded                 
                        int receivedBytes = _workerRequest.GetPreloadedEntityBodyLength();
                        byte[] preloadedBytes = _workerRequest.GetPreloadedEntityBody();
                        uploadFile = GetFileUploadInfo(preloadedBytes, Encoding.UTF8, downloadContext.Request);
                       
                        if(!ValidateFile(uploadFile, downloadContext.Response))
                        {                            
                            return;
                        }

                        SetFileStream(preloadedBytes , uploadFile, out fStream);
                        fStream.SetLength(fStream.Length - m_endExpression.Length - 2);
                        fStream.Close();
                        fStream = null;                       
                        if (!_workerRequest.IsClientConnected())
                        {
                            return;
                        }

                        downloadContext.Response.Redirect(m_redirectUrl + "?status=4&disfileName=" + uploadFile.DisplayFileName + "&fileName=" + uploadFile.FileName);     
   
                    }
                }
            }
            finally
            {
                if (fStream != null)
                {
                    fStream.Close();
                    fStream = null;
                }
            }
        }


        private bool ValidateFile(UploadFile uploadFile, HttpResponse response)
        {

            if (uploadFile.DisplayFileName == null || uploadFile.DisplayFileName.Length == 0)
            {
                response.Write("Please select file");
                //response.Redirect(m_redirectUrl + "?status=1");                
                return false;
            }

            var filetypes = uploadFile.FileType.Split(',').Select(x => x.Trim());

            var acceptedFileTypes = filetypes.FirstOrDefault(x => uploadFile.FileName.IndexOf(x) != -1);

            if (acceptedFileTypes == null)
            {
                response.Write("File type not valid");
                //response.Redirect(m_redirectUrl + "?status=3");
                return false;
            }


            int maxFileInMB = int.Parse(ConfigurationManager.AppSettings["MaxFileSize"]);
            var limitSize = maxFileInMB * 1024 * 1024;

            if (uploadFile.FileSize > limitSize)
            {               
               //response.Redirect(m_redirectUrl + "?status=2");            
                response.Write(string.Format("File size should be less than {0} MB", maxFileInMB));
                
               return false;
            }            
            return true;
           
        }

        private UploadFile GetFileUploadInfo(byte[] data, Encoding encoding, HttpRequest request)
        {
            //UploadFileInfo
            //Content-Range: bytes 0-102400/202042694

            UploadFile uploadFile = new UploadFile();
            // Copy to a string for header parsing
            string content = encoding.GetString(data);

            // Look for Content-Type
            // Content-Type: application/x-zip-compressed
            Regex re = new Regex(@"(?<=Content\-Type:)(.*?)(?=\r\n\r\n)");
            Match contentTypeMatch = re.Match(content);
            m_startIndex = contentTypeMatch.Index + contentTypeMatch.Length + "\r\n\r\n".Length;  

            //Content-Disposition: form-data; name="zipUpload"; filename="FileName.zip"
            re = new Regex(@"(?<=filename\=\"")(.*?)(?=\"")");
            Match filenameMatch = re.Match(content);
            string[] zipFileNames = filenameMatch.Value.Split('\\');
                             
            string zipFileName = Guid.NewGuid().ToString() + "_" + zipFileNames[zipFileNames.Length - 1];

           // m_endExpression = @"(?<=-----)(.*?)(?=\r\n)";

            m_endExpression = @"\r\n" + content.Substring(0, content.IndexOf("\r\n"));

            //Regex endLength = new Regex(m_endExpression);
            //Match endLengthMtach = endLength.Match(content);

          //  int endIndex = 0;
           // endIndex = conte endLengthMtach.Index;  
           
            uploadFile.DisplayFileName = zipFileNames[zipFileNames.Length - 1];
            uploadFile.FileName = zipFileName;
            uploadFile.FileSize = request.ContentLength - m_startIndex - m_endExpression.Length - 2;
            uploadFile.FileType = ConfigurationManager.AppSettings["FileType"].ToString();
            return uploadFile;

        }


        private void SetFileStream(byte[] data, UploadFile uploadFile, out FileStream fStream)
        {
            fStream = null;

            // Did we find the required values?
            if (m_startIndex != -1)
            {
                int contentLength = data.Length - m_startIndex;
                string uploadPath = m_uploadPath;

                string path = uploadPath + "\\" + uploadFile.FileName;

                if (File.Exists(path))
                {
                    fStream = new FileStream(path, FileMode.Append);
                }
                else
                {
                    fStream = new FileStream(path, FileMode.OpenOrCreate);
                }

                if (fStream.Length < uploadFile.FileSize)
                 fStream.Write(data, m_startIndex , contentLength);
                
                fStream.Flush();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}