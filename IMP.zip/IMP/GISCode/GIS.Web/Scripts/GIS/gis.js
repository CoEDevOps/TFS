﻿
(function () {

    var GISMain = (function () {
        
        function GISMain() {
            var self = this;
            $(document).ready(function () {
                self.initialize();
            });
        };

        //Initialise
        GISMain.prototype.initialize = function () {
            var self = this;
            //left  menu item click
            self.lnkAutomation = $("#lnkAutomation");
            self.lnkVTF = $("#lnkVTF");
            self.lnkPTF = $("#lnkPTF");
            self.lnkPTF = $("#lnkPTF");

            //Read more item click
            self.lnkAutomationRM = $("#lnkAutomationRM");
            self.lnkVTFRM = $("#lnkVTFRM");
            self.lnkPTFRM = $("#lnkPTFRM");            

            //left menu list items
            self.liAutomation = $("#liAutomation");
            self.liVTF = $("#liVTF");
            self.lnkPTF = $("#lnkPTF");          
            
            //send mail
            self.qSendMail = $("#btnSendMail");

            //Set Target Urls
            self.setTargetUrls();

            //Set Mouseover
            self.setMouseOver();

            //self.validateForm();
            
        };

        GISMain.prototype.setTargetUrls = function () {
            var self = this;
            self.lnkAutomation.on("click",
               function () {
                   self.setTargetUrl(window.GIS.AutomationUrl);
               });

            self.lnkVTF.on("click",
               function () {
                   self.setTargetUrl(window.GIS.VTFUrl);
               });

            self.lnkPTF.on("click",
               function () {
                   self.setTargetUrl(window.GIS.PTFUrl);
               });

            self.lnkAutomationRM.on("click",
               function () {
                   self.setTargetUrl("/GISManagement/About/2");
               });

            self.lnkVTFRM.on("click",
               function () {
                   self.setTargetUrl("/GISManagement/About/3");
               });

            self.lnkPTFRM.on("click",
               function () {
                   self.setTargetUrl("/GISManagement/TaskForceCaseStudies/");
               });

            //self.qSendMail.on("click",
            //    function () {
            //        GISMain.prototype.getInTouch();
            //    });
                        
            self.qSendMail.attr('href', self.getInTouch());            

        };

        GISMain.prototype.setMouseOver = function () {
            var self = this;
            self.liAutomation.mouseover(function () {
                window.GIS.GISCarousel.moveToSlide(0);
            });
            self.liVTF.mouseover(function () {
                window.GIS.GISCarousel.moveToSlide(1);
            });
            self.lnkPTF.mouseover(function () {
                window.GIS.GISCarousel.moveToSlide(2);
            });
        };
        //form validate
        GISMain.prototype.validateForm = function () {

             $("#frmquery").validate({               
                rules: {
                    txtname: {                        
                        required: true
                    },
                    txtemail: {
                        required: true,
                        email: true
                    }
                },
                highlight: function (element) {
                    $(element).closest('.form-group').addClass('has-error');
                },
                unhighlight: function (element) {
                    $(element).closest('.form-group').removeClass('has-error');
                },
                errorPlacement: function (error, element) {
                }
            });
        };

        GISMain.prototype.getInTouch = function () {

            //if ($('#frmquery').valid() == true) {
                
                //var qName = $("#txtname");
                //var qEmail = $("#txtemail");
                //var qDescription = $("#txtdesc");
                //var sub = "GIS query from " + qName.val();
                //var wnd = window.open('mailto:' + window.GIS.ContactToAdd + '?subject=' + sub + '&body=' + qDescription.val() + '');
                //qName.val("");
                //qEmail.val("");
                //qDescription.val("");
                //setTimeout(function () {
                //    if (wnd != undefined) {
                //        wnd.close();
                //    }
                //}, 0);
            //}
            //return false; //avoid posting form

            //var qName = $("#txtname");
            //var qEmail = $("#txtemail");
            //var qDescription = $("#txtdesc");
            //var sub = "GIS query from " + qName.val();
            return "mailto:" + window.GIS.ContactToAdd;
        };

        GISMain.prototype.setTargetUrl = function (url) {            
            document.location.href = url;
        };

        return GISMain;

    })();

    window.GIS.GISMain = new GISMain();

})();

