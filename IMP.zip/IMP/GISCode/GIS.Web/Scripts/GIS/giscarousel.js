﻿//Resize left menu based on size of carousel image
window.GIS.Resize = (function () {
    //$('#dvleftmenu').find('#wrapper').css('height', $('#dvimg').innerHeight());
    $('#dvleftmenu').find('#sidebar-wrapper').css('height', $('#dvimg').innerHeight());
    //$('#dvleftmenu').find('#sidebar-wrapper').css('height', $('#dvmenubanner').innerHeight());    
    var height = parseInt($('#dvimg').innerHeight()) / 3;
    $('#ulleftmenuItems').find('#liAutomation').css('height', height.toString() + "px");
    $('#ulleftmenuItems').find('#liVTF').css('height', height.toString() + "px");
    $('#ulleftmenuItems').find('#lnkPTF').css('height', height.toString() + "px");
});

(function () {
    
    var GISCarousel = (function () {

        function GISCarousel() {
            var self = this;
            $(document).ready(function () {                
                self.initialize();
            });
        };
        
        GISCarousel.prototype.initialize = function () {
            var self = this;
            self.objCorousel = $("#myCarousel");
            self.objCorousel.carousel({
                interval: false
            });
        };

        
        GISCarousel.prototype.moveToSlide = function (slideNumber) {
            var self = this;
            self.objCorousel.carousel(slideNumber);
            
        };

        GISCarousel.prototype.moveNext = function () {
            var self = this;
            self.objCorousel.carousel("next");

        };

        GISCarousel.prototype.movePrev = function () {
            var self = this;
            self.objCorousel.carousel("prev");

        };          

        return GISCarousel;

    })();
    
    window.GIS.GISCarousel = new GISCarousel();

    //Resize left manu after first load
    window.GIS.Resize();

})();


$(window).resize(function () {    
    window.GIS.Resize();
});

