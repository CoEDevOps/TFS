﻿
(function () {

    var UploadFile = (function () {


        function UploadFile() {

            var self = this;
           /* requirejs(['../Common/commonconfig'], function () {
                //the jquery.alpha.js and jquery.beta.js plugins have been loaded.
                requirejs(['jquery'], function () {
                    $(document).ready(function () {
                        self.initialize();
                    });
                });
            });*/

            $(document).ready(function () {
                self.initialize();
            });

        };

        UploadFile.prototype.initialize = function () {
            var self = this;
            var previousfile = self.getParameterByName('previousfile');
            self.btnSubmit = $("#btnUploadFile");
            self.cntrlFile = $("#fileZipProject");
            self.uploadStarted = false;
           // $("#hdnPreviousFile").val(previousfile);

            self.btnSubmit.on("click",
                function () {
                    return self.validateFile();
                });
        };

        UploadFile.prototype.getParameterByName = function (name, url) {
            if (!url) url = window.location.href;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        };

        UploadFile.prototype.validateFile = function () {
            var self = this;
            var filename = self.cntrlFile.val();
           
            if (filename == '') {
                $("#lblerror").text('Please select file');
                return false;
            }
            self.uploadStarted = true;
            return true;
        };

        return UploadFile;
    })();
       

    window.VTF.UploadFile = new UploadFile();
    

})();

//hind overlay on close
window.onunload = function() {    
    $("#dvoverlay", window.opener.document).empty();
}

//close file upload popup when clicked outside
window.onblur = function () {
    if (window.VTF.UploadFile.uploadStarted == false) {
        //window.top.close();
    }   
};


