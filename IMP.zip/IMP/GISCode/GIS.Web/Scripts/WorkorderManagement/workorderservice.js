﻿//Global Variable
(function () {

    var WorkOrderService = (function () {
        
        function WorkOrderService(serviceform, postForm) {
            var self = this;
           /* requirejs(['../Common/commonconfig'], function () {                
                requirejs(['servicedialog'], function () {
                    $(document).ready(function () {
                        self.initialize(serviceform, postForm);
                    });
                });
            });*/

            $(document).ready(function () {
                self.initialize(serviceform, postForm);
            });
        };

        //Initialise
        WorkOrderService.prototype.initialize = function (serviceform, postForm) {
            var self = this;

            //load the custom messages.
            window.VTF.CustomMessage.loadmessages();

            self.content = $("#content");
            self.btnNext = self.content.find("#btnNext");
            self.errMsg = self.content.find("#errorMessage");           
            self.serviceform = self.content.find("#" + serviceform);
            self.postForm = self.content.find("#" + postForm);
            self.valerrormessage = self.content.find("#validationerrorMessage");
            self.dvloading = $("#dvloading");
            self.validatedates = {};
            self.btnNext.on("click",
                function () {
                    self.createWorkOrder();
                });

            self.initializeControls(); 
            //Intialize message 
            var messageFileSize = window.VTF.CustomMessage.MessageList["UploadFileSize"].Message;
            self.messageFileSize = messageFileSize.replace("#@FileSize", VTF.FileSize);

            //Check remark max length 
            $("textarea[maxlength], input[maxlength]").keypress(function (event) {
                var key = event.which;

                //all keys including return.
                if (key >= 33 || key == 13 || key == 32) {
                    var maxLength = $(this).attr("maxlength");
                    var length = this.value.length;
                    if (length >= maxLength) {
                        event.preventDefault();
                    }
                }
            });
        };


        //Initialise delete confirmation dialog on click on grid delete button
        WorkOrderService.prototype.initializeDelDialog = function (obj, indx) {
            var self = this;
            var delDialogCntrl = $("#dialog-confirm");            
            delDialogCntrl.text(window.VTF.CustomMessage.MessageList["ServiceDeletionQuestion"].Message);
            delDialogCntrl.dialog({
                resizable: false,
                height: 140,
                modal: true,
                buttons: [
                   {
                       text: "Delete Service",
                       id: "benDeleteService",
                       "class": "btnbluesmall fontbold",
                       click: function () {
                           self.deleteService(obj, indx);
                           $(this).dialog("close");
                       }
                   },
                   {
                       text: "Cancel",
                       id: "btnCancel",
                       "class": "btnbluesmall fontbold",
                       click: function () {
                           $(this).dialog("close");
                       }
                   }
                ],
                show: {
                    effect: "fade",
                    duration: 800
                },
                hide: {
                    effect: "fade",
                    duration: 400
                }                
            });
        };

        //Initialise child Controls 
        WorkOrderService.prototype.initializeControls = function () {
            var self = this;

            self.url = "/WorkorderManagement/createworkorder";
            //self.grid = $(self.serviceform).find(".grid-mvc").find("tbody");
            self.grid = $(self.serviceform).find(".gtable").find("tbody");
            //self.modelfeatures = 'height=200,width=450,toolbar=no,directories=no,status=no,location=no,menubar=no,scrollbars=no,resizable=no ,modal=yes,left=550,top=200';            
            self.hdnCurrentFile = $(self.serviceform).find(".hdnCurrentFile");
            var startDate = $("#datepickerSt").text();
            var endDate = $("#datepickerEn").text();

            //Register Start Date & End Date controls
            var dt = window.VTF.DateControl;
            //find the date by attribute and register the date control.
            // maintain an "validatedates" array to validate if date is grater then on submit.
            var dateobjs = $(self.grid).find("[date='true']");
            $.each(dateobjs, function (index) { 
                var cmp = $(dateobjs[index]).attr("datetocompare");
                dt.registerControl(dateobjs[index], function () {
                    if (!window.VTF.DateControl.validateOnlyDateFormat(dateobjs[index]))
                    {
                        $(dateobjs[index]).addClass("errormsg");
                    }
                    else
                    {
                        $(dateobjs[index]).removeClass("errormsg");
                    }
                
                });
                //Restrict dates as per work order start and end date
                $(dateobjs[index]).datepicker('option', {
                    minDate: new Date(window.VTF.DateControl.formatMMDDYYYY(startDate)),
                    maxDate: new Date(window.VTF.DateControl.formatMMDDYYYY(endDate))
                });
            });

            self.grid.find('.grid-btnupload').on("click",
                  function (obj) {
                      self.currentUpload = $(obj.currentTarget).next().attr("name");
                      self.hdnCurrentFile.val(self.currentUpload);
                      self.valerrormessage.html('&nbsp;');
                      var gridfilename = $(obj.currentTarget).closest("tr").find('.grid-filename');
                      if (gridfilename) {
                          if (gridfilename.hasClass("errormsg"))
                          {
                              gridfilename.html('&nbsp;');
                              gridfilename.removeClass("errormsg");
                          }
                      }
                      //display overlay
                      $("#dvoverlay").append("<div style='z-index: 100;' class='dvoverlay'><span>File upload dialog is open. It will be closed once upload activity is completed</span><div class=loading></div></div>");
                      self.modelWindow = self.openPopup("/WorkOrderManagement/UploadFile", "ModelUpload", 350, 200);
                      
                  });

            self.grid.find('.grid-btndelete').on("click", function (obj, indx) {
                window.VTF.WorkOrderService.initializeDelDialog(obj, indx);
            });           

            self.grid.find('.grid-btndelupload').on("click", function (obj) {
                $(obj.currentTarget).removeClass("visible");
                $(obj.currentTarget).addClass("hidden");

                self.valerrormessage.html('&nbsp;');

                var gridfilename = $(obj.currentTarget).closest("tr").find('.grid-filename');
                if (gridfilename) {
                    gridfilename.removeClass("errormsg");
                    gridfilename.attr('title', '');
                    var delfile = $(obj.currentTarget).closest("tr").find('.grid-deletefile');
                    delfile.removeClass("grid-deletefile-align-right");
                    delfile.addClass("grid-deletefile-align-left");
                    var divfiletext = gridfilename.html('&nbsp;');                    
                }
                var hidFileName = $(obj.currentTarget).closest("tr").find('.hdnfilename');
                var hidFileDispName = $(obj.currentTarget).closest("tr").find('.hdndisfilename');
                if (hidFileName) {
                    hidFileName.val('');
                }
                if (hidFileDispName) {
                    hidFileDispName.val('');
                }                
            });
            //Register dropdown control
            var lst = window.VTF.SelectMenu;
            lst.registerControl("logtypesddl");

            var lstpriority = window.VTF.SelectMenu;
            lstpriority.registerControl("slpriority");
        };        

        WorkOrderService.prototype.createWorkOrder = function () {
            var self = this;

            var startDate = $("#datepickerSt").text();

            var endDate = $("#datepickerEn").text();

            //To validate client side.
            var isValid = $.validator.unobtrusive.validateForm(self.serviceform);
            var isDateValid = true;
            //var trrows = $(self.grid).find('tr:visible');
            
            self.valerrormessage.removeClass("errormsg");
            self.valerrormessage.html('&nbsp;');

            // Validate ddl remark field
            if ($("#logtypesddl").val() == "") {
                window.VTF.SelectMenu.setError("logtypesddl");
                window.VTF.CustomMessage.displayFromMessageKey(self.errMsg, 'Logtypesddl');
                self.setScrollTop();
                return false;
            }

            // Check text remark special character 
            var remarkregex = /['<>]/gi;
            var remarkstr =  $("#servicetxtremark").val();
            if (remarkregex.test(remarkstr) == true )
            {
                window.VTF.CustomMessage.displayFromMessageKey(self.errMsg, 'RemarkTxtValidate');
                return false;
            }

            // file upload validation
            if ($('.hdndisfilename').val() == "")
            {
                window.VTF.CustomMessage.displayFromMessageKey(self.errMsg, 'FileUploadValidate');
                return false;
            }
            
            if (window.VTF.DateControl.formatYYYYMMDD(endDate) < window.VTF.DateControl.formatYYYYMMDD(startDate)) {
                window.VTF.CustomMessage.displayFromMessageKey(self.errMsg, 'DateIsLessThan');
                window.VTF.DateControl.setError(cntrlEndDate);
                self.setScrollTop();
                return false;
            }

            self.serviceform.submit();
            self.showLoading();

        };

        WorkOrderService.prototype.setScrollTop = function () {
            window.scrollTo(0, 0);
        };

        WorkOrderService.prototype.openPopup = function (url, title, w, h) {
            
            var dualScreenLeft = window.screenLeft != undefined ? window.screenLeft : screen.left;
            var dualScreenTop = window.screenTop != undefined ? window.screenTop : screen.top;

            var width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;
            var height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height;

            var left = ((width / 2) - (w / 2)) + dualScreenLeft;
            var top = ((height / 2) - (h / 2)) + dualScreenTop;
            var newWindow = window.open(url, title, 'toolbar=no,directories=no,status=no,location=no,menubar=no,scrollbars=no,resizable=no ,modal=yes, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
            
            if (window.focus) {
                newWindow.focus();
            }
        };


        WorkOrderService.prototype.isDateGreater = function (element, elementtocompare)
        {
            var value = $(element).val();
            var valueOther = $(elementtocompare).val();
            return window.VTF.DateControl.formatYYYYMMDD(valueOther) >= window.VTF.DateControl.formatYYYYMMDD(value)
            return value >= valueOther;
        }
       
        //Delete selected service on confirmation
        WorkOrderService.prototype.deleteService = function (obj, indx) {

            var self = this;
            var tbody = $(obj.currentTarget).closest("tbody");

            var rowCount = tbody.find('tr').length;

            $(tbody).find('tr').each(function (index, rowItem) {
                if (rowItem.style.display == "none") {
                    rowCount -= 1;
                }
            });

            if (rowCount <= 1) {
                // self.valerrormessage.html('Atleast one service needs to be selected to create work order.');
                window.VTF.CustomMessage.displayFromMessageKey(self.valerrormessage, 'OneServiceValidation2');
                return;
            }

            var trObj = $(obj.currentTarget).closest("tr");
            var serviceIDPr = trObj.find(".service-id").attr("name");
          
            //set service id as 0 for the deleted item and hide row
            trObj.find(".service-id").val(null);
            trObj.hide();
            window.VTF.CustomMessage.displayFromMessageKey(self.valerrormessage, 'OneServiceDeletion');

        };

        WorkOrderService.prototype.showLoading = function () {
            var self = this;
            self.btnNext.attr('disabled', 'disabled');
            self.btnNext.removeClass("btnblue");
            self.btnNext.addClass("btndisable");
            $("#dvoverlay").append("<div style='z-index: 100;' class='dvoverlay'><span>Processing...</span><div class=loading></div></div>");
        };

        return WorkOrderService;
    })();

    window.VTF.WorkOrderService = new WorkOrderService("serviceform", "serviceFinal");

})();


