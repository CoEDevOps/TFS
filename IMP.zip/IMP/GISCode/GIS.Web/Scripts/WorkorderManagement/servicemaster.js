﻿//Global Variable
window.servicesSelected = [];

(function () {

    var ServiceMaster = (function () {
        function ServiceMaster(custForm) {
            var self = this;
           /* requirejs(['../Common/commonconfig'], function () {                
                requirejs(['servicedialog'], function () {
                    $(document).ready(function () {
                        self.initialize(custForm);
                    });
                });
            });*/
            $(document).ready(function () {
                self.initialize(custForm);
            });
        };

        //Initialise
        ServiceMaster.prototype.initialize = function (custForm) {
            var self = this;
            //load the custom messages.
            window.VTF.CustomMessage.loadmessages();
            self.btnNext = $("#btnNext");
            self.errMsg = $("#errorMessage");
            self.form = $("#" + custForm);
            self.initializeControls();           
            self.btnNext.on("click",
                function () {
                    self.createWorkOrder();
                });
        };

        //Initialise child Controls 
        ServiceMaster.prototype.initializeControls = function () {
            var self = this;            
            self.url = "/WorkorderManagement/createworkorder";
                        
            //Register Start Date & End Date controls
            var dt = window.VTF.DateControl;
            dt.registerControl($("#datepickerSt"));
            dt.registerControl($("#datepickerEn"));

            dt.setDate($("#datepickerSt"), new Date());
            dt.setDate($("#datepickerEn"), new Date());

            //Register dropdown control
            var lst = window.VTF.SelectMenu;
            lst.registerControl("slpriority");
        };
        
        //Hilight selected control
        ServiceMaster.prototype.highlightSelected = function (serviceId, required) {
            var self = this;
            var cntrlId = $("#td_"+ serviceId); 
            if(required == true){
                cntrlId.addClass('serviceselected');
                self.errMsg.text(' ');
            }
            else{
                cntrlId.removeClass('serviceselected');
            }
        };

        //Validate Control
        ServiceMaster.prototype.validate = function () {
            var self = this;
            var cntrlStartDate = $("#datepickerSt");
            var cntrlEndDate = $("#datepickerEn");
            var startDate = cntrlStartDate.val();
            var endDate = cntrlEndDate.val();

            if (window.servicesSelected.length < 0) {                
                //window.VTF.CustomMessage.displayFromMessageKey(self.errMsg, 'OneServiceValidation');
                //self.setScrollTop();
                //return false;
            }
            else if (window.VTF.DateControl.validateDateFormat(cntrlStartDate) == false) {
                window.VTF.CustomMessage.displayFromMessageKey(self.errMsg, 'DateFormat');
                window.VTF.DateControl.setError(cntrlStartDate);
                self.setScrollTop();
                return false;
            }
            else if (window.VTF.DateControl.validateDateFormat(cntrlEndDate) == false) {
                window.VTF.CustomMessage.displayFromMessageKey(self.errMsg, 'DateFormat');
                window.VTF.DateControl.setError(cntrlEndDate);
                self.setScrollTop();
                return false;
            }

            else if (window.VTF.DateControl.formatYYYYMMDD(endDate) < window.VTF.DateControl.formatYYYYMMDD(startDate))
            {                
                window.VTF.CustomMessage.displayFromMessageKey(self.errMsg, 'DateIsLessThan');
                //window.DateControl.setError("datepickerSt ");
                window.VTF.DateControl.setError(cntrlEndDate);
                self.setScrollTop();
                return false;
            }
            return true;
        };

        //Get JSON
        ServiceMaster.prototype.appendServiceToForm = function () {
            var self = this;
            var servicelst = window.servicesSelected;
            if (servicelst.length > 0) {
                var i = 0;
                $.each(servicelst, function (i, val) {

                    var serviceName = 'ServiceList[' + i + '].ServiceId';
                    // servicelst[i]
                    $('<input>').attr({
                        type: 'hidden',
                        name: serviceName,
                        value: servicelst[i]
                    }).appendTo(self.form);

                   // var input = $('<input type="text" name="ServiceList[' + i + '].ServiceId>"');
                    //self.form.append(input);
                });
               
            }            

        };


        //Get JSON
        ServiceMaster.prototype.getServiceJSON = function () {
            var tmpJSON = '[';
            var servicelst = window.servicesSelected;            
            if (servicelst.length > 0) {                
                var i = 0;
                $.each(servicelst, function (i, val) {
                    if (i > 0) {
                        tmpJSON += ',';
                    }
                    tmpJSON += '{"ServiceId":' + servicelst[i] + '}';
                    i++;
                });
                tmpJSON += ']';
            }
            return tmpJSON;
            
        };

        //Create work order
        ServiceMaster.prototype.createWorkOrder = function () {
            var self = this;
            var engagementCode = $("#spnEngagementCode").text().trim();
            var priority = $("#slpriority").val();
            var startDate = $("#datepickerSt").val();
            var endDate = $("#datepickerEn").val();

            if (self.validate() == true) {               
                //Format Date to MM/DD/YYYY
                startDate = window.VTF.DateControl.formatMMDDYYYY(startDate);
                endDate = window.VTF.DateControl.formatMMDDYYYY(endDate);
                $("#datepickerSt").val(startDate);
                $("#datepickerEn").val(endDate);
                self.errMsg.text('');
                var that = this;
                self.appendServiceToForm();                

                self.form.submit();
                
            }            
        };

        ServiceMaster.prototype.setScrollTop = function(){
            window.scrollTo(0, 0);
        };


        return ServiceMaster;
    })();

    window.VTF.ServiceMaster = new ServiceMaster("workOrderDetailsForm");

})();


