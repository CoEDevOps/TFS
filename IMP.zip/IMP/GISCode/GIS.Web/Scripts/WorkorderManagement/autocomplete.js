﻿
(function () {
    /*
        Every View has a start up script associated with it, which is called
        by require js. For e.g the SearchCode Page is associated to the 
        AutoComplete script. Every start up script has a class with 
        properies and methods. The class has constructor which first loads the 
        dependacy, in this case the commonconfig, jqueryand webapi are the dependancy which
        are loaded first. After dependancy are loaded the initialize method is called when the 
        document is fully loaded.    
    */
    var AutoComplete = (function () {

     function AutoComplete() {
            var self = this;
            //dependancy are loaded first
           /* requirejs(['../Common/commonconfig'], function () {               
                requirejs(['jqueryui', 'webapi', 'custommessage'], function () {
                    $(document).ready(function () {
                        //start up method
                        self.initialize();
                    });
                });
            });*/

            $(document).ready(function () {
                //start up method
                self.initialize();                
            });
        };

        /*
            Initialize method finds all the necessary controls in the page and
            hooks up the appropriate call back methods. Intiliaze method also 
            defines the default values for the class level variables. 
        */
        AutoComplete.prototype.initialize = function () {
            var self = this;
            window.VTF.CustomMessage.loadmessages();
            var containerengagement = $(".containerengagement.body-content");
            self.code = containerengagement.find("#txtSearchEngmt");
            self.url = "/WorkorderManagement/searchcode";
            //message needs to come from database.
            self.msg = "Please enter engagement code"
            //message needs to come from database.
            self.invalidCharMsg = "Please enter valid characters";
            self.btnSearch = $(containerengagement.find("#btnSearch"));
            self.errorMessage = $(containerengagement.find("#errorMessage"));          
            self.isValidCode = false;
            self.loadData();
            self.btnSearch.on("click",
               function () {
                   self.submitCode();
               });
        };

        //Search Engagement Code
        AutoComplete.prototype.loadData = function () {
            var self = this;
            var data = { strKeyword: self.code.val() };
            self.code.autocomplete({
                source: function (request, response) {                    
                    if (self.validate() == true) {
                        self.errorMessage.text('');
                        window.VTF.WebApi.getData(self.url + "/" + self.code.val(), function (data) {
                            if (data.Message === undefined)
                            {
                                self.errorMessage.text('');
                                response($.map(data, function (value, key) {
                                    return {
                                        label: value.EngagementCode + " : " + self.truncateCode(value.EngagementName,35),
                                        value: value.EngagementCode
                                    };
                                })); 
                            }
                            else {
                                self.close();                                
                                window.VTF.CustomMessage.dispayMessage(self.errorMessage, data, "fontwhite");
                            }
                            
                        }, function (data) {                                                   
                        });
                    }
                    else {
                        self.close();
                        self.errorMessage.text(self.invalidCharMsg);
                    }
                },                
                minLength: 1,
            });

            self.code.val(self.msg);
           self.code.click(function () {
                if ($(this).val() == self.msg) {
                    $(this).val('');

                }
            });
        };        

        //Close container
        AutoComplete.prototype.close = function () {
            this.code.autocomplete('close');
        }

        //Validate entered keyword
        AutoComplete.prototype.validate = function () {
            try {
                var self = this;
                var reg = /^[A-Za-z0-9_]*$/;
                return reg.test(self.code.val());
            }
            catch (err) {
                //console.log(err.message);
            }
        };        

        //Submit Engagement Code
        AutoComplete.prototype.submitCode = function () {
            var self = this;            
            //self.code = self.txtSearchEngmt;
            if (self.code.val() == self.msg || (self.code.val().trim() == '')) {
                self.errorMessage.text(self.msg);
            }
            else {
                self.errorMessage.text('');
                if (self.validate() == true) {
                    self.errorMessage.text('');
                    self.close();
                    document.location.href = "/WorkorderManagement/SelectServices/" + self.code.val();
                }
                else {
                    self.errorMessage.text(self.invalidCharMsg);
                }
            }
        };

        //Truncate if code exceeds maxlength
        AutoComplete.prototype.truncateCode = function (val, maxlength) {
            if (val.length > maxlength) {
                val = jQuery.trim(val).substring(0, maxlength).trim(this) + "...";
            }
            return val.toLowerCase();
                       
        };       

        return AutoComplete;
    })();

    /*
       After the class is full initialized the class 
       object is created and assigned to window object. 
    */
    window.VTF.AutoComplete = new AutoComplete();

})();



