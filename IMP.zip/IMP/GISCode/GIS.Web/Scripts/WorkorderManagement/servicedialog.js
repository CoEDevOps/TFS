﻿(function () {
    var ServiceDialog = (function () {
        function ServiceDialog(dvServiceDetails) {
            var self = this;
                   $(document).ready(function () {
                self.initialize(dvServiceDetails);
            });
        };

        //Initialise
        ServiceDialog.prototype.initialize = function (dvServiceDetails) {
            var self = this;
            self.dialogform = $("#" + dvServiceDetails);
            self.url = "/WorkorderManagement/getservicedetails";
            self.loadDialog();
        };

        //Load Service Details
        ServiceDialog.prototype.getServiceDetails = function (serviceId) {
            var self = this;
            self.ServiceId = serviceId;
            window.VTF.WebApi.getData(self.url + "/" + serviceId, function (data) {
                if (data.Message === undefined) {
                    self.generateMarkup(data);

                    if (self.isAlreadySelected() == true) {
                        $("#btnSelect").html('<span class="ui-button-text">Remove Service</span>');
                    }
                    else {
                        $("#btnSelect").html('<span class="ui-button-text"> Next </span>');
                    }

                    dialog.dialog('open');
                }
                else {
                    self.close();
                }

            }, function (data) {

                //Check if the reponse is not blank or null and then parse
                if (data.responseText == null || data.responseText == "")
                    return;
                
                var errorMessage = jQuery.parseJSON(data.responseText);
                if (errorMessage != undefined && errorMessage.Message != undefined) {
                    //self.errMsg.text(errorMessage.Message);
                    window.VTF.CustomMessage.dispayMessage(self.errMsg, errorMessage);
                    window.VTF.ServiceMaster.scsetScrollTop();
                }
            });
        };

        //Generate Service Details markup
        ServiceDialog.prototype.generateMarkup = function (data) {
            if (data.length > 0) {
                var serviceDescription = data[0];
                $("#serviceDetails").find('#tblServiceDetails').empty();
                var tablebody = $("#serviceDetails").find('#tblServiceDetails');
                $("#serviceDetails").find('#tblServiceDetails').empty();
                //append title
                var row = $("<tr/>");
                row.append($("<td align='left' class='font11pt fontbold fontgreen'>/>").text(serviceDescription.ServiceName));
                tablebody.append(row);

                //Append Service Short Description
                row = $("<tr/>");
                row.append($("<td align='left' class='font9pt'>/>").text(serviceDescription.ShortDescription));
                tablebody.append(row);

                //Append Features in bullet items  
                row = $("<tr/>");
                row.append($("<td align='left'>/>").text(""));
                tablebody.append(row);

                row = $("<tr/>");
                row.append($("<td align='left' class='font11pt fontbold fontgreen'>/>").text("Features"));
                tablebody.append(row);

                row = $("<tr/>");
                var cell = $("<td/>");
                var list = $("<ul class='servicelist'/>")
                var items = serviceDescription.Features.split('|');
                $.each(items, function (index, value) {
                    list.append($("<li class='star font9pt'/>").text(value));
                });
                cell.append(list);
                row.append(cell);
                tablebody.append(row);

                // Append Eligibility in bullet item
                row = $("<tr/>");
                row.append($("<td align='left'>/>").text(""));
                tablebody.append(row);

                row = $("<tr/>");
                row.append($("<td align='left' class='font11pt fontbold fontgreen'>/>").text("Eligibility"));
                tablebody.append(row);

                if (serviceDescription.EligibilityDescription != null) {
                    row = $("<tr/>");
                    row.append($("<td align='left' class='font9pt'>/>").text(serviceDescription.EligibilityDescription));
                    tablebody.append(row);
                }

                row = $("<tr/>");
                var cell = $("<td/>");
                var list = $("<ul class='servicelist'/>")
                var items = serviceDescription.Eligibility.split('|');
                $.each(items, function (index, value) {
                    list.append($("<li class='star font9pt'/>").text(value));
                });
                cell.append(list);
                row.append(cell);
                tablebody.append(row);

                // Append Pricing in bullet item
                row = $("<tr/>");
                row.append($("<td align='left'>/>").text(""));
                tablebody.append(row);

                row = $("<tr/>");
                row.append($("<td align='left' class='font11pt fontbold fontgreen'>/>").text("Pricing"));
                tablebody.append(row);

                row = $("<tr/>");
                var cell = $("<td/>");
                var list = $("<ul class='servicelist'/>")
                var items = serviceDescription.Pricing.split('|');
                $.each(items, function (index, value) {
                    list.append($("<li class='star font9pt'/>").text(value));
                });
                cell.append(list);
                row.append(cell);
                tablebody.append(row);

                //Append Contact us
                row = $("<tr/>");
                row.append($("<td align='left'>/>").text(""));
                tablebody.append(row);

                row = $("<tr/>");
                row.append($("<td align='left' class='font11pt fontbold fontgreen'>/>").text("Point of Contact"));
                tablebody.append(row);

                row = $("<tr/>");
                var cell = $("<td/>");
                var list = $("<ul class='servicelist'/>")
                var items = serviceDescription.Support.split('|');
                $.each(items, function (index, value) {
                    list.append($("<li class='star font9pt'/>").text(value));
                });
                cell.append(list);
                row.append(cell);
                tablebody.append(row);


            }
        };

        //Load dialog with Service Details
        ServiceDialog.prototype.loadDialog = function () {
            var self = this;
            dialog = self.dialogform.dialog({
                title: "Service Details",
                autoOpen: false,
                height: 898,
                width: 655,
                modal: true,
                draggable: false,
                resizable: false,
                buttons: [
                   {
                       text: "Cancel",
                       id: "btnBack",
                       "class": "btnblue fontbold",
                       click: function () {
                           dialog.dialog("close");
                       }
                   },
                   {
                       text: "Next",
                       id: "btnSelect",
                       "class": "btnblue fontbold",
                       click: function () {
                           // self.selectService();
                           $("#serviceuid").val(self.ServiceId);
                           dialog.dialog('close');
                           $("#btnNext").click();
                       }
                   }
                ],
                show: {
                    effect: "fade",
                    duration: 800
                },
                hide: {
                    effect: "fade",
                    duration: 400
                },
                close: function () {

                }
            });
        };

        //Hilight selected service
        ServiceDialog.prototype.selectService = function () {
            var self = this;
            if (self.isAlreadySelected() == true) {
                self.popService();
                window.VTF.ServiceMaster.highlightSelected(self.ServiceId, false);
            }
            else {
                self.pushService();
                window.VTF.ServiceMaster.highlightSelected(self.ServiceId, true);
            }

            dialog.dialog('close');
        };

        //Check for duplicate
        ServiceDialog.prototype.isAlreadySelected = function () {
            var self = this;
            var id = window.servicesSelected.length + 1;
            var found = window.servicesSelected.some(function (id) {
                return id === self.ServiceId;
            });
            return found;
        };

        //Add service selected to a global array
        ServiceDialog.prototype.pushService = function () {
            var self = this;
            window.servicesSelected.push(self.ServiceId);

        };

        //Remove service selected from a global array
        ServiceDialog.prototype.popService = function () {
            var self = this;
            window.servicesSelected = $.grep(window.servicesSelected, function (value) {
                return value != self.ServiceId;
            });
        }

        return ServiceDialog;

    })();

    window.VTF.ServiceDialog = new ServiceDialog("serviceDetails");

})();

