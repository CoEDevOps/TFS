﻿
(function () {

    var UploadStatus = (function () {


        function UploadStatus() {

            var self = this;
           /* requirejs(['../Common/commonconfig'], function () {
                //the jquery.alpha.js and jquery.beta.js plugins have been loaded.
                requirejs(['jquery'], function () {
                    $(document).ready(function () {
                        self.initialize();
                    });
                });
            });*/

            $(document).ready(function () {
                self.initialize();
            });

        };

        UploadStatus.prototype.initialize = function () {
            var self = this;
            var parent = $(window.opener.document);
            //Set the validation message and initlize the common js for message list.
            var parenthdnCusomtMessageList = parent.find("#hdnCusomtMessageList");
            var hdnCusomtMessageList = $("#hdnCusomtMessageList");
            var hdnFileTypeAllowed = $("#hdnFileTypeAllowed");
            hdnCusomtMessageList.val(parenthdnCusomtMessageList.val());          
            window.VTF.CustomMessage.loadmessages();
            var messageFileSize = window.VTF.CustomMessage.MessageList["UploadFileSize"].Message;
            window.VTF.CustomMessage.MessageList["UploadFileSize"].Message = messageFileSize.replace("#@FileSize", VTF.FileSize);

            var messageFileType = window.VTF.CustomMessage.MessageList["UploadFileType"].Message;
            window.VTF.CustomMessage.MessageList["UploadFileType"].Message = messageFileType.replace("#@FileType", hdnFileTypeAllowed.val());
            self.Uploaded();
        };       



        return UploadStatus;
    })();

    UploadStatus.prototype.Uploaded = function () {

        var self = this;
        var status = self.getParameterByName("status");
        var parent = $(window.opener.document);
        var uploadMessage = parent.find("#validationerrorMessage");

        var hdnCurrentFile = parent.find("#hdnCurrentFile");
        var uploadedfile = parent.find('input[name="' + hdnCurrentFile.val() + '"]');
        var parenttr = $(uploadedfile.closest("tr"));

        var displayfile = parenttr.find(".hdndisfilename");


        var divObj = parenttr.find('.grid-filename');
        var deleteFile = parenttr.find('.grid-deletefile');
        var btnDeleteUpload = parenttr.find('.grid-btndelupload');
        btnDeleteUpload.removeClass("hidden");
        deleteFile.removeClass("grid-deletefile-align-left");
        deleteFile.addClass("grid-deletefile-align-right");
        //btnDeleteUpload.addClass("grid-btndelupload11");

        uploadedfile.val('');
        displayfile.val('');
        divObj.attr('title', '');

        // Please select a file.
        if (status == 1) {
            if (divObj) {
                window.VTF.CustomMessage.displayFromMessageKey(divObj, 'UploadFileRequired');
                //divObj.text("Please select a file");
                //divObj.addClass("errormsg"); 
                deleteFile.removeClass("visible");
                deleteFile.addClass("hidden");
            }
        }
            // File size greater.
        else if (status == 2) {
            if (divObj) {
                window.VTF.CustomMessage.displayFromMessageKey(divObj, 'UploadFileSize');
                // divObj.text("File size needs to be less then " + VTF.FileSize + " MB");
                //divObj.addClass("errormsg");
                deleteFile.removeClass("visible");
                deleteFile.addClass("hidden");
            }
        }
        else if (status == 3) {
            if (divObj) {
                window.VTF.CustomMessage.displayFromMessageKey(divObj, 'UploadFileType');
                // divObj.text("File size needs to be less then " + VTF.FileSize + " MB");
                //divObj.addClass("errormsg");
                deleteFile.removeClass("visible");
                deleteFile.addClass("hidden");
            }
        }            // File uploading done.
        else if (status == 4) {
            window.VTF.CustomMessage.displayFromMessageKey(uploadMessage, 'UploadSuccess');
            // uploadMessage.text("Uploaded successfully");

            var displayfilename = self.getParameterByName("disfileName");
            var fileName = self.getParameterByName("fileName");

            uploadedfile.val(fileName);
            displayfile.val(displayfilename);

            if (divObj) {
                divObj.text(displayfilename);
                divObj.attr('title', displayfilename);
                deleteFile.removeClass("hidden");
                deleteFile.addClass("visible");
            }
        }
            //Session Timeout Message
        else if (status == 5) {
            var errormessage = parent.find("#errorMessage");
            if (errormessage) {
                errormessage.text(window.VTF.CustomMessage.MessageList["SessionTimeOut"].Message);
            }
        }


        else if (status == 6) {
            var errormessage = parent.find("#errorMessage");
            if (errormessage) {
                errormessage.text(window.VTF.CustomMessage.MessageList["UnAuthorized"].Message);
            }
        }

         window.close();
    }

    UploadStatus.prototype.getParameterByName  = function(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    }

    window.VTF.UploadStatus = new UploadStatus();

})();



