﻿(function () {

    var GetWorkOrder = (function () {

        function GetWorkOrder() {
            var self = this;
           /* requirejs(['../Common/commonconfig'], function () {
                requirejs(['servicedialog'], function () {
                    $(document).ready(function () {
                        self.initialize();
                    });
                });
            });*/

            $(document).ready(function () {
                self.initialize();
            });
        };

        //Initialise
        GetWorkOrder.prototype.initialize = function () {
            var self = this;
            self.content = $("#content");
            self.btnNext = self.content.find("#btnNext");
            self.btnNext.on("click",
                 function () {
                     window.location.href = "/WorkOrderManagement/ViewWorkOrders";
                 });
            //Register dropdown control
            var lst = window.VTF.SelectMenu;
            lst.registerControl("slpriority");
        }; 
        

        return GetWorkOrder;
    })();

    window.VTF.GetWorkOrder = new GetWorkOrder();

})();


