﻿(function () {

    var GetWorkOrderServiceStatus = (function () {

        function GetWorkOrderServiceStatus() {
            var self = this;
            /*requirejs(['../Common/commonconfig'], function () {
                requirejs(['servicedialog'], function () {
                    $(document).ready(function () {
                        self.initialize();
                    });
                });
            });*/

            $(document).ready(function () {
                self.initialize();
            });
        };

        //Initialise
        GetWorkOrderServiceStatus.prototype.initialize = function () {
            var self = this;

            //load the custom messages.
            window.VTF.CustomMessage.loadmessages();

            self.content = $("#content");
           // self.btnNext = self.content.find("#btnNext");
            self.serviceurl = '/WorkOrderManagement/updateworkorderservicestatus';
            self.workorderurl = '/WorkOrderManagement/updateworkorderstatus'
            self.hdnUserID = self.content.find("#hdnUserID");
            self.errormsg = self.content.find("#errorMessage");
           /* self.btnNext.on("click",
                 function () {
                     window.location.href = "/WorkOrderManagement/ViewWorkOrders";
                 });*/
            //Register dropdown control
            var lst = window.VTF.SelectMenu;
            lst.registerControl("slpriority");
          
            //callback function onchange of work order drop down
            var workorderfn = function (currentObj) {
                self.updateworkorderstatus(currentObj)
            }

            //register the work order dropdown.
            lst.registerControl("slworkorderstatus", workorderfn);

            /*var data = {
                    EngagementCode: engagementCode,
                    Priority: priority,
                    StartDate: startDate,
                    EndDate: endDate,
                    ServiceList: jQuery.parseJSON(serviceslst)
                };  */
            self.content.find("select[servicestatus='slservicestatus']").each(function () {
                var that = self;
                //callback function onchange of work order service drop down
                var fn = function (currentObj) {
                    that.updateservicestatus(currentObj)
                }
                var drpId = $(this).attr("id");
                //register the work order service dropdown.
                lst.registerControl(drpId, fn);
                //add class to change width.
                window.VTF.SelectMenu.addClass(drpId, "grid-service-status");
            });
        };

        GetWorkOrderServiceStatus.prototype.updateservicestatus = function (currentObj) {
            var self = this;
            var data = {
                WorkOrderServiceId: $(currentObj).attr("workOrderServiceId"),
                Status: currentObj.value,
                UserID: self.hdnUserID.val()
            };

            window.VTF.WebApi.postData(self.serviceurl, data, function (result) {
                var test = result;
                if (result.Message != undefined) {
                    var fontsuccess = $(currentObj).closest("td").find(".fontsuccessblue");
                    fontsuccess.text(result.Message);
                    fontsuccess.show();
                    fontsuccess.fadeOut(4000);
                }               

            }, function (data) {
                var errorMessage = jQuery.parseJSON(data.responseText);
                if (errorMessage != undefined && errorMessage.Message != undefined) {
                    var fontsuccess = $(currentObj).closest("td").find(".fontsuccessblue");
                    fontsuccess.text(errorMessage.Message);
                    fontsuccess.show();
                    fontsuccess.fadeOut(4000);
                }
            });
        };

        GetWorkOrderServiceStatus.prototype.updateworkorderstatus = function (currentObj) {
            var self = this;
            var data = {
                WorkOrderID: $(currentObj).attr("workOrderId"),
                Status: currentObj.value,
                UserID: self.hdnUserID.val()
            };

            window.VTF.WebApi.postData(self.workorderurl, data, function (result) {
                var test = result;
                if (result.Message != undefined) {                   
                    //self.errormsg.text(result.Message);
                    window.VTF.CustomMessage.dispayMessage(self.errormsg, result);
                    setTimeout(function () { self.errormsg.html('&nbsp;') }, 2000);
                }

            }, function (data) {
                var errorMessage = jQuery.parseJSON(data.responseText);
                if (errorMessage != undefined && errorMessage.Message != undefined) {                    
                    window.VTF.CustomMessage.dispayMessage(self.errormsg, result);
                    setTimeout(function () { self.errormsg.html('&nbsp;') }, 2000);
                }
            });
        };


        return GetWorkOrderServiceStatus;
    })();

    window.VTF.GetWorkOrderServiceStatus = new GetWorkOrderServiceStatus();

})();


