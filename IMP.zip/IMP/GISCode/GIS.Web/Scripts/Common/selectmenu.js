﻿(function () {

    var SelectMenu = (function () {
        function SelectMenu() {
            var self = this;
            requirejs(['../Common/commonconfig'], function () {
                //the jquery.alpha.js and jquery.beta.js plugins have been loaded.
                requirejs(['jqueryui'], function () {
                    $(document).ready(function () {
                        self.initialize();
                    });
                });
            });
        };

        //Initialise
        SelectMenu.prototype.initialize = function () {            
            //do nothing
        };

        //Register Select Menu Control
        SelectMenu.prototype.registerControl = function (selectCntrl, onchangecallback) {
            var self = this;
            var parentCntrl = selectCntrl;
            selectCntrl = $("#" + selectCntrl);
            //$(selectCntrl).selectmenu(); 
            //Set defaul callback on change
            if (!onchangecallback)
            {
                onchangecallback = function () {
                    self.removeError(parentCntrl);
                };
            }
            $(selectCntrl).selectmenu({
                change: function () { onchangecallback(this); }
            });

            //remove default css applied to buttons
            $("#" + parentCntrl + "-button").removeClass("ui-state-default");
        };

        //Enable
        SelectMenu.prototype.enable = function (selectCntrl) {
            selectCntrl = $("#" + selectCntrl);
            $(selectCntrl).selectmenu("enable");
        };

        //Disable
        SelectMenu.prototype.disable = function (selectCntrl) {
            selectCntrl = $("#" + selectCntrl);
            $(selectCntrl).selectmenu("disable");
        };
        //Select Default
        SelectMenu.prototype.setDefault = function (selectCntrl, defaultVal) {
            selectCntrl = $("#" + selectCntrl);            
            $(selectCntrl).val(defaultVal);
        };

        //Set Error
        SelectMenu.prototype.setError = function (selectCntrl) {            
            $("#" + selectCntrl + "-button").addClass("errormsg")
        };

        SelectMenu.prototype.addClass = function (selectCntrl, classname) {
            $("#" + selectCntrl + "-button").addClass(classname)
        };

        //Remove Error
        SelectMenu.prototype.removeError = function (selectCntrl) {            
            $("#" + selectCntrl + "-button").removeClass("errormsg")
            if ($("#errorMessage")) {
                $("#errorMessage").text('');
            }                
        };        
        
        return SelectMenu;
    })();   

    window.VTF.SelectMenu = new SelectMenu();

})();



