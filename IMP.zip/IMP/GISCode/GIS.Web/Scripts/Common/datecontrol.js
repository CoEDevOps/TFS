﻿(function () {
    var DateControl = (function () {
        function DateControl() {
            var self = this;

           /* this has the mapping of the date format from server to 
           * client side. For e.g M/d/yyyy is represented at client side 
           * as m/d/yyy. Since capital M means month in server side and which maps 
           * to small m at client side.
           */
            this.dateFormatMapList = {};
            this.dateFormatMapList['M/d/yyyy'] = 'm/d/yy';
            this.dateFormatMapList['d/M/yyyy'] = 'd/m/yy';
            this.dateFormatMapList['M/d/yy'] = 'm/d/y';
            this.dateFormatMapList['d/M/yy'] = 'd/m/y';
            this.dateFormatMapList['dd-MM-yyyy'] = 'dd/mm/yy';
            this.dateFormatMapList['dd/MM/yyyy'] = 'dd/mm/yy';            
        };        

        //Initialise
        DateControl.prototype.initialize = function () {            
            //do nothing
        };

        //Register Date Control with default properties
        DateControl.prototype.registerControl = function (dtPicker, onchangecallback) {
            var self = this;
            dtPicker = $(dtPicker);
            var defaultCallback = function () { window.VTF.DateControl.validateDateFormat(dtPicker); };
            if (onchangecallback)
            {
                defaultCallback = onchangecallback;
            }

            $(dtPicker).datepicker({
                showOn: "button",
                buttonImage: "../../Content/Images/calendar_icon.png",
                buttonImageOnly: true,
                beforeShowDay: $.datepicker.noWeekends,
                buttonText: "Select date",
                dateFormat: "dd/mm/yy",
               // dateFormat: self.getCultureDateFormat(),
                defaultDate: +0,
               // language: window.VTF.currentUICulture,
                minDate: 0,
                changeMonth: true,
                changeYear: true,
                onSelect: function (dateText, inst) {
                    window.VTF.DateControl.removeError(dtPicker);
                }
            }).on('change', defaultCallback);
        };

        //Get default date
        DateControl.prototype.getDate = function (dtPicker) {
            dtPicker = $(dtPicker);
            var currentDate = $(self.dtPicker).datepicker("getDate");
            return $(dtPicker).datepicker("getDate");
        };

        //Sets default date
        DateControl.prototype.setDate = function (dtPicker,dt) {
            dtPicker = $(dtPicker);
            $(dtPicker).datepicker("setDate", dt);
        };

        //Enable Date Picker
        DateControl.prototype.enable = function (dtPicker) {
            dtPicker = $(dtPicker);
            $(dtPicker).datepicker("option", "disabled", false);
        };

        //Disable Date Picker
        DateControl.prototype.disable = function (dtPicker) {
            dtPicker = $(dtPicker);
            $(dtPicker).datepicker("option", "disabled", true);
        };

        //Set the format
        DateControl.prototype.setDateFormat = function (dtPicker,dtFormat) {
            dtPicker = $(dtPicker);
            $(dtPickerck).datepicker("option", "dateFormat", dtFormat);
        };

        //Set Error
        DateControl.prototype.setError = function (dtPicker) {
            //to doerrormsg
            $(dtPicker).addClass("errormsg");
        };

        //Remove Error
        DateControl.prototype.removeError = function (dtPicker) {
            //to do
            $(dtPicker).removeClass("errormsg");
            if ($("#errorMessage")) {
                $("#errorMessage").text('');
            }
        };

        //Validate Date
        DateControl.prototype.validateDateFormat = function (dtPicker) {
            var self = this;
            try{
                var date = $.datepicker.parseDate("dd/mm/yy", $(dtPicker).val());
                var minDate = new Date(1953, 1, 1); // minimum sql date
                if (date < minDate) {
                    if ($("#errorMessage")) {
                        $("#errorMessage").text('Invalid Date');
                    }
                    self.setError(dtPicker);
                    return false;
                }
                self.removeError(dtPicker);
                return true;
            }
            catch(exception){
                if ($("#errorMessage")) {
                    $("#errorMessage").text('Invalid Date Format');
                }            
                self.setError(dtPicker);
                return false;
            }
        };

        DateControl.prototype.getCultureDateFormat = function () {
            
            if (!this.dateFormatMapList[window.VTF.shortDatePatternUICulture])
                throw 'No date format map found';           

            return this.dateFormatMapList[window.VTF.shortDatePatternUICulture];
        }

        DateControl.prototype.validateCultureDateFormat = function (dtPicker) {
            var self = this;
            try {
                var date = $.datepicker.parseDate(self.getCultureDateFormat(), $(dtPicker).val());
                var minDate = new Date(1953, 1, 1); // minimum sql date
                if (date < minDate) {
                    return false;
                }

                return true;
            }
            catch (exception) {
                return false;
            }
        };
        //Validate Date
        DateControl.prototype.validateOnlyDateFormat = function (dtPicker) {
            var self = this;
            try {
                var date = $.datepicker.parseDate("dd/mm/yy", $(dtPicker).val());
                var minDate = new Date(1953, 1, 1); // minimum sql date
                if (date < minDate) {                    
                    return false;
                }
               
                return true;
            }
            catch (exception) {                
                return false;
            }
        };
        //Format to MM/dd/yyyy
        DateControl.prototype.formatMMDDYYYY = function (dateStr) {
            var parts = dateStr.split("/");
            if (parts.length == 3) {
                return parts[1] + "/" + parts[0] + "/" + parts[2];
            }
            return dateStr;
        };

        //Format to yyyy-mm-dd
        DateControl.prototype.formatYYYYMMDD = function (dateStr) {            
            var date = $.datepicker.parseDate("dd/mm/yy", dateStr);
            return date;
        };
        
        //Validate Date Range
        DateControl.prototype.validateDateRange = function (dtPicker, sDate, eDate) {
            var self = this;
            try {
                var date = $.datepicker.parseDate("dd/mm/yy", $(dtPicker).val());
                var startdate = $.datepicker.parseDate("dd/mm/yy", sDate);
                var enddate = $.datepicker.parseDate("dd/mm/yy", eDate);                
                if (date < startdate) {
                    $(dtPicker).addClass("errormsg");
                    return false;
                }
                else if (date > enddate) {
                    $(dtPicker).addClass("errormsg");
                    return false;
                }
                return true;
            }
            catch (exception) {
                return false;
            }
        };
        return DateControl;
    })();

    window.VTF.DateControl = new DateControl();

})();