﻿
(function () {

    var CustomMessage = (function () {

        function CustomMessage() {
           /* var self = this;
           // var messages = $("#hdnCusomtMessageList").val();
            //var messageList = jQuery.parseJSON(messages);            
            this.MessageList = {};
            if (!messageList) {
                messageList = {};
            }
            else {
                $.each(messageList, function (key, value) {
                    var custommessage = messageList[key];
                    self.MessageList[custommessage.MessageKey] = {};
                    self.MessageList[custommessage.MessageKey].MessageType = custommessage.MessageType;
                    self.MessageList[custommessage.MessageKey].Message = custommessage.Message;
                });
            }*/           

            //this.MessageList = messageList;
        }

        CustomMessage.prototype.loadmessages = function(){
            var self = this;
            var messages = $("#hdnCusomtMessageList").val();
            

            var messageList = '';
            if (messages.length > 0)
                messageList = jQuery.parseJSON(messages)

            this.MessageList = {};
            if (!messageList) {
                messageList = {};
            }
            else {
                $.each(messageList, function (key, value) {
                    var custommessage = messageList[key];
                    self.MessageList[custommessage.MessageKey] = {};
                    self.MessageList[custommessage.MessageKey].MessageType = custommessage.MessageType;
                    self.MessageList[custommessage.MessageKey].Message = custommessage.Message;
                });
            }
        }

        CustomMessage.prototype.dispayMessage = function (objMsg, customMessage, className) {
            $(objMsg).text(customMessage.Message);

            if (className) {
                $(objMsg).addClass(className);
                return;
            }


            //for success message
            if (customMessage[VTF.Message] == VTF.MessageType.Success) {
                $(objMsg).removeClass("errormsg");
                $(objMsg).addClass("fontSuccess");
            }
                //for failure message
            else {
                $(objMsg).removeClass("fontSuccess");
                $(objMsg).addClass("errormsg");
            }
        }
        
        CustomMessage.prototype.displayFromMessageKey = function (objMsg, messageKey, className) {
            if (this.MessageList[messageKey]) {
                $(objMsg).text(this.MessageList[messageKey].Message);
            }

            if (className) {
                $(objMsg).addClass(className);
                return;
            }

            $(objMsg).removeClass("errormsg");

            //for success message
            if (this.MessageList[messageKey].MessageType == VTF.MessageType.Success) {
                $(objMsg).addClass("fontSuccess");
                $(objMsg).addClass("fontbold");
            }
                //for failure message
            else {
                $(objMsg).addClass("errormsg");
            }
        }


       
        return CustomMessage;
    })();
    window.VTF.CustomMessage = new CustomMessage();
})();



