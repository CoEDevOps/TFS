﻿



(function () {
requirejs.config({

    //DEV
    //urlArgs: "rel=" + (new Date()).getTime(),

    //PROD
   // urlArgs: "rel=v9",

    "baseUrl": "/Scripts/Common",
    //javascript path specify here
    paths: {
        jquery: 'jquery',
        jvalidate: 'jquery.validate',
        junobtrusive: 'jquery.validate.unobtrusive',
        validator: 'validatordynamic',
        jQueryXDomain: 'jQuery.XDomainRequest',
        webapi: 'webapi',
        jqueryui: 'jqueryui',
        custommessage: 'custommessage',
        servicedialog: '/Scripts/WorkorderManagement/servicedialog',
        autocomplete: '/Scripts/WorkorderManagement/autocomplete',
        workorderservice: '/Scripts/WorkorderManagement/workorderservice',
        servicemaster: '/Scripts/WorkorderManagement/servicemaster',
        getworkorder: '/Scripts/WorkorderManagement/getworkorder',
        getworkorderservicestatus: '/Scripts/WorkorderManagement/getworkorderservicestatus',
        uploadfile: '/Scripts/WorkorderManagement/uploadfile',
        uploadstatus: '/Scripts/WorkorderManagement/uploadstatus',
        bootstrap:'bootstrap',
        gis: '/Scripts/GIS/gis',
        giscarousel: '/Scripts/GIS/giscarousel',
        test: '/Scripts/Test/Test'
        
    },
    //dependancy specify in shim
    shim: {
        jvalidate: { deps: ["jquery"] },
        junobtrusive: { deps: ["jquery", "jvalidate"] },
        validator: { deps: ["jquery", "jvalidate", "junobtrusive"] },
        webapi: { deps: ["validator", "jQueryXDomain"] },
        jqueryui: { deps: ['jquery'] },
        datecontrol: { deps: ['jquery'] },
        custommessage: { deps: ['jquery'] },
        servicedialog: { deps: ['jquery', 'webapi', 'jqueryui', 'datecontrol', 'selectmenu', 'custommessage'] },
        autocomplete: { deps: ['jqueryui', 'webapi', 'custommessage'] },
        workorderservice: { deps: ['servicedialog'] },
        servicemaster: { deps: ['servicedialog'] },
        getworkorder: { deps: ['jquery', 'jqueryui', 'selectmenu'] },
        getworkorderservicestatus: { deps: ['jquery', 'webapi', 'jqueryui', 'selectmenu', 'custommessage'] },
        uploadfile: { deps: ['jquery'] },
        uploadstatus: { deps: ['jquery', 'custommessage'] },
        bootstrap: { deps: ['jquery'] },
        giscarousel: { deps: ['jquery', 'bootstrap'] },
        gis: { deps: ['jquery', 'jvalidate', 'bootstrap', 'giscarousel'] },
        test: { deps: ['jquery', 'webapi', 'jqueryui', 'datecontrol'] }

    } 
});


window.VTF.Config = {};
window.VTF.Config.WebApiUrl = 'http://localhost:55959/api';
window.VTF.Message = 'MessageType';
window.VTF.MessageType = { Unhandled: 1, Success: 2, Failure: 3 };
window.VTF.FileSize = 5;

window.GIS = {};
window.GIS.AutomationUrl = "/WorkorderManagement/Index/";
window.GIS.VTFUrl = "http://localhost:57858/workordermanagement/index";
window.GIS.PTFUrl = "/GISManagement/TaskForceCaseStudies/";
window.GIS.ContactToAdd = "vtfadmin@capgemini.com";

})();

