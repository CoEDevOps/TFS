﻿
(function () {

    var loadedscript = document.getElementsByTagName("script");    

    for (var i = 0; i < loadedscript.length ; i++) {
        var starupscript = loadedscript[i].getAttribute("data-start-up");

        if (!starupscript) continue;

        //Set the script version.
        requirejs.config({
            //PROD
            urlArgs: "rel=v" + window.VTF.JSVersion
        });

        requirejs(['commonconfig'], function () {
            requirejs([starupscript]);
        });

        return;
    }

})();



