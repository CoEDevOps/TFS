﻿
(function () {

    var WebApi = (function () {

        function WebApi() {
           
        };      

        WebApi.prototype.postData = function (url, jsonData, callbacksuccess, callbackfailure) {
            var that = this;
            jQuery.support.cors = true;
            $.ajax({
                cache: false,
                crossDomain: true,
                type: "POST",
                data: jsonData,
                contentType: "application/x-www-form-urlencoded",
                url: VTF.Config.WebApiUrl + url,
                xhrFields: {
                    withCredentials: true
                },
                beforeSend: function (xhr) {
                    xhr.withCredentials = true;
                },
                headers: {
                    'Accept-Language': window.VTF.currentUICulture
                },
                success: function (result) {                   
                    //error messages from WebAPi
                    if (result[VTF.Message])
                    {
                        //unhandled messages, redirect to error page
                        if (result[VTF.Message] == VTF.MessageType.Unhandled)
                        {
                            window.location.href = 'UserManagement/Error';
                        }
                        // system messages from webapi
                        else {
                            if (callbacksuccess) {
                                callbacksuccess(result);
                            }
                        }
                        
                        return;
                    }

                    if (callbacksuccess) {
                        callbacksuccess(result);
                    }
                },
                error: function (result) {
                    //For unauthorized access 
                    if (result.status == 401)
                    {
                        // Show the "Session timeout message" and return.
                        $("#errorMessage").text('Sorry, your session has timed out. Please refresh the page to create new session.');
                        return;
                    }

                    //For Model state or other error.
                    if (result.status == 400) {
                        if(callbackfailure)
                        {
                            callbackfailure(result);
                        }
                    }
                    else
                    {
                        if (callbackfailure) {
                            callbackfailure(result)
                        }
                    }                    
                }
            })
        };

        WebApi.prototype.getData = function (url, callbacksuccess, callbackfailure) {            
            var that = this;
            jQuery.support.cors = true;
            $.ajax({
                cache: false,
                crossDomain: true,
                type: "GET",
                // contentType: "application/json",
                contentType: "text/plain",
                //dataType: "json",
                url: VTF.Config.WebApiUrl + url,
                beforeSend: function (xhr) {
                    xhr.withCredentials = true;
                },
                xhrFields: {
                    withCredentials: true
                },
                headers: {
                    'Accept-Language': window.VTF.currentUICulture
                },
                success: function (result) {
                    if (callbacksuccess) {
                        callbacksuccess(result)
                    }
                },
                error: function (result) {

                    //For unauthorized access 
                    if (result.status == 401) {
                        $("#errorMessage").text('Sorry, your session has timed out. Please refresh the page to create new session.');
                        // Show the "Session timeout message".
                    }

                    //For Model state or other error.
                    if (result.status == 400) {
                        if (callbackfailure) {
                            callbackfailure(result);
                        }
                    }
                    else
                    {
                        if (callbackfailure) {
                            callbackfailure(result)
                        }
                    }  
                
                }
            });
        };        
        return WebApi;
    })();
    window.VTF.WebApi = new WebApi();
})();



