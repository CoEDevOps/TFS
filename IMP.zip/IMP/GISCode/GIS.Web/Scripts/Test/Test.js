﻿/// <reference path="../Common/webapi.js" />
/// <reference path="jquery-1.8.2.js" />

(function () {
    /*
        Every View has a start up script associated with it, which is called
        by require js. For e.g the SearchCode Page is associated to the 
        AutoComplete script. Every start up script has a class with 
        properies and methods. The class has constructor which first loads the 
        dependacy, in this case the commonconfig, jqueryand webapi are the dependancy which
        are loaded first. After dependancy are loaded the initialize method is called when the 
        document is fully loaded.    
    */
    var Test = (function () {

        function Test() {
            var self = this;

            $(document).ready(function () {
                //start up method
                self.initialize();
            });
        };

        /*
            Initialize method finds all the necessary controls in the page and
            hooks up the appropriate call back methods. Intiliaze method also 
            defines the default values for the class level variables. 
        */
        Test.prototype.initialize = function () {
            var self = this;
            self.btnNext = $("#btnNext");
            self.datecntrl = $("#EnrolledDate");
            self.serviceform = $("#ServiceForm");
            self.firstname = $("#FirstName");

            var dt = window.VTF.DateControl;
            dt.registerControl(self.datecntrl);

            self.btnNext.on("click",
                function () {
                    self.validate();
                })

        };

        Test.prototype.validate = function () {

            var self = this;
            //To validate client side.
            //var isValid = $.validator.unobtrusive.validateForm(self.serviceform);
           // if (!isValid)
               // return false;

            var isValidDate = window.VTF.DateControl.validateCultureDateFormat(self.datecntrl);

            if (!isValidDate) {
                alert("Invalid date format");
                //   return false;
            }

            var data = {
                FirstName: self.firstname.val(),
                LastName: '',
                EnrolledDate: self.datecntrl.val()
            };

            /* Ajax request */
            window.VTF.WebApi.postData("/Test/Test", data, function (result) {
                alert(result);
            });

            // self.serviceform.submit();
        }


        return Test;
    })();

    /*
       After the class is full initialized the class 
       object is created and assigned to window object. 
    */
    window.VTF.Test = new Test();

})();



