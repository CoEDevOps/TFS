﻿using System.Web.Mvc;
using System.Web.Routing;


namespace Capgemini.GroupProduction.GIS.Web
{
    /// <summary>
    /// Route configuration.
    /// </summary>
    public static class RouteConfig
    {
        /// <summary>
        /// REgister the route collection.
        /// </summary>
        /// <param name="routes"></param>
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                name: "GISDefault",
                url: "{controller}/{action}/{id}",
                //To Do: Commented out for Milestone 1
                //defaults: new { controller = "UserManagement", action = "Login", id = UrlParameter.Optional 
                defaults: new
                {
                    controller = "GISManagement",
                    action = "Index",
                    id = UrlParameter.Optional
                },
                //defaults: new
                //{
                //    controller = "WorkOrderManagement",
                //    action = "Index",
                //    id = UrlParameter.Optional
                //},
                namespaces: new string[] { "Capgemini.GroupProduction.GIS.Web.Controller" }

            );        

        }
    }
}