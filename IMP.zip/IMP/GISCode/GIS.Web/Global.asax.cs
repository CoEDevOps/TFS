﻿using Capgemini.GroupProduction.GIS.Common;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.Entity.Binders;
using Capgemini.GroupProduction.GIS.Web.Helpers;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Capgemini.GroupProduction.GIS.Web
{
    /// <summary>
    /// 
    /// </summary>
    public class MvcApplication : HttpApplication
    {
        /// <summary>
        /// Event registers the route defination.
        /// </summary>
        protected void Application_Start()
        {
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            ModelBinders.Binders.Add(typeof(CustomDateTime), new CustomDateTimeModelBinder());
                   
        }

        /// <summary>
        /// Abandons the session.
        /// </summary>
        public void Session_OnEnd()
        {
            Session.Abandon();
        }

    }
}