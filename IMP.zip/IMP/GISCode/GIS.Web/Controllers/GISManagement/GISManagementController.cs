﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Capgemini.GroupProduction.GIS.Web.Controllers
{
    public class GISManagementController : Controller
    {        
        /// <summary>
        /// GIS Home Page
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Index()
        {
            return View("Index");
        }

        /// <summary>
        /// Read More Customer Say
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult WhatCustomerSay()
        {
            return View("WhatCustomerSay");
        }

        /// <summary>
        /// PTF
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult TaskForceCaseStudies()
        {
            return View("TaskForceCaseStudies");
        }

        /// <summary>
        /// Read More - About
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult About(int id)
        {
            TempData["SectionId"] = id;
            return View("About");
        }

        /// <summary>
        /// DownloadPTFCaseStudy
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult DownloadPTFCaseStudy()
        {            

            if (Request.QueryString["File"] == null)
            {
                return new EmptyResult();
            }

            string file = Request.QueryString["File"].ToString(); 
            string filePath = System.Configuration.ConfigurationManager.AppSettings["PTFCaseStudiesPath"].ToString() + "\\" + file;

            if (!System.IO.File.Exists(filePath))
            {
                return new EmptyResult();
            }

            string extension = file.Substring(file.IndexOf(".") + 1);
            FileStream fileStream = new FileStream(filePath, FileMode.Open);
            string mimeApplicationType = System.Net.Mime.MediaTypeNames.Application.Octet;
            Response.AppendHeader("content-disposition", "attachment; filename=" + file);
            Response.ContentType = mimeApplicationType;

            return new FileStreamResult(fileStream, mimeApplicationType);
            
        }
    }
}
