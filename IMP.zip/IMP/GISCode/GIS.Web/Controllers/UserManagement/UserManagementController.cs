﻿using System;
using System.Web.Mvc;
using System.Text;
using System.Configuration;
using System.Net.Http;
using System.Net;
using Capgemini.GroupProduction.GIS.Web;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.Web.Helpers;
using System.Collections.Generic;
using Capgemini.GroupProduction.GIS.ValueObject;
using System.DirectoryServices;
using System.Web.SessionState;
using Capgemini.GroupProduction.GIS.Web.ActionFilters;
using Capgemini.GroupProduction.GIS.Common;
using System.Web;

namespace Capgemini.GroupProduction.GIS.Web.Controllers
{
  
    /// <summary>
    /// 
    /// </summary>
    public class UserManagementController : Controller
    {
        /// <summary>
        /// Error page
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ActionName("Error")]
        public ActionResult Error()
        {
            return View("Error");
        }


        /// <summary>
        /// View for unauthorised users
        /// </summary>
        /// <returns></returns>     
        [HttpGet]
        [ActionName("Unauthorized")]
        public ActionResult Unauthorized()
        {
            return View("Unauthorized");
        }


        /// <summary>
        /// Ldap authetntication of user.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
    
        [HttpGet]
        [ActionName("Login")]
        public ActionResult Login()
        {
            // When the user has directly accessed the page then 
            // the Session["UserName"] variable is null. So redirect to "Unauthorized" page. 
            string returnUrl = HttpUtility.UrlDecode(Request.QueryString["ReturnUrl"]);
            if (Session["UserName"] == null || string.IsNullOrEmpty(returnUrl) || returnUrl.IndexOf(@"/UserManagement/Login") != -1)
            {
                return View("Unauthorized");
            }

            /* DO LDAP authentication and user ID request*/            
            LDAPAuthention userAuthentication = new LDAPAuthention();
            HttpClientHelper clientHelper = new HttpClientHelper();            
            User user = userAuthentication.LDAPAuthenticate();

            if(user == null)
            {
               // return Json(string.Empty, JsonRequestBehavior.AllowGet);
                return View("Unauthorized");
            }

            //Get the data from WebAPi.
            user = clientHelper.PostDataToApi<User, User>("/UserManagement/AddUser/", user);

            Session["UserID"] = user.UserID;
            Session["LoginId"] = user.UserName;
            Session["UserName"] = user.Name;           
            Session["RoleIds"] = user.RoleIds;

            UserAuthorization userAuthorization = new UserAuthorization(user);

            Session["IsFactoryManager"] = userAuthorization.IsFactoryManager();

            //string controllerName = Request.QueryString["controller"];        
            //if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(controllerName))
            //{
            //    return View("Unauthorized");
            //}

          
            string userToken = EncyrptDecrypt.Encrypt(user.UserID + "_" + user.RoleIds, false);

            HttpClientCookie cookie = new HttpClientCookie();          

            Response.SetCookie(cookie.CreateUserTokenCookie(userToken, clientHelper.BaseApiDomainName));

            return Redirect(returnUrl);  
        }
      
       

       /// <summary>
       /// Load the menu based on role.
       /// </summary>
       /// <param name="SelectedMenu"></param>
       /// <returns></returns>
        [HttpGet]
        [ActionName("LoadMenuAll")]
        public ActionResult LoadMenuAll(string SelectedMenu)
        {
            ViewBag.ActiveMenu = SelectedMenu;
            Int64 userID = (Int64)Session["UserID"];
            HttpClientHelper clientHelper = new HttpClientHelper();
            IEnumerable<MenuEntity> menus = clientHelper.GetDataFromApi<IEnumerable<MenuEntity>>("/UserManagement/AllRoleMenu/" + userID);
            return View("_MainMenu",menus);
        }
        
        /// <summary>
        /// Logout
        /// </summary>
        /// <returns></returns>    
        [HttpGet]
        [ActionName("Logout")]
        public ActionResult Logout()
        {
            Session.Abandon();
            return View("Logout");
        }
        
    }
}
