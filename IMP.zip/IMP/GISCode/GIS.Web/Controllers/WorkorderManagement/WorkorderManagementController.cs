﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.Linq;
using Capgemini.GroupProduction.GIS.Web.ActionFilters;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.Web.Helpers;
using System.Text.RegularExpressions;
using Capgemini.GroupProduction.GIS.ValueObject;
using System;
using Capgemini.GroupProduction.GIS.ServiceNow.ValueObject;
using System.Configuration;
using Capgemini.GroupProduction.GIS.ServiceNow.Entity;
using System.IO;
using Capgemini.GroupProduction.GIS.Common;

namespace Capgemini.GroupProduction.GIS.Web.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [AuthorizationRequiredAttribute]
    public class WorkorderManagementController : Controller
    {

        /// <summary>
        /// Search Engagement Codes
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Index()
        {
            return View("SearchEngagementCode");
        }

        /// <summary>
        /// Select Services
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult SelectServices(string id)
        {
            var regex = @"^[A-Za-z0-9_]*$";
            var match = Regex.Match(id, regex, RegexOptions.IgnoreCase);
            if (match.Success == true)
            {
                HttpClientHelper clientHelper = new HttpClientHelper();
                //Check if Engagement details are available for a searched code
                WorkOrder engagementDetails = clientHelper.GetDataFromApi<WorkOrder>("/WorkorderManagement/getworkorderallservicemaster/" + id + "/0/");
                if (engagementDetails != null && engagementDetails.EngagementCode != null)
                {
                    ViewBag.EngagementCode = id;
                    ViewBag.CustomMessageList = engagementDetails.CustomMessageList;
                    return View("SelectServices", engagementDetails);
                }
                else
                {
                    //Redirect to Search Engagement Page in case of invalid code
                    return View("SearchEngagementCode");
                }
            }
            else
            {
                //Redirect to Search Engagement Page in case of invalid code
                return View("SearchEngagementCode");
            }
        }

        /// <summary>
        /// Load Work Order Details with Engagement Details
        /// </summary>
        /// <param name="code"></param>
        /// <param name="sender">Work Order Id</param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult LoadWorkOrderDetails(string code, string sender)
        {
            HttpClientHelper clientHelper = new HttpClientHelper();
            if (code != null)
            {
                //get default details from engagement
                WorkOrderDetailsVO woDetails = clientHelper.GetDataFromApi<WorkOrderDetailsVO>("/WorkorderManagement/getworkorderdetails/" + code + "/0");
                return View("WorkOrderDetails", woDetails);
            }
            else if (sender != null)
            {
                //get details for work order id
                WorkOrderDetailsVO woDetails = clientHelper.GetDataFromApi<WorkOrderDetailsVO>("/WorkorderManagement/getworkorderdetails/0/" + sender);
                return View("WorkOrderDetails", woDetails);
            }
            else
            {
                return View("SearchEngagementCode");
            }
        }

        /// <summary>
        /// Load Master Services
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult LoadMasterServices()
        {
            HttpClientHelper clientHelper = new HttpClientHelper();
            IEnumerable<ServiceMasterVO> serviceDetails = clientHelper.GetDataFromApi<IEnumerable<ServiceMasterVO>>("/WorkorderManagement/getservicedetails/0");
            return View("ServiceList", serviceDetails);
        }

        /// <summary>
        /// Work Order Confirmation View
        /// </summary>
        /// <param name="workOrder"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult ConfirmWorkOrderDetails(WorkOrder workOrder, string serviceuid)
        {
            HttpClientHelper clientHelper = new HttpClientHelper();
            Int64 workOrderID = clientHelper.PostDataToApi<WorkOrder, Int64>("/WorkorderManagement/createworkorder", workOrder);
            workOrder.WorkOrderId = workOrderID;

            TempData["ServiceIds"] = serviceuid;
            TempData["WorkOrderID"] = workOrderID;

            return RedirectToAction("GetWorkOrderSelectedService");
        }

        /// <summary>
        /// Get selected workorder selected service.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult GetWorkOrderSelectedService()
        {
            if (TempData["WorkOrderID"] == null || TempData["ServiceIds"] == null)
                return RedirectToAction("Index");

            Int64 workOrderID = (Int64)TempData["WorkOrderID"];
            string serviceIds = TempData["ServiceIds"].ToString();
            string[] serviceArr = serviceIds.Split(',');

            TempData["WorkOrderID"] = null;
            TempData["ServiceIds"] = null;

            WorkOrder workOrder = new WorkOrder();
            workOrder.WorkOrderId = workOrderID;
            workOrder.ServiceList = new List<ServiceMasterVO>();

            foreach (string serviceID in serviceArr)
            {
                ServiceMasterVO serviceMaster = new ServiceMasterVO();
                serviceMaster.ServiceId = int.Parse(serviceID);
                workOrder.ServiceList.Add(serviceMaster);
            }

            HttpClientHelper clientHelper = new HttpClientHelper();
            // ViewBag.WorkOrderId = id;
            WorkOrderServiceDetails workOrderSelServ = clientHelper.PostDataToApi<WorkOrder, WorkOrderServiceDetails>("/WorkorderManagement/getworkorderselservice", workOrder);
            ViewBag.CustomMessageList = workOrderSelServ.CustomMessageList.ToString();
            return View("CreateWorkOrder", workOrderSelServ);
        }

        /// <summary>
        /// Post work order selected service.
        /// </summary>
        /// <param name="workOrderService">Selected services.</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult WorkOrderSelectedService(IEnumerable<WorkOrderService> workOrderService)
        {
            HttpClientHelper clientHelper = new HttpClientHelper();
            //remove deleted services (i.e. service id as 0)
            var serviceList = from myObject in workOrderService
                              where myObject.ServiceId != 0
                              select myObject;
            //Pass UserId as created by
            serviceList = serviceList.Select(c => { c.UserID = Convert.ToInt64(HttpContext.Session["UserID"]); return c; }).ToList();

            WorkOrderServiceDetails workOrderSelServ = clientHelper.PostDataToApi<IEnumerable<WorkOrderService>,
                WorkOrderServiceDetails>("/WorkorderManagement/createworkorderservice",
                serviceList);

            //successful. reditect to work order page.
            if (workOrderSelServ.Transaction > 0)
            {

                TempData["Message"] = workOrderSelServ.Message;
                TempData["WorkOrderNum"] = workOrderSelServ.WorkOrder.WorkOrderNumber;

                //Check if Service Now instance is available for a work order
                ServiceNowInstance objSnowInstance = clientHelper.GetDataFromApi<ServiceNowInstance>("/ServiceNowManagement/getServiceNowInstance/" + workOrderSelServ.WorkOrder.WorkOrderId.Value);

                if (objSnowInstance != null && objSnowInstance.Active == true)
                {
                    string result = string.Empty;
                    ServiceWorkOrderVO workOrderDetails = new ServiceWorkOrderVO();
                    workOrderDetails.WorkOrderId = workOrderSelServ.WorkOrder.WorkOrderId.Value;
                    workOrderDetails.WorkOrderNumber = workOrderSelServ.WorkOrder.WorkOrderNumber;
                    workOrderDetails.SnowFilePath = ConfigurationManager.AppSettings.Get("ServiceNowFilePath");
                    workOrderDetails.FactoryId = objSnowInstance.FactoryId;
                    result = clientHelper.PostDataToApi<ServiceWorkOrderVO, String>("/ServiceNowManagement/generateWOFileforSnow/", workOrderDetails);
                    if (result == "failure")
                    {
                        //Redirect on error
                        TempData["errMsg"] = "Failed to create a work order, please try again later";
                        return RedirectToAction("Index");
                    }
                }
                //generate json
                clientHelper.PostDataToApi<WorkOrderServiceDetails>("/WorkorderManagement/WriteInputJsonData/", workOrderSelServ);

                return RedirectToAction("GetWorkOrder", new { id = workOrderSelServ.WorkOrder.WorkOrderId.Value });
            }
            //redirect to error page.
            return View("CreateWorkOrder", workOrderSelServ);
        }

        /// <summary>
        /// Ge work order details.
        /// </summary>
        /// <param name="id">work order id.</param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult GetWorkOrder(Int64 id)
        {
            ViewData["Message"] = TempData["Message"];

            ViewData["WorkOrderNum"] = TempData["WorkOrderNum"];

            HttpClientHelper clientHelper = new HttpClientHelper();

            WorkOrderVO workOrderSelServ = clientHelper.GetDataFromApi<WorkOrderVO>("/WorkorderManagement/getworkorder/" + id);

            return View("GetWorkOrder", workOrderSelServ);

        }

        /// <summary>
        /// Upload a file.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult UploadFile()
        {
            ViewData["FileType"] = ConfigurationManager.AppSettings["FileType"].ToString();
            return View("UploadFile");
        }

        /// <summary>
        /// Upload a status.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult UploadStatus()
        {
            ViewData["FileType"] = ConfigurationManager.AppSettings["FileType"].ToString();
            return View("UploadStatus");
        }

        /// <summary>
        /// View Work Orders
        /// </summary>
        /// <returns></returns>
        public ActionResult ViewWorkOrders()
        {
            HttpClientHelper clientHelper = new HttpClientHelper();
            //get default details from engagement
            IEnumerable<WorkOrder> woDetails = clientHelper.GetDataFromApi<IEnumerable<WorkOrder>>("/WorkorderManagement/getmyworkorders/");
            return View("MyWorkOrders", woDetails);
        }

        /// <summary>
        /// View Work Orders
        /// </summary>
        /// <returns></returns>
        public ActionResult ViewQueueWorkOrders()
        {
            HttpClientHelper clientHelper = new HttpClientHelper();
            //get default details from engagement
            IEnumerable<WorkOrder> woDetails = clientHelper.GetDataFromApi<IEnumerable<WorkOrder>>("/WorkorderManagement/getqueueworkorders/");
            return View("MyQueueWorkOrders", woDetails);
        }

        /// <summary>
        /// Get work order service status.
        /// </summary>
        /// <param name="id">work order id.</param>
        /// <returns>Action result.</returns>
        [HttpGet]
        public ActionResult GetWorkOrderServiceStatus(Int64 id)
        {
            HttpClientHelper clientHelper = new HttpClientHelper();
            WorkOrderVO workOrderSelServ = clientHelper.GetDataFromApi<WorkOrderVO>("/WorkorderManagement/getworkorder/" + id);
            ViewData["WorkOrderNum"] = workOrderSelServ.WorkOrder.WorkOrderNumber;
            ViewData["IsStatusEditable"] = false;
            return View("MyWorkOrderServiceStatus", workOrderSelServ);
        }

        /// <summary>
        /// Get Factory manager queue work order.
        /// </summary>
        /// <param name="id">work order id.</param>
        /// <returns>ActionResult result.</returns>
        [HttpGet]
        public ActionResult GetQueueWorkOrderServiceStatus(Int64 id)
        {
            HttpClientHelper clientHelper = new HttpClientHelper();
            WorkOrderVO workOrderSelServ = clientHelper.GetDataFromApi<WorkOrderVO>("/WorkorderManagement/getworkorder/" + id);
            ViewData["WorkOrderNum"] = workOrderSelServ.WorkOrder.WorkOrderNumber;
            ViewData["IsStatusEditable"] = (bool)Session["IsFactoryManager"] == true && workOrderSelServ.WorkOrder.IsServiceInstanceAvailable == false;
            ViewData["IsMyQueue"] = true;
            ViewData["ActiveMenu"] = 4;
            return View("MyWorkOrderServiceStatus", workOrderSelServ);
        }
        /// <summary>
        /// Load Work Order Details with Engagement Details
        /// </summary>
        /// <param name="code"></param>
        /// <param name="sender">Work Order Id</param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Download()
        {
            //if(string.IsNullOrEmpty(id))

            if (Request.QueryString["File"] == null || Request.QueryString["FileName"] == null)
            {
                return new EmptyResult();
            }

            string file = Request.QueryString["File"].ToString();
            string fileName = Request.QueryString["fileName"].ToString();

            string filePath = System.Configuration.ConfigurationManager.AppSettings["FileUploadPath"].ToString() + "\\" + file;

            if (!System.IO.File.Exists(filePath))
            {
                return new EmptyResult();
            }

            string extension = file.Substring(file.IndexOf(".") + 1);

            FileStream fileStream = new FileStream(filePath, FileMode.Open);

            string mimeApplicationType = System.Net.Mime.MediaTypeNames.Application.Octet;

            Response.AppendHeader("content-disposition", "attachment; filename=" + fileName);
            Response.ContentType = mimeApplicationType;

            return new FileStreamResult(fileStream, mimeApplicationType);
            // return File( System.Configuration.ConfigurationManager.AppSettings["FileUploadPath"].ToString() + id, System.Net.Mime.MediaTypeNames.Application.Octet); 
        }
    }
}