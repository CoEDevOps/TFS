﻿using System;
using System.Web.Mvc;
using System.Text;
using System.Configuration;
using System.Net.Http;
using System.Net;
using Capgemini.GroupProduction.GIS.Web;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.Web.Helpers;
using System.Collections.Generic;
//using Capgemini.GroupProduction.GIS.ValueObject;
using System.DirectoryServices;
using System.Web.SessionState;
using Capgemini.GroupProduction.GIS.Web.ActionFilters;
using Capgemini.GroupProduction.GIS.Common;
using Capgemini.GroupProduction.GIS.Report.ValueObject;


namespace Capgemini.GroupProduction.GIS.Web.Controllers
{
    [AuthorizationRequiredAttribute]
    public class ReportManagementController : Controller
    {

        [HttpGet]
        public ActionResult Index()
        {
            return View("Report");
        }

        [HttpGet]
        [ActionName("GetAllCharts")]
        public ActionResult GetAllCharts()
        {
            #region Bar and Pie chart region

            HttpClientHelper clientHelper = new HttpClientHelper();
            IEnumerable<PieChartVO> PieChart = clientHelper.GetDataFromApi<IEnumerable<PieChartVO>>("/ReportManagement/GetPieChart");
            IEnumerable<BarChartVO> BarChart = clientHelper.GetDataFromApi<IEnumerable<BarChartVO>>("/ReportManagement/GetBarChart");

            List<PieChartParamVO> PieChartLst = new List<PieChartParamVO>();

            foreach (var item in PieChart)
            {
                PieChartParamVO pieobj = new PieChartParamVO();
                pieobj.XAxisParameter = item.ServiceCount;
                pieobj.YAxisParameter = item.ServiceName;
                PieChartLst.Add(pieobj);
            }

            List<BarChartParamVO> BarChartLst = new List<BarChartParamVO>();

            foreach (var item in BarChart)
            {
                BarChartParamVO barobj = new BarChartParamVO();
                barobj.XAxisParameter = item.ServiceCount;
                barobj.YAxisParameter = item.ServiceName;
                BarChartLst.Add(barobj);
            }

            List<ChartVO> ChartLst = new List<ChartVO>();
            ChartVO chrtobj = new ChartVO();
            chrtobj.BarChart = BarChartLst;
            chrtobj.PieChart = PieChartLst;
            ChartLst.Add(chrtobj);

            return View("Report", ChartLst);

            #endregion
        }

    }

}