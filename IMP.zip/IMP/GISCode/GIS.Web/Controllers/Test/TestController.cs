﻿using System;
using System.Web.Mvc;
using System.Text;
using System.Configuration;
using System.Net.Http;
using System.Net;
using Capgemini.GroupProduction.GIS.Web;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.Base.Web.Helpers;
using System.Collections.Generic;
using Capgemini.GroupProduction.GIS.ValueObject;
using System.DirectoryServices;
using System.Web.SessionState;
using Capgemini.GroupProduction.GIS.Web.ActionFilters;
using Capgemini.GroupProduction.GIS.Common;
using Capgemini.GroupProduction.GIS.Entity.Test;

namespace Capgemini.GroupProduction.Base.Web.Controllers
{

   // [AuthorizationRequiredAttribute]
    public class TestController : Controller
    {
        /// <summary>
        /// Error page
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ActionName("Index")]
        public ActionResult Index()
        {            
            return View("Home");
        }

        /// <summary>
        /// Error page
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [ActionName("Index")]
        public ActionResult Index(Student student)
        {
            if(!this.ModelState.IsValid)
            {
                return View("Home", student);
            }

            return View("Home", student);
        }
    }
}
