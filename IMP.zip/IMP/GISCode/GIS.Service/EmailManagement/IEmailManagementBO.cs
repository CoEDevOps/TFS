﻿using Capgemini.GroupProduction.GIS.ValueObject;
using System;

namespace Capgemini.GroupProduction.GIS.ServiceInterface
{
    /// <summary>
    /// Email Managememnt
    /// </summary>
    public interface IEmailManagementBO
    {       
        /// <summary>
        /// Send Mail to Factory Manager when new work order created
        /// </summary>
        /// <param name="workOrderService"></param>
        String NotifyFMNewWorkOrder(Int64 workOrderId);

        /// <summary>
        /// Send Acknowledgement Mail to User
        /// </summary>
        /// <param name="workOrderId"></param>
        /// <returns></returns>
        String NotifyUserNewWorkOrder(Int64 workOrderId);

        /// <summary>
        /// Notify User on Status Change
        /// </summary>
        /// <param name="updatedStatus"></param>
        /// <returns></returns>
        String NotifyUserStatusChange(EmailStatus updatedStatus);
    }
}
