﻿using Capgemini.GroupProduction.GIS.RepositoryInterface;
using Capgemini.GroupProduction.GIS.ServiceInterface;
using Capgemini.GroupProduction.GIS.ValueObject;
using System;
using Capgemini.GroupProduction.GIS.Common;
using Capgemini.GroupProduction.GIS.Entity;
using System.Configuration;
using System.Text;
using Capgemini.GroupProduction.GIS.Repository;

namespace Capgemini.GroupProduction.GIS.Service
{
    /// <summary>
    /// Email management
    /// </summary>
    public class EmailManagementBO : IEmailManagementBO
    {

        private readonly IEmailManagementDO m_emailmanagementRepository;
        public readonly IWorkorderManagementBO m_workorderMgmtService;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="serviceMgmtRepository"></param>
        public EmailManagementBO(IEmailManagementDO serviceMgmtRepository)
        {
            m_emailmanagementRepository = serviceMgmtRepository;
            m_workorderMgmtService = new WorkorderManagementBO(new WorkorderManagementDO(), new CommonDO());
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="serviceMgmtRepository"></param>
        public EmailManagementBO()
        {

        }

        /// <summary>
        /// Gets New Work Order details and sends out email to FM
        /// </summary>
        /// <param name="workOrderId"></param>
        /// <returns></returns>
        public String NotifyFMNewWorkOrder(Int64 workOrderId)
        {
            NewWorkOrderVO woDetails = this.GetNewWorkOrderDetails(workOrderId);
            if (woDetails != null)
            {
                string[] strtmpArray = new string[9];
                strtmpArray[0] = woDetails.User;
                strtmpArray[1] = woDetails.WorkOrderNumber;
                strtmpArray[2] = woDetails.EngagementCode;
                strtmpArray[3] = woDetails.EngagementName;
                strtmpArray[4] = woDetails.ProjectManager;
                strtmpArray[5] = woDetails.CustomerName;
                strtmpArray[6] = String.Format("{0:dd/MM/yyyy}", woDetails.StartDate);
                strtmpArray[7] = String.Format("{0:dd/MM/yyyy}", woDetails.EndDate);
                strtmpArray[8] = woDetails.Services;

                Email objEmail = new Email();
                objEmail.SendMail(woDetails.FactoryManagerEmailIDs, "New work order created #" + woDetails.WorkOrderNumber,
                    ConfigurationManager.AppSettings["EmailTemplatePath"] + "FM_NewWorkOrder.html", strtmpArray);
                return "success";
            }
            return "failure";
        }

        /// <summary>
        /// Send Acknowledgement Mail to User
        /// </summary>
        /// <param name="workOrderId"></param>
        /// <returns></returns>
        public String NotifyUserNewWorkOrder(Int64 workOrderId)
        {
            NewWorkOrderVO woDetails = this.GetNewWorkOrderDetails(workOrderId);
            if (woDetails != null)
            {
                string[] strtmpArray = new string[9];
                strtmpArray[0] = woDetails.User;
                strtmpArray[1] = woDetails.WorkOrderNumber;
                strtmpArray[2] = woDetails.EngagementCode;
                strtmpArray[3] = woDetails.EngagementName;
                strtmpArray[4] = woDetails.ProjectManager;
                strtmpArray[5] = woDetails.CustomerName;
                strtmpArray[6] = String.Format("{0:dd/MM/yyyy}", woDetails.StartDate);
                strtmpArray[7] = String.Format("{0:dd/MM/yyyy}", woDetails.EndDate);
                strtmpArray[8] = woDetails.Services;

                Email objEmail = new Email();
                objEmail.SendMail(woDetails.UserEmail, "New work order created #" + woDetails.WorkOrderNumber,
                    ConfigurationManager.AppSettings["EmailTemplatePath"] + "User_NewWorkOrder.html", strtmpArray);
                return "success";
            }
            return "failure";
        }

        /// <summary>
        /// Notify User on status update
        /// </summary>
        /// <param name="updatedStatus"></param>
        /// <returns></returns>
        public String NotifyUserStatusChange(EmailStatus updatedStatus)
        {
            NewWorkOrderVO woDetails = this.GetNewWorkOrderDetails(updatedStatus.WorkOrderId.Value);

            if (woDetails != null)
            {
                string[] strtmpArray = new string[11];
                string strSub;
                string serviceUpdated;
                strtmpArray[0] = woDetails.User;
                strtmpArray[1] = woDetails.WorkOrderNumber;
                strtmpArray[2] = woDetails.WorkOrderReferenceNo == null ? "NA" : woDetails.WorkOrderReferenceNo;
                strtmpArray[3] = woDetails.EngagementCode;
                strtmpArray[4] = woDetails.EngagementName;
                strtmpArray[5] = woDetails.CustomerName;
                strtmpArray[6] = woDetails.PriorityType.ToString();
                strtmpArray[7] = String.Format("{0:dd/MM/yyyy}", woDetails.StartDate);
                strtmpArray[8] = String.Format("{0:dd/MM/yyyy}", woDetails.EndDate);
                strtmpArray[9] = Enum.IsDefined(typeof(WorkorderStatus), woDetails.Status) == true ?
                    Enum.Parse(typeof(WorkorderStatus), woDetails.Status.ToString()).ToString().Replace("_", " ") : String.Empty;
                woDetails.Services = FormatServicesSelectedWithStatus(updatedStatus, out serviceUpdated);
                strtmpArray[10] = woDetails.Services;

                strSub = FormatStatusUpdateSubject(updatedStatus, woDetails.WorkOrderNumber, serviceUpdated);
                Email objEmail = new Email();
                objEmail.SendMail(woDetails.UserEmail, strSub,
                    ConfigurationManager.AppSettings["EmailTemplatePath"] + "User_StatusChange.html", strtmpArray);
                return "success";
            }
            return "failure";
        }

        #region Private Methods

        /// <summary>
        /// Get New work order details
        /// </summary>
        /// <param name="workOrderId"></param>
        /// <returns></returns>
        private NewWorkOrderVO GetNewWorkOrderDetails(Int64 workOrderId)
        {
            return m_emailmanagementRepository.GetNewWorkOrderDetails(workOrderId);
        }

        /// <summary>
        /// Format Services Selected
        /// </summary>
        /// <param name="strServiceCsv"></param>
        /// <returns></returns>
        private string FormatServicesSelected(string strServiceCsv)
        {

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<ul>");
            string[] services = strServiceCsv.Split(',');
            if (services.Length > 1)
            {
                foreach (string str in services)
                {
                    sb.AppendLine("<li>" + str + "</li>");
                }
            }
            else
            {
                sb.AppendLine("<li>" + strServiceCsv + "</li>");
            }
            sb.AppendLine("</ul>");
            return sb.ToString();
        }

        /// <summary>
        /// Format services with status
        /// </summary>
        /// <param name="statusDetails"></param>
        /// <param name="updatedServiceName"></param>
        /// <returns></returns>
        private string FormatServicesSelectedWithStatus(EmailStatus statusDetails, out string updatedServiceName)
        {
            WorkOrderVO workOrderVo = m_workorderMgmtService.GetSavedWorkOrderService(statusDetails.WorkOrderId.Value);
            updatedServiceName = String.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<table class='tableServices'>");
            sb.AppendLine("<tr>");
            sb.AppendLine("<td><b>Service</b></td>");
            sb.AppendLine("<td><b>Status</b></td>");
            sb.AppendLine("</tr>");

            foreach (WorkOrderServiceVO woService in workOrderVo.WorkOrderService)
            {
                sb.AppendLine("<tr>");

                if ((statusDetails.WorkOrderServiceId != null) && (woService.WorkOrderServiceId == statusDetails.WorkOrderServiceId.Value))
                {
                    updatedServiceName = woService.ServiceName;
                }
                sb.AppendLine("<td width='70%'>" + woService.ServiceName + "</td>");
                sb.AppendLine("<td width='30%'>");
                sb.AppendLine(Enum.IsDefined(typeof(ServiceStatus), woService.Status) == true ?
                    Enum.Parse(typeof(ServiceStatus), woService.Status.ToString()).ToString().Replace("_", " ") : String.Empty);
                sb.AppendLine("</td>");
                sb.AppendLine("</tr>");
            }

            sb.AppendLine("</table>");
            return sb.ToString();
        }

        /// <summary>
        /// Format Subject as per status
        /// </summary>
        /// <param name="statusDetails"></param>
        /// <param name="workOrderNumber"></param>
        /// <param name="serviceUpdated"></param>
        /// <returns></returns>
        private string FormatStatusUpdateSubject(EmailStatus statusDetails, string workOrderNumber, string serviceUpdated)
        {
            string strStatus = String.Empty;
            string strSub = String.Empty;
            if (statusDetails.WorkOrderServiceId != null)
            {
                //Service status update
                strStatus = Enum.IsDefined(typeof(ServiceStatus), statusDetails.Status) == true ?
                    Enum.Parse(typeof(ServiceStatus), statusDetails.Status.ToString()).ToString().Replace("_", " ") : String.Empty;
                strSub = "Work order #" + workOrderNumber + " - Service (" + serviceUpdated.Trim() + ") Status: " + strStatus;
            }
            else
            {
                //Work order status update
                strStatus = Enum.IsDefined(typeof(WorkorderStatus), statusDetails.Status) == true ?
                    Enum.Parse(typeof(WorkorderStatus), statusDetails.Status.ToString()).ToString().Replace("_", " ") : String.Empty;
                strSub = "Work order #" + workOrderNumber + " Status: " + strStatus;
            }
            return strSub;
        }
        #endregion
    }
}
