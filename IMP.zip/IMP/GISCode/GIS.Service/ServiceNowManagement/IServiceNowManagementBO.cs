﻿using Capgemini.GroupProduction.GIS.ServiceNow.Entity;
using System;

namespace Capgemini.GroupProduction.GIS.ServiceInterface
{
    /// <summary>
    /// Service Now management.
    /// </summary>
    public interface IServiceNowManagementBO
    {
        /// <summary>
        /// Update service reference Ids from SNOW to VTF
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="requestNumber"></param>
        /// <param name="workOrderId"></param>
        void UpdateWorkOrderReferenceIds(string requestId, string requestNumber, Int64 workOrderId);

        /// <summary>
        /// Update work order reference Ids from SNOW to VTF
        /// </summary>
        /// <param name="serviceRequestId"></param>
        /// <param name="serviceRequestNumber"></param>
        /// <param name="workOrderId"></param>
        /// <param name="serviceId"></param>
        void UpdateServiceReferencIds(string serviceRequestId, string serviceRequestNumber, Int64 workOrderId, Int64 serviceId);

        /// <summary>
        /// Reset Work Order Number and other reference Ids if snow push process fails
        /// </summary>
        /// <param name="workOrderId"></param>
        void ResetWorkOrderReferenceFlags(Int64 workOrderId);

        /// <summary>
        /// Get Snow Instance Details
        /// </summary>
        /// <param name="workOrderId"></param>
        /// <returns></returns>
        ServiceNowInstance GetServiceNowInstanceDetails(Int64 workOrderId); 
    }
}
