﻿using Capgemini.GroupProduction.GIS.RepositoryInterface;
using Capgemini.GroupProduction.GIS.ServiceInterface;
using Capgemini.GroupProduction.GIS.ServiceNow.Entity;
using System;

namespace Capgemini.GroupProduction.GIS.Service
{
    /// <summary>
    /// Service now management.
    /// </summary>
    public class ServiceNowManagementBO : IServiceNowManagementBO
    {
        private readonly IServiceNowManagementDO m_ServiceNowMgmtRepository;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="serviceMgmtRepository"></param>
        public ServiceNowManagementBO(IServiceNowManagementDO serviceMgmtRepository)
        {
            m_ServiceNowMgmtRepository = serviceMgmtRepository;
        }


        /// <summary>
        /// Update service reference Ids from SNOW to VTF
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="requestNumber"></param>
        /// <param name="workOrderId"></param>
        public void UpdateWorkOrderReferenceIds(string requestId, string requestNumber, Int64 workOrderId)
        {
            m_ServiceNowMgmtRepository.UpdateWorkOrderReferenceIds(requestId, requestNumber, workOrderId);
        }

        /// <summary>
        /// Update work order reference Ids from SNOW to VTF
        /// </summary>
        /// <param name="serviceRequestId"></param>
        /// <param name="serviceRequestNumber"></param>
        /// <param name="workOrderId"></param>
        /// <param name="serviceId"></param>
        public void UpdateServiceReferencIds(string serviceRequestId, string serviceRequestNumber, Int64 workOrderId, Int64 serviceId)
        {
            m_ServiceNowMgmtRepository.UpdateServiceReferencIds(serviceRequestId, serviceRequestNumber, workOrderId, serviceId);
        }

        /// <summary>
        /// Reset Work Order Number and other reference Ids if snow push process fails
        /// </summary>
        /// <param name="workOrderId"></param>
        public void ResetWorkOrderReferenceFlags(Int64 workOrderId)
        {
            m_ServiceNowMgmtRepository.ResetWorkOrderReferenceFlags(workOrderId);
        }

        /// <summary>
        /// Get Snow Instance Details
        /// </summary>
        /// <param name="workOrderId"></param>
        /// <returns></returns>
        public ServiceNowInstance GetServiceNowInstanceDetails(Int64 workOrderId)
        {
            return m_ServiceNowMgmtRepository.GetServiceNowInstanceDetails(workOrderId);
        }
    }
}
