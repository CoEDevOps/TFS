﻿using System.Collections.Generic;
using Capgemini.GroupProduction.GIS.Entity;
using System;

namespace Capgemini.GroupProduction.GIS.ServiceInterface
{
    /// <summary>
    /// Interface for usermanagement service.
    /// </summary>
    public interface IUserManagmentBO
    {      

        /// <summary>
        /// Authenticate user.
        /// </summary>
        /// <param name="userName">User name</param>
        /// <param name="password">Password</param>
        /// <returns>User entity for the credentials provided.Null in case user not found</returns>
        User Authenticate(string userName, string password);

        /// <summary>
        /// Generate session token and add in database.
        /// </summary>
        /// <returns>Session entity</returns>
        Session GenerateSession();

        /// <summary>
        /// Validate the session.
        /// </summary>
        /// <param name="sessionID">Session ID</param>
        /// <returns>Valid session id will return true.</returns>
        bool ValidateSession(string sessionID);              

        /// <summary>
        /// Get Menu Items
        /// </summary>
        /// <returns></returns>
        IEnumerable<MenuEntity> GetMenuItem();        

        /// <summary>
        /// Add new user.
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        User AddUser(User user);

        /// <summary>
        /// Get menu items based on the role of the user.
        /// </summary>
        /// <param name="userID">User id.</param>       
        /// <returns>Menu items based on user role.</returns>
        IEnumerable<RoleAccess> GetRoleAccessAll(Int64 userID);


        /// <summary>
        /// Get role access item based on the role of the user.
        /// </summary>
        /// <param name="userID">User id.</param>       
        /// <returns>RoleAccess items based on user role.</returns>
        IEnumerable<MenuEntity> GetRoleMenuItem(Int64 userID);
        
        /// <summary>
        /// Get username on the basis of userid.
        /// </summary>
        /// <param name="userID">User id.</param>       
        /// <returns>username based on userid.</returns>
        User GetUserName(int UserID);
    }
}
