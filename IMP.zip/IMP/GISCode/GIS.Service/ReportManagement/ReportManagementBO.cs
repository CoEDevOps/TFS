﻿using System;
using System.Collections.Generic;
using System.Linq;
using Capgemini.GroupProduction.GIS.ServiceInterface;
using Capgemini.GroupProduction.GIS.RepositoryInterface;
using Capgemini.GroupProduction.GIS.Entity;
using System.Configuration;
using Capgemini.GroupProduction.GIS.ValueObject;
using Capgemini.GroupProduction.GIS.Report.ValueObject;

namespace Capgemini.GroupProduction.GIS.Service
{
    public class ReportManagementBO : IReportManagementBO
    {
        private readonly IReportManagementDO _reportMgtRepository;

        public ReportManagementBO(IReportManagementDO reportMgtRepository)
        {
            _reportMgtRepository = reportMgtRepository;
        }

        public IEnumerable<PieChartVO> GetPieChart()
        {
            IEnumerable<PieChartVO> pieChartData = _reportMgtRepository.GetPieChart().ToList();
            return pieChartData;
        }

        public IEnumerable<BarChartVO> GetBarChart()
        {
            IEnumerable<BarChartVO> barChartData = _reportMgtRepository.GetBarChart().ToList();
            return barChartData;
        }
    }
}
