﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.Report.ValueObject;

namespace Capgemini.GroupProduction.GIS.ServiceInterface
{
    public interface IReportManagementBO
    {
        IEnumerable<PieChartVO> GetPieChart();

        IEnumerable<BarChartVO> GetBarChart();

    }
}
