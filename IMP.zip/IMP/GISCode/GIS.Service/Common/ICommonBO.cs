﻿using Capgemini.GroupProduction.GIS.Entity;

namespace Capgemini.GroupProduction.GIS.Service.Common
{
    /// <summary>
    /// Common bussiness component interface.
    /// </summary>
    public interface ICommonBO
    {
        CustomMessage GetMessage(string messageKey);
    }
}
