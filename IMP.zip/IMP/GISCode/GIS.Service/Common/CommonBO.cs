﻿using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.Repository;

namespace Capgemini.GroupProduction.GIS.Service.Common
{
    /// <summary>
    /// Common bussiness component
    /// </summary>
    public class CommonBO : ICommonBO
    {
        private readonly ICommonDO m_commonDO;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="serviceMgmtRepository"></param>
        public CommonBO(ICommonDO commonRepository)
        {
            m_commonDO = commonRepository;
        }

        public CustomMessage GetMessage(string messageKey)
        {
            return m_commonDO.GetMessage(messageKey);
        }
    }
}
