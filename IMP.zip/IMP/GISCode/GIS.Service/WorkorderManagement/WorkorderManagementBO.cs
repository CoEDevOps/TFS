﻿using System.Collections.Generic;
using System.Linq;
using Capgemini.GroupProduction.GIS.ServiceInterface;
using Capgemini.GroupProduction.GIS.RepositoryInterface;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.ValueObject;
using System;
using Capgemini.GroupProduction.GIS.Repository;
using Capgemini.GroupProduction.GIS.Common;

namespace Capgemini.GroupProduction.GIS.Service
{
    /// <summary>
    /// Work order management.
    /// </summary>
    public class WorkorderManagementBO :IWorkorderManagementBO
    {
        private readonly IWorkorderManagementDO m_workordermgmtRepository;
        private readonly ICommonDO m_commonRepository;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="serviceMgmtRepository"></param>
        public WorkorderManagementBO(IWorkorderManagementDO serviceMgmtRepository, ICommonDO commonRepository)
        {
            m_workordermgmtRepository = serviceMgmtRepository;
            m_commonRepository = commonRepository;
        }

        /// <summary>
        /// Search Engagement Codes
        /// </summary>
        /// <param name="strKeyword"></param>
        /// <returns></returns>
        public IEnumerable<EngagementCodeVO> SearchEngagementCodes(string strKeyword)
        {
            IEnumerable<EngagementCodeVO> engmtCodes = m_workordermgmtRepository.SearchEngagementCodes(strKeyword).ToList();
            return engmtCodes;
        }

        /// <summary>
        /// Get Work Order Details with Engagement details
        /// </summary>
        /// <param name="engmtCode"></param>
        /// <param name="workOrderId"></param>
        /// <returns></returns>
        public WorkOrderDetailsVO GetWorkOrderDetails(string engmtCode, Int64 workOrderId)
        {
            WorkOrderDetailsVO woDetails = m_workordermgmtRepository.GetWorkOrderDetails(engmtCode, workOrderId);
            return woDetails;
        }

        /// <summary>
        /// Get Service List
        /// </summary>
        /// <param name="serviceId"></param>
        /// <returns></returns>
        public IEnumerable<ServiceMasterVO> GetServiceList(int serviceId)
        {
            IEnumerable<ServiceMasterVO> serviceList = m_workordermgmtRepository.GetServiceList(serviceId).ToList();
            return serviceList;
        }


        /// <summary>
        /// Add New Work Order Details
        /// </summary>
        /// <param name="workOrderDetails"></param>
        /// <returns></returns>
        public Int64 AddWorkOrderDetails(WorkOrder workOrderDetails)
        {
            Int64 workOrder = m_workordermgmtRepository.AddWorkOrderDetails(workOrderDetails);                      
            return workOrder;
        }

        /// <summary>
        /// Add Work Order Services
        /// </summary>
        /// <param name="workOrderServiceDetails"></param>
        /// <param name="workOrder"></param>
        public WorkOrderServiceDetails AddWorkOrderServiceDetails(IEnumerable<WorkOrderService> workOrderServiceDetails)
        {
            return m_workordermgmtRepository.AddWorkOrderServiceDetails(workOrderServiceDetails);                                  
        }


        /// <summary>
        /// Get Service List
        /// </summary>
        /// <param name="workOrder"></param>
        /// <returns></returns>
        public WorkOrder GetWorkOrderAllServiceMaster(string engmtCode)
        {
            WorkOrderDetailsVO woDetails = m_workordermgmtRepository.GetWorkOrderDetails(engmtCode, 0);
            
            IEnumerable<ServiceMasterVO> serviceList = m_workordermgmtRepository.GetServiceList(0).ToList();

            WorkOrder workOrder = new WorkOrder();          
            workOrder.EngagementCode = woDetails.EngagementCode;
            workOrder.CustomerName = woDetails.CustomerName;
            workOrder.EngagementName = woDetails.EngagementName;
            workOrder.Priority = woDetails.Priority;
            workOrder.ProjectManager = woDetails.ProjectManager;
            workOrder.StartDate = DateTime.Now;
            workOrder.EndDate = DateTime.Now;

            workOrder.ServiceList = serviceList.ToList();
            /* VN2: Need to check whic is the best place to declare the message groups.
             */
            string msgGroups = string.Format("{0},{1},{2}", MessageGroups.WorkOrder, MessageGroups.Common, MessageGroups.Service);
            workOrder.CustomMessageList = m_commonRepository.GetMessageByGroup(msgGroups);

            return workOrder;

        }

        /// <summary>
        /// Get Service List
        /// </summary>
        /// <param name="workOrder"></param>
        /// <returns></returns>
        public WorkOrderServiceDetails GetWorkOrderWithSelectedService(WorkOrder workOrder)
        {
            long workOrderID = workOrder.WorkOrderId.Value;

            WorkOrderServiceDetails workOrderVOService = new WorkOrderServiceDetails();
           //fetch the  work work.
            workOrderVOService.WorkOrder = m_workordermgmtRepository.GetWorkOrderDetails(string.Empty, workOrderID);

            IEnumerable<int> lstService = workOrder.ServiceList.Select(x => x.ServiceId);

            if (lstService.Count() == 0)
            {
                return workOrderVOService;
            }

            //fetch the services
            IEnumerable<ServiceMasterVO> lstWorkORderService = m_workordermgmtRepository.GetServiceList(lstService);

            //Populate the service 
            List<WorkOrderService> lstworkOrder = new List<WorkOrderService>();

            foreach (ServiceMasterVO serviceMaster in lstWorkORderService)
            {
                WorkOrderService workOrderService = new WorkOrderService();
                workOrderService.ServiceId = serviceMaster.ServiceId;
                workOrderService.WorkOrderID = workOrderID;
                workOrderService.ServiceName = serviceMaster.ServiceName;
                workOrderService.StartDate = DateTime.Now;
                workOrderService.EndDate = DateTime.Now;
                lstworkOrder.Add(workOrderService);
            }           

            workOrderVOService.WorkOrderService = lstworkOrder;
            /* VN2: Need to check whic is the best place to declare the message groups.
            */
            string msgGroups = string.Format("{0},{1},{2},{3},{4}", MessageGroups.WorkOrder, MessageGroups.Common, 
                MessageGroups.Service, MessageGroups.FileUpload, MessageGroups.Session);
            workOrderVOService.CustomMessageList = m_commonRepository.GetMessageByGroup(msgGroups);

            return workOrderVOService;

        }

        public WorkOrderVO GetSavedWorkOrderService(Int64 workerId)
        {

            WorkOrderVO workOrderVOService = new WorkOrderVO();
            //fetch the  work work.
            workOrderVOService.WorkOrder = m_workordermgmtRepository.GetWorkOrderDetails(string.Empty, workerId);

            //fetch the services
            workOrderVOService.WorkOrderService = m_workordermgmtRepository.GetServiceByWorkOrderId(workerId).ToList();           

            return workOrderVOService;

        }


        /// <summary>
        /// Get My Work Orders
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public IEnumerable<WorkOrder> GetMyWorkOrders(string userId)
        {
            return m_workordermgmtRepository.GetMyWorkOrders(userId);
        }

        /// <summary>
        /// Get My Work Orders
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public IEnumerable<WorkOrder> GetQueueWorkOrders(string userId)
        {
            return m_workordermgmtRepository.GetQueueWorkOrders(userId);
        }

        /// <summary>
        /// Update the work order service status.
        /// </summary>
        /// <param name="serviceVO">Service object.</param>
        /// <returns>WorkOrder service with updated status.</returns>
        public WorkOrderServiceVO UpdateWorkOrderServiceStatus(WorkOrderServiceVO serviceVO)
        {
            WorkOrderServiceVO service = m_workordermgmtRepository.UpdateWorkOrderServiceStatus(serviceVO);

            return service;

        }

        /// <summary>
        /// Update the work order status.
        /// </summary>
        /// <param name="workOrderVO">work order object.</param>
        /// <returns>WorkOrder with updated status.</returns>
        public WorkOrderDetailsVO UpdateWorkOrderStatus(WorkOrderDetailsVO workOrderVO)
        {
            WorkOrderDetailsVO workOrder = m_workordermgmtRepository.UpdateWorkOrderStatus(workOrderVO);

            return workOrder;

        }
    }
}
