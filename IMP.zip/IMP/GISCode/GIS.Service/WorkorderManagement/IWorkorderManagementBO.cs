﻿using System.Collections.Generic;
using Capgemini.GroupProduction.GIS.Entity;
using Capgemini.GroupProduction.GIS.ValueObject;
using System;

namespace Capgemini.GroupProduction.GIS.ServiceInterface
{
    /// <summary>
    /// Work order management
    /// </summary>
    public interface IWorkorderManagementBO
    {
        /// <summary>
        /// Search Engagement
        /// </summary>
        /// <returns></returns>
        IEnumerable<EngagementCodeVO> SearchEngagementCodes(string strKeyword);

        /// <summary>
        /// Get Work Order Details with Engagement details
        /// </summary>
        /// <param name="engmtCode"></param>
        /// <param name="woroOrderId"></param>
        /// <returns></returns>
        WorkOrderDetailsVO GetWorkOrderDetails(string engmtCode,Int64 woroOrderId);

        /// <summary>
        /// Get Service List
        /// </summary>
        /// <param name="serviceId"></param>
        /// <returns></returns>
        IEnumerable<ServiceMasterVO> GetServiceList(int serviceId);

        WorkOrder GetWorkOrderAllServiceMaster(string engmtCode);

        /// <summary>
        /// Add New Work Order Details
        /// </summary>
        /// <param name="workOrder"></param>
        /// <returns></returns>
        Int64 AddWorkOrderDetails(WorkOrder workOrderDetails);

        /// <summary>
        /// Add Work Order Services
        /// </summary>
        /// <param name="workOrderServiceDetails"></param>
        /// <param name="workOrder"></param>
        WorkOrderServiceDetails AddWorkOrderServiceDetails(IEnumerable<WorkOrderService> workOrderServiceDetails);

        WorkOrderServiceDetails GetWorkOrderWithSelectedService(WorkOrder workOrder);

        WorkOrderVO GetSavedWorkOrderService(Int64 workerId);

        /// <summary>
        /// Get Work Orders Submitted for User
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        IEnumerable<WorkOrder> GetMyWorkOrders(string userId);

        /// <summary>
        /// Get My Work Orders
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        IEnumerable<WorkOrder> GetQueueWorkOrders(string userId);


        /// <summary>
        /// Update the work order service status.
        /// </summary>
        /// <param name="serviceVO">Service object.</param>
        /// <returns>WorkOrder service with updated status.</returns>
        WorkOrderServiceVO UpdateWorkOrderServiceStatus(WorkOrderServiceVO serviceVO);

        /// <summary>
        /// Update the work order status.
        /// </summary>
        /// <param name="workOrderVO">work order object.</param>
        /// <returns>WorkOrder with updated status.</returns>
        WorkOrderDetailsVO UpdateWorkOrderStatus(WorkOrderDetailsVO workOrderVO);
        
    }
}
