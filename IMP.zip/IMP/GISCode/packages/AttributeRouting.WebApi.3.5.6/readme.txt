AttributeRouting v3.*

Upgrading from v2 or v1? Please read about breaking changes here:

https://github.com/mccalltd/AttributeRouting/wiki/Upgrading-to-v3
