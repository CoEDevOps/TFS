﻿using System;
using System.Web.Mvc;

namespace Capgemini.GroupProduction.GIS.Grid
{
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IGridColumn<T> : IGridColumn where T : class
    {       
        IGridColumn<T> SetWidth(int width);
        IGridColumn<T> Css(string cssClass);
        IGridColumn<T> Titled(string title);
        MvcHtmlString RenderCell(T instance, int index);
       
        IGridColumn<T> RenderValueAs(Func<T, int, string> constraint);
    }

    /// <summary>
    /// 
    /// </summary>
    public interface IGridColumn 
    {
        MvcHtmlString RenderCell(object instance, int index);
        MvcHtmlString RenderHeader();
    }
}
