﻿using Capgemini.GroupProduction.GIS.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.GIS.Common
{
    public interface IMasterData
    {
        IEnumerable<RoleAccess> GetRoleAccess(Int64 userID);
    }
}
