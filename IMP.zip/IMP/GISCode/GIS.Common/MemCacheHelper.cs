﻿using Capgemini.GroupProduction.GIS.Entity;
using Memcached.ClientLibrary;
using System;
using System.Collections.Generic;
using System.Web;

namespace Capgemini.GroupProduction.GIS.Common
{
    /// <summary>
    /// Singleton class for configuration of the application.
    /// There is only one instance of the SysAppConfig in the application.
    /// Single instance created in the thread safe way.
    /// </summary>
    public class MemCacheHelper
    {
     
        static MemCacheHelper()
        {
            /*Initialize the memcache server*/            
            SockIOPool pool = SockIOPool.GetInstance();
            pool.SetServers(new string[] { System.Configuration.ConfigurationManager.AppSettings["MemcacheServer"].ToString() });
            pool.Initialize();
        }     

       
        /// <summary>
        /// Get all the role master data from the WebAPi. 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public static IEnumerable<RoleAccess> GetAllRoleAccess(Int64 userID, IMasterData masterData)
        {
           
            //In case the cache is null then get the all the role access.
            MemcachedClient memcacheClient = new MemcachedClient(); 
            if (memcacheClient.Get("GisRoleAccessMaster") == null)
            {
                IEnumerable<RoleAccess> roleAccess = masterData.GetRoleAccess(userID);
                memcacheClient.Add("GisRoleAccessMaster", roleAccess, DateTime.Now.AddHours(5));
                
                return roleAccess;
            }

            return (IEnumerable<RoleAccess>)memcacheClient.Get("GisRoleAccessMaster");
        }


    }

}