﻿using Capgemini.GroupProduction.Base.Common;
using Capgemini.GroupProduction.Base.Entity;
using Capgemini.GroupProduction.Base.Web.Helpers;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace Capgemini.GroupProduction.Base.Web.ActionFilters
{
    /// <summary>
    /// The filter is called before every action is executed to check if the user is authenticated. 
    /// The user authenticated with window user name and his details are saved in the session.
    /// </summary>
    public class AuthorizationRequiredAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// Checks if the User Session variable is initialized and redirects to
        /// Login page in it is not initialized. Check if the authenticated 
        /// user is authorized to access the resource. In case the user is not authorized then 
        /// redirects to "Unauthorized" page.
        /// </summary>
        /// <param name="filterContext">request context</param>
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);
            Controller controllerBase = (Controller)filterContext.Controller;
            /*
             * During the first request when the Session variable is set then 
             * the value is in the mmemory. The value is saved in the Database when the 
             * request is fully processed. The exact point of insertion in database is 
             * unknown but the it is not saved when variable is set. For this reason 
             * when the session variable is null(user has first accessed) then the 
             * Session["UserName"] varaible is set and redirected to UserManagment/Login 
             * page with the reutrn Url. As the Session["UserName"] is set and current page is fully 
             * processed then the Session record is inserted in database. So in "UserManagment/Login"
             * LDAP authentication and getting the user details from database and seting the user details 
             * in session variables is done. Finnaly the User is redireted to the return url which is the 
             * requested page.
             */
            if (controllerBase.Session["UserID"] == null)
            {
                LDAPAuthention userAuthentication = new LDAPAuthention();
                controllerBase.Session["UserName"] = userAuthentication.CurrentUser;
               
                string actionName = filterContext.ActionDescriptor.ActionName;
                string controllerName = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;
               

                filterContext.Result = new RedirectResult("~/UserManagement/Login/" + actionName + "?controller=" + controllerName);                             
            }
            else
            {
                string actionName = filterContext.ActionDescriptor.ActionName;
                string controllerName = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;

                Int64 userID = (Int64)controllerBase.Session["UserID"];
                string roleIds = (string)controllerBase.Session["RoleIDs"];

                User user = new User();
                user.UserID = userID;
                user.RoleIds = roleIds;
                UserAuthorization controllerActionRole = new UserAuthorization(user);              
                IEnumerable<RoleAccess> roleAccess = MemCacheHelper.GetAllRoleAccess(userID, new MasterData());
                string url = string.Format(@"{0}/{1}", controllerName, actionName);

                if (!controllerActionRole.IsUrlAuthorized(url, roleAccess))
                {
                    filterContext.Result = new RedirectResult("~/UserManagement/Unauthorized");                    
                }                
            }
        }


        /// <summary>
        ///  Appends the standard headers in the response.
        /// </summary>
        /// <param name="filterContext">Request context.</param>
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            base.OnActionExecuted(filterContext);

            filterContext.HttpContext.Response.Expires = -1;
            filterContext.HttpContext.Response.Cache.SetNoServerCaching();
            filterContext.HttpContext.Response.Cache.SetAllowResponseInBrowserHistory(false);
            filterContext.HttpContext.Response.CacheControl = "no-cache";
            filterContext.HttpContext.Response.Cache.SetNoStore();

        }

    }
}