﻿using Base.Web.Helpers;
using Capgemini.GroupProduction.Base.Common;
using Capgemini.GroupProduction.Base.Web;
using Capgemini.GroupProduction.Base.Web.Helpers;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Base.Web.App_Start
{
    public static class DependancyConfig
    {
           /// <summary>
        /// REgister the route collection.
        /// </summary>
        /// <param name="routes"></param>
        public static void RegisterDepandency()
        {
            var container = new UnityContainer();
            container.RegisterType<IHttpClientHelper, HttpClientHelper>(new HierarchicalLifetimeManager());

            IDependencyResolver resolver = DependencyResolver.Current;
            DependencyResolver.SetResolver(new WebDependancyResolver(container, resolver)); 
        }
    }
}