﻿using Base.Web.App_Start;
using Capgemini.GroupProduction.Base.Entity;
using Capgemini.GroupProduction.Base.Entity.Binders;
using System.Web.Mvc;
using System.Web.Routing;

namespace Base.Web
{
    public class Global : System.Web.HttpApplication
    {
        /// <summary>
        /// Event registers the route defination.
        /// </summary>
        protected void Application_Start()
        {
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            DependancyConfig.RegisterDepandency();
            ModelBinders.Binders.Add(typeof(CustomDateTime), new CustomDateTimeModelBinder());
        }

        /// <summary>
        /// Abandons the session.
        /// </summary>
        public void Session_OnEnd()
        {
            Session.Abandon();
        }
    }
}