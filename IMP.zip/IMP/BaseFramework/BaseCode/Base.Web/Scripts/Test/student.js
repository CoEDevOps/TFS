﻿
(function () {
    /*
        Every View has a start up script associated with it, which is called
        by require js. For e.g the SearchCode Page is associated to the 
        AutoComplete script. Every start up script has a class with 
        properies and methods. The class has constructor which first loads the 
        dependacy, in this case the commonconfig, jqueryand webapi are the dependancy which
        are loaded first. After dependancy are loaded the initialize method is called when the 
        document is fully loaded.    
    */
    var Student = (function () {

        function Student() {
            var self = this;
            
            $(document).ready(function () {
                //start up method
                self.initialize();
            });
        };

        /*
            Initialize method finds all the necessary controls in the page and
            hooks up the appropriate call back methods. Intiliaze method also 
            defines the default values for the class level variables. 
        */
        Student.prototype.initialize = function () {
            var self = this;
            //loading messages
            //window.VTF.CustomMessage.loadmessages();
            var widget = $(".ui-widget");
            self.studentform = $("#studentform");
            self.dtenrolled = $(widget.find(".dtpicker"));
            self.btnSearch = $(widget.find(".submit"));
            self.firstnamemsg = $(widget.find(".firstnamemsg"));
            self.lastnamemsg = $(widget.find(".lastnamemsg"));
            self.firstname = $(widget.find("#FirstName"));
            self.lastname = $(widget.find("#LastName"));
            self.datemsg = $(widget.find(".datemsg"));

            var dt = window.Base.DateControl;
            dt.registerControl(self.dtenrolled, function () {
               /* if (!window.VTF.DateControl.validateOnlyDateFormat(dateobjs[index])) {
                    $(dateobjs[index]).addClass("errormsg");
                }
                else {
                    $(dateobjs[index]).removeClass("errormsg");
                }*/

            });
            //Restrict dates as per work order start and end date
           /* self.dtenrolled.datepicker('option', {
                minDate: new Date(window.VTF.DateControl.formatMMDDYYYY(startDate)),
                maxDate: new Date(window.VTF.DateControl.formatMMDDYYYY(endDate))
            });*/

            self.btnSearch.on("click",
               function () {
                   self.firstnamemsg.text('');
                   self.lastnamemsg.text('');
                   self.datemsg.text('');

                   var isValid = window.Base.DateControl.validateCultureDateFormat(self.dtenrolled);

                   if (!isValid) {
                      // alert("Invalid date format");
                       self.datemsg.text(window.Base.CustomMessage.MessageList["DateValid"].Message);
                   }

                   if (self.firstname.val().length == 0)
                   {
                       isValid = false;
                       self.firstnamemsg.text(window.Base.CustomMessage.MessageList["FirstName"].Message);
                   }

                   if (self.lastname.val().length == 0) {
                       isValid = false;
                       self.lastnamemsg.text(window.Base.CustomMessage.MessageList["LastName"].Message);
                   }

                   if (!isValid) return;

                   self.studentform.submit();
               });
        };
      

        return Student;
    })();

    /*
       After the class is full initialized the class 
       object is created and assigned to window object. 
    */
    window.Base.Student = new Student();

})();



