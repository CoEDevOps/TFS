﻿



(function () {
requirejs.config({

    //DEV
    //urlArgs: "rel=" + (new Date()).getTime(),

    //PROD
   // urlArgs: "rel=v9",

    "baseUrl": "/Scripts/Common",
    //javascript path specify here
    paths: {
        jquery: 'jquery',
        jvalidate: 'jquery.validate',
        junobtrusive: 'jquery.validate.unobtrusive',
        validator: 'validatordynamic',
        jQueryXDomain: 'jQuery.XDomainRequest',
        webapi: 'webapi',
        jqueryui: 'jqueryui',
        custommessage: 'custommessage',     
        student: '/Scripts/Test/student'
        
    },
    //dependancy specify in shim
    shim: {
        jvalidate: { deps: ["jquery"] },
        junobtrusive: { deps: ["jquery", "jvalidate"] },
        validator: { deps: ["jquery", "jvalidate", "junobtrusive"] },
        webapi: { deps: ["validator", "jQueryXDomain"] },
        jqueryui: { deps: ['jquery'] },
        custommessage: { deps: ['jquery'] },
        student: { deps: ['jquery', 'webapi', 'jqueryui', 'datecontrol', 'selectmenu', 'custommessage'] },      
    } 
});


window.Base.Config = {};
window.Base.Config.WebApiUrl = 'http://localhost:55959/api';
window.Base.Message = 'MessageType';
window.Base.MessageType = { Unhandled: 1, Success: 2, Failure: 3 };
window.Base.FileSize = 5;

})();

