﻿
//IE, clear session on windows close
window.addEventListener("beforeunload", function (event){
    if (window.event != undefined) {       
        if (window.event.clientY < 0 && window.event.clientX > 60) {
            window.location.href = '/UserManagement/Logout';
        }
    }
});