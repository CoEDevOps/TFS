﻿(function ($) {
    $.validator.unobtrusive.validateForm = function (curForm) {
        //use the normal unobstrusive.parse method
        //$.validator.unobtrusive.parse(selector); changed this line with
        $(curForm).find('*[data-val = true]').each(function () {

            $.validator.unobtrusive.parseElement(this, false);
        });

        //get the relevant form
        var form = $(curForm);

        return form.valid();
    }

    $.validator.unobtrusive.validateDynamicContentForm = function (curForm) {
        //use the normal unobstrusive.parse method
        //$.validator.unobtrusive.parse(selector); changed this line with
        $(curForm).find('*[data-val = true]').each(function () {

            $.validator.unobtrusive.parseElement(this, false);
        });

        //get the relevant form
        var form = $(curForm);

        //get the collections of unobstrusive validators, and jquery validators
        //and compare the two
        var unobtrusiveValidation = form.data('unobtrusiveValidation');
        var validator = form.validate();

        $.each(unobtrusiveValidation.options.rules, function (elname, elrules) {
            if (validator.settings.rules[elname] == undefined) {
                var args = {};
                $.extend(args, elrules);
                args.messages = unobtrusiveValidation.options.messages[elname];
                $('[name=' + elname + ']').rules("add", args);
            } else {
                $.each(elrules, function (rulename, data) {
                    if (validator.settings.rules[elname][rulename] == undefined) {
                        var args = {};
                        args[rulename] = data;
                        args.messages = unobtrusiveValidation.options.messages[elname][rulename];
                        $('[name=' + elname + ']').rules("add", args);
                    }
                });
            }
        });

        return form.valid();
    }

    $.validator.addMethod("genericcompare", function (value, element, params) {
        // debugger;
        var propelename = params.split(",")[0];
        var operName = params.split(",")[1];
        if (params == undefined || params == null || params.length == 0 ||
        value == undefined || value == null || value.length == 0 ||
        propelename == undefined || propelename == null || propelename.length == 0 ||
        operName == undefined || operName == null || operName.length == 0)
            return true;
        var valueOther = $(propelename).val();
        var val1 = (isNaN(value) ? Date.parse(value) : eval(value));
        var val2 = (isNaN(valueOther) ? Date.parse(valueOther) : eval(valueOther));

        if (operName == "GreaterThan")
            return val1 > val2;
        if (operName == "LessThan")
            return val1 < val2;
        if (operName == "GreaterThanOrEqual")
            return val1 >= val2;
        if (operName == "LessThanOrEqual")
            return val1 <= val2;
    });

    $.validator.unobtrusive.adapters.add("genericcompare",
    ["comparetopropertyname", "operatorname"], function (options) {
        options.rules["genericcompare"] = "#" +
        options.params.comparetopropertyname + "," + options.params.operatorname;
        options.messages["genericcompare"] = options.message;
    });

})($);