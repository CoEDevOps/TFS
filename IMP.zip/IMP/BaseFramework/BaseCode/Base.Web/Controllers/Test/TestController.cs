﻿using System.Web.Mvc;
using System.Collections.Generic;
using Capgemini.GroupProduction.Base.Web.ActionFilters;
using Capgemini.GroupProduction.Base.Entity.Test;
using System;
using Capgemini.GroupProduction.Base.Entity;
using Capgemini.GroupProduction.Base.Entity.Test.ValueObject;

namespace Capgemini.GroupProduction.Base.Web.Controllers
{

    [AuthorizationRequiredAttribute]
    public class TestController : Controller
    {
         private IHttpClientHelper m_httpHelper;

         public TestController(IHttpClientHelper httpHelper)
        {
            m_httpHelper = httpHelper;
        }

        /// <summary>
        /// Error page
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ActionName("Index")]
        public ActionResult Index()
        {
            List<Student> lststudent = m_httpHelper.GetDataFromApi<List<Student>>("/Test/GetStudentList");
            return View("Home", lststudent);
        }

         /// <summary>
        /// Error page
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ActionName("AddStudent")]
        public ActionResult AddStudent()
        {            
           StudentVO studentvo =  m_httpHelper.GetDataFromApi<StudentVO>("/Test/GetStudentInfo");
           ViewBag.CustomMessageList = studentvo.CustomMessages;
           return View("AddStudent", studentvo.Student);
        }

        /// <summary>
        /// Error page
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [ActionName("SaveStudent")]
        public ActionResult SaveStudent(Student student)
        {
            if (!this.ModelState.IsValid)
            {
                return View("AddStudent", student);
            }

           /* PostStudent postStudent = new PostStudent();
            postStudent.FirstName = student.FirstName;
            postStudent.LastName = student.LastName;
            postStudent.EnrolledDate = student.EnrolledDate.ToString();
            */
            //string time = cust;ded
            Student retstudent = m_httpHelper.PostDataToApi<Student, Student>("/Test/SaveStudentInfo", student);

            return RedirectToAction("Index");
        }
    }
}
