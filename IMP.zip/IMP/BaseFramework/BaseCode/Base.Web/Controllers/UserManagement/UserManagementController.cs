﻿using System;
using System.Web.Mvc;
using Capgemini.GroupProduction.Base.Entity;
using Capgemini.GroupProduction.Base.Web.Helpers;
using System.Collections.Generic;
using Capgemini.GroupProduction.Base.Common;

namespace Capgemini.GroupProduction.Base.Web.Controllers
{
  
    /// <summary>
    /// 
    /// </summary>
    public class UserManagementController : Controller
    {
        private IHttpClientHelper m_httpHelper;

        public UserManagementController(IHttpClientHelper httpHelper)
        {
            m_httpHelper = httpHelper;
        }
        /// <summary>
        /// Error page
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ActionName("Error")]
        public ActionResult Error()
        {            
            return View("Error");
        }


        /// <summary>
        /// View for unauthorised users
        /// </summary>
        /// <returns></returns>     
        [HttpGet]
        [ActionName("Unauthorized")]
        public ActionResult Unauthorized()
        {
            return View("Unauthorized");
        }


        /// <summary>
        /// Ldap authetntication of user.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
    
        [HttpGet]
        [ActionName("Login")]
        public ActionResult Login(string id)
        {
            // When the user has directly accessed the page then 
            // the Session["UserName"] variable is null. So redirect to "Unauthorized" page. 
            if (Session["UserName"] == null)
            {
                return View("Unauthorized");
            }

            /* DO LDAP authentication and user ID request*/            
            LDAPAuthention userAuthentication = new LDAPAuthention();   
            User user = userAuthentication.LDAPAuthenticate();

            if(user == null)
            {
               // return Json(string.Empty, JsonRequestBehavior.AllowGet);
                return View("Unauthorized");
            }

            //Get the data from WebAPi.
            user = m_httpHelper.PostDataToApi<User, User>("/UserManagement/AddUser/", user);

            Session["UserID"] = user.UserID;
            Session["LoginId"] = user.UserName;
            Session["UserName"] = user.Name;
            string[] roleIds = user.RoleIds.Split(',');
            Session["RoleIds"] = user.RoleIds;

            UserAuthorization userAuthorization = new UserAuthorization(user);

            Session["IsFactoryManager"] = userAuthorization.IsFactoryManager();

            string controllerName = 
                Request.QueryString["controller"];        
            if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(controllerName))
            {
                return View("Unauthorized");
            }

          
            string userToken = EncyrptDecrypt.Encrypt(user.UserID + "_" + user.RoleIds, false);

            HttpClientCookie cookie = new HttpClientCookie();

            Response.SetCookie(cookie.CreateUserTokenCookie(userToken, m_httpHelper.BaseApiDomainName));

            return RedirectToAction(id, controllerName);
        }
      
       

       /// <summary>
       /// Load the menu based on role.
       /// </summary>
       /// <param name="SelectedMenu"></param>
       /// <returns></returns>
        [HttpGet]
        [ActionName("LoadMenuAll")]
        public ActionResult LoadMenuAll(string SelectedMenu)
        {
            ViewBag.ActiveMenu = SelectedMenu;
            Int64 userID = (int)Session["UserID"];
            IEnumerable<MenuEntity> menus = m_httpHelper.GetDataFromApi<IEnumerable<MenuEntity>>("/UserManagement/AllRoleMenu/" + userID);
            return View("_MainMenu",menus);
        }
        
        /// <summary>
        /// Logout
        /// </summary>
        /// <returns></returns>    
        [HttpGet]
        [ActionName("Logout")]
        public ActionResult Logout()
        {
            Session.Abandon();
            return View("Logout");
        }
        
    }
}
