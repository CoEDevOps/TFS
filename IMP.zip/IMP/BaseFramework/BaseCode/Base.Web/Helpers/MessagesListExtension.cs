﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace Capgemini.GroupProduction.Base.Web.Helpers
{
    public static class MessageListExtension
    {

        public static MvcHtmlString MessageList(this HtmlHelper htmlHelper,string messageList)
        {
            var script = new TagBuilder("script");
            script.Attributes.Add("type", "text/javascript");

            script.InnerHtml = "window.VTF.CustomMessageList = " + messageList + ";";

            return MvcHtmlString.Create(script.ToString());
        }
    }
}