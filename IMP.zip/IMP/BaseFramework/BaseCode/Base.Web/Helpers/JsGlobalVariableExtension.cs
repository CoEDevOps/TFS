﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace Capgemini.GroupProduction.Base.Web.Helpers
{
    public static class JsGlobalVariableExtension
    {

        public static MvcHtmlString GlobalJSVariable(this HtmlHelper htmlHelper, string messages)
        {
            var script = new TagBuilder("script");
            script.Attributes.Add("type", "text/javascript");

            StringBuilder sb = new StringBuilder();
            sb.Append("window.Base = {};");
            sb.AppendFormat("window.Base.JSVersion = {0};", System.Configuration.ConfigurationManager.AppSettings["JSVersion"].ToString());
            sb.AppendFormat("window.Base.currentUICulture = '{0}';", Thread.CurrentThread.CurrentUICulture.Name);
            sb.AppendFormat("window.Base.shortDatePatternUICulture = '{0}';", Thread.CurrentThread.CurrentUICulture.DateTimeFormat.ShortDatePattern);
            sb.AppendFormat("window.Base.messageList = {0};", messages);

            script.InnerHtml = sb.ToString();
            return MvcHtmlString.Create(script.ToString());
        }
    }
}