﻿using Capgemini.GroupProduction.Base.Common;
using Capgemini.GroupProduction.Base.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Capgemini.GroupProduction.Base.Web.Helpers
{
    public class MasterData : IMasterData
    {
        public IEnumerable<Entity.RoleAccess> GetRoleAccess(long userID)
        {
             HttpClientHelper m_clientHelper = new HttpClientHelper();
             return m_clientHelper.GetDataFromApi<IEnumerable<RoleAccess>>("/UserManagement/AllRoleAccess/" + userID);
        }
    }
}