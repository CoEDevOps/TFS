﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;

namespace Capgemini.GroupProduction.Base.Web
{
    /// <summary>
    /// Helper class to connect to the client.
    /// </summary>
    public interface  IHttpClientHelper
    {
        string BaseApiDomainName { get; }

        /// <summary>
        /// Get the the data from WebApi.
        /// </summary>        
        /// <param name="url">Base Api url to connect.</param>
        /// <param name="appendSession">Append session id in request.</param>
        /// <returns>Get the HttpResponseMessage from WebApi.</returns>
        HttpResponseMessage GetDataFromApi(string url, bool appendSession = true);
       

        /// <summary>
        /// Get the the data from WebApi.
        /// </summary>
        /// <typeparam name="T">HttpResponseMessage of Type T from WebApi.</typeparam>
        /// <param name="url">Base Api url to connect.</param>
        /// <param name="appendSession">Append session id in request.</param>
        /// <returns>Get the HttpResponseMessage from WebApi.</returns>
        T GetDataFromApi<T>(string url, bool appendSession = true) where T : class;
      

        /// <summary>
        /// Get the the data from Url.
        /// </summary>
        /// <typeparam name="T">HttpResponseMessage of Type T from Url.</typeparam>
        /// <param name="url">Base Api url to connect.</param>
        /// <param name="appendSession">Append session id in request.</param>
        /// <returns>Get the HttpResponseMessage from WebApi.</returns>
        T GetDataFromAbsoulteUrl<T>(string url, bool appendSession = true) where T : class;        

       
        /// <summary>
        /// Post datat to the WebApi.
        /// </summary>
        /// <typeparam name="PType">Type of data to post WebApi.</typeparam>       
        /// <param name="url">Url</param>
        /// <param name="postData">data to post WebApi.</param>
        /// <param name="appendSession">Append session id in request.</param>
        /// <returns>return HttpResponseMessage</returns>
        HttpResponseMessage PostDataToApi<PType>(string url, PType postData, bool appendSession = true) where PType : class;
       

        /// <summary>
        /// Post datat to the WebApi.
        /// </summary>
        /// <typeparam name="PType">Type of data to post WebApi.</typeparam>
        /// <typeparam name="T">Type of data from WebApi.</typeparam>
        /// <param name="url">Url</param>
        /// <param name="postData">data to post WebApi.</param>
        /// <param name="appendSession">Append session id in request.</param>
        /// <returns>return HttpResponseMessage of type T.</returns>
        T PostDataToApi<PType, T>(string url, PType postData, bool appendSession = true) where T : class;
    }
}
