﻿
namespace Capgemini.GroupProduction.Base.Web.Helpers
{
    /// <summary>
    /// Trim string to the specifed length.
    /// </summary>
    public static class TrimString
    {
        /// <summary>
        /// Custom Method to truncate string if exceeds maxlength
        /// </summary>
        /// <param name="value"></param>
        /// <param name="maxLength"></param>
        /// <returns></returns>
        public static string TrimStringEnd(this string value, int maxLength)
        {
            if (value.Length > maxLength)
            {
                return value.Substring(0 ,maxLength) + "..." ;
            }
            return value;
        }
    }
}