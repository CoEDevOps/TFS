﻿using Capgemini.GroupProduction.Base.Entity;
using Capgemini.GroupProduction.Base.Entity.Test;
using Capgemini.GroupProduction.Base.Repository;
using Capgemini.GroupProduction.VTF.Repository.Test;
using System.Collections.Generic;

namespace Capgemini.GroupProduction.Base.Service
{
    /// <summary>
    /// Common bussiness component
    /// </summary>
    public class TestBO : ITestBO
    {
        private readonly ITestDO m_commonDO;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="serviceMgmtRepository"></param>
        public TestBO(ITestDO commonRepository)
        {
            m_commonDO = commonRepository;
        }



        public Student AddStudent(Student student)
        {
            return m_commonDO.AddStudent(student);
        }

        public List<Student> GetStudentList()
        {
            return m_commonDO.GetStudentList();
        }

        public Student EditStudent(Student student)
        {
            throw new System.NotImplementedException();
        }
    }
}
