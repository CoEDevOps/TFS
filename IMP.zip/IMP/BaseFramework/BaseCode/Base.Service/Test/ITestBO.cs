﻿using Capgemini.GroupProduction.Base.Entity;
using Capgemini.GroupProduction.Base.Entity.Test;
using System.Collections.Generic;

namespace Capgemini.GroupProduction.Base.Service
{
    /// <summary>
    /// Common bussiness component interface.
    /// </summary>
    public interface ITestBO
    {
        Student AddStudent(Student student);
        List<Student> GetStudentList();
        Student EditStudent(Student student);
    }
}
