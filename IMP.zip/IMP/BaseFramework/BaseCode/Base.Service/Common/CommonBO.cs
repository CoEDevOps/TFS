﻿using Capgemini.GroupProduction.Base.Entity;
using Capgemini.GroupProduction.Base.Repository;
using System.Collections.Generic;

namespace Capgemini.GroupProduction.Base.Service
{
    /// <summary>
    /// Common bussiness component
    /// </summary>
    public class CommonBO : ICommonBO
    {
        private readonly ICommonDO m_commonDO;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="serviceMgmtRepository"></param>
        public CommonBO(ICommonDO commonRepository)
        {
            m_commonDO = commonRepository;
        }

        public CustomMessage GetMessage(string messageKey, string language)
        {
            return m_commonDO.GetMessage(messageKey, language);
        }


        public CustomMessageList GetMessageByGroup(string messageGroups, string language)
        {
            return m_commonDO.GetMessageByGroup(messageGroups, language);
        }
    }
}
