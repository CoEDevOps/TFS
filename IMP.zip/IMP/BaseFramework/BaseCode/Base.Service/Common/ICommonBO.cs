﻿using Capgemini.GroupProduction.Base.Entity;
using System.Collections.Generic;

namespace Capgemini.GroupProduction.Base.Service
{
    /// <summary>
    /// Common bussiness component interface.
    /// </summary>
    public interface ICommonBO
    {
        CustomMessage GetMessage(string messageKey, string language);

        CustomMessageList GetMessageByGroup(string messageGroups, string language);
    }
}
