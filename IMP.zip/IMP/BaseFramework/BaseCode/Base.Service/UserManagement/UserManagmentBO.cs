﻿using System;
using System.Collections.Generic;
using System.Linq;
using Capgemini.GroupProduction.VTF.Repository;
using Capgemini.GroupProduction.Base.Entity;

namespace Capgemini.GroupProduction.VTF.Service
{
    /// <summary>
    /// 
    /// </summary>
    public class UserManagmentBO : IUserManagmentBO
    {
        private readonly IUserManagementDO m_userRepository;

        public UserManagmentBO(IUserManagementDO userRepository)
        {
            m_userRepository = userRepository;
        }


        /// <summary>
        /// Public method to authenticate user by user name and password.
        /// </summary>
        /// <param name="userName">User name.</param>
        /// <param name="password">Password.</param>
        /// <returns></returns>
        public User Authenticate(string userName, string password)
        {
            User user = m_userRepository.GetUser(userName, password);

            return user;
        }

        /// <summary>
        /// Genrate session.
        /// </summary>
        /// <returns>Session entity.</returns>
        public Session GenerateSession()
        {
            string token = Guid.NewGuid().ToString() + "_" + DateTime.UtcNow.Ticks.ToString();
            var tokendomain = new Session
            {
                SessionID = token,
                Created = DateTime.UtcNow,
                Expires = DateTime.UtcNow.AddSeconds(900),
                LockDate = DateTime.UtcNow,
                LockDateLocal = DateTime.Now,
                LockCookie = 1,
                Timeout = 30,
                Locked = false,
                Flags = 0
            };

            m_userRepository.AddSession(tokendomain);

            return tokendomain;
        }

        /// <summary>
        /// Validate the session.
        /// </summary>
        /// <param name="sessionID">Session ID</param>
        /// <returns>Valid session id will return true.</returns>
        public bool ValidateSession(string sessionID)
        {
            Session resultToken = m_userRepository.GetSession(sessionID);

            if (resultToken == null || resultToken.SessionID == null)
            {
                return false;
            }

            if (DateTime.UtcNow > resultToken.Expires)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Get Mnu Items
        /// </summary>
        /// <returns></returns>
        public IEnumerable<MenuEntity> GetMenuItem()
        {
            IEnumerable<MenuEntity> menuEntity = m_userRepository.GetMenuItem().ToList();
            return menuEntity;
        }

        
        /// <summary>
        /// Add new user.
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public User AddUser(User user)
        {

            if (!string.IsNullOrEmpty(user.UserName))
            {
                user = m_userRepository.AddUser(user.UserName, user.Name, user.Email);                
            }
            return user;
        }

        /// <summary>
        /// Get menu items based on the role of the user.
        /// </summary>
        /// <param name="userID">User id.</param>       
        /// <returns>Menu items based on user role.</returns>
        public IEnumerable<MenuEntity> GetRoleMenuItem(Int64 userID)
        {
            IEnumerable<MenuEntity> menuEntity = m_userRepository.GetRoleMenuItem(userID).ToList();
            return menuEntity;
        }
        /// <summary>
        /// Get role access item based on the role of the user.
        /// </summary>
        /// <param name="userID">User id.</param>       
        /// <returns>RoleAccess items based on user role.</returns>
        public IEnumerable<RoleAccess> GetRoleAccessAll(Int64 userID)
        {
            IEnumerable<RoleAccess> roleAccess = m_userRepository.GetRoleAccess(0).ToList();
            return roleAccess;
        }
    }
}
