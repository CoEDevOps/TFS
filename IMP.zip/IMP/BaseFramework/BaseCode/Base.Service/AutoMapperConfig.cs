﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using System.Diagnostics.CodeAnalysis;
using Capgemini.GroupProduction.VTF.Domain;
using Capgemini.GroupProduction.VTF.Database.Entity;

namespace Capgemini.GroupProduction.VTF.Service
{
    internal static class AutoMapperConfig
    {
        private static bool autoMapperConfigured = false;
        private static object autoMapperLock = new object();

        public static void SetAutoMapperConfiguration()
        {
            if (!autoMapperConfigured)
            {
                lock (autoMapperLock)
                {
                    if (!autoMapperConfigured)
                    {
                        autoMapperConfigured = true;
                        SetAutoMapperConfigurationPrivate();
                    }
                }
            }
        }

        [SuppressMessage("Microsoft.Maintainability", "CA1506:AvoidExcessiveClassCoupling", Justification = "This code is required to configure AutoMapper correctly.  It could potentially be broken down into smaller methods later."),
        SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "This code is required to configuring AutoMapper correctly.  It could potentially be broken down into smaller methods later.")]
        private static void SetAutoMapperConfigurationPrivate()
        {
            // define the mapping from the InventoryProduct entity to the InventoryProduct domain entity
            Mapper.CreateMap<CatalogEntity, Catalog>();
            Mapper.CreateMap<Catalog, CatalogEntity>();
            Mapper.CreateMap<UserEntity, User>();
            Mapper.CreateMap<TokenEntity, Token>();
        }
    }
}
