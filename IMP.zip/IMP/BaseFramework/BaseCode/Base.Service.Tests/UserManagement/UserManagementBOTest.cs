﻿using Capgemini.GroupProduction.Base.Entity;
using Capgemini.GroupProduction.VTF.Repository;
using Capgemini.GroupProduction.VTF.Service;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;

namespace Base.Service.Tests.UserManagement
{
    [TestClass]
    public class UserManagementBOTest
    {       
        private IUserManagmentBO userBO;


        public UserManagementBOTest()
        {
            IUserManagementDO userDO = new MockUserManagementDO();
            userBO = new UserManagmentBO(userDO);
        }

        [TestMethod]
        public void UserAuthenticate()
        {
            User user = userBO.Authenticate("Test", "test");
            Assert.IsTrue(user != null, "User object is not null");
            Assert.AreEqual(user.Email, "test@capgemini.com", "User email id is not null");
        }

        [TestMethod]
        public void GenerateSession()
        {
            Session session = userBO.GenerateSession();
            Assert.IsTrue(session != null, "Session object is not null");
            Assert.IsTrue(session.SessionID.Length > 0, "Session ID is is valid");
            Assert.IsTrue(session.Timeout > 0, "Session Timeout is valid");
        }

        [TestMethod]
        public void ValidateSession()
        {
            bool isValid = userBO.ValidateSession("223232323232323");
            Assert.IsTrue(isValid, "Is Session Valid");           
        }


        [TestMethod]
        public void GetMenuItem()
        {
            IEnumerable<MenuEntity> menuItems = userBO.GetMenuItem();
            Assert.IsTrue(menuItems.Count() > 0, "Menu item count greater then zero");
            Assert.IsTrue(menuItems.First().MenuName.Length > 0, "Menu name is valid");
            Assert.IsTrue(menuItems.First().MenuOrder == 1, "Menu order is one");
        }

        [TestMethod]
        public void AddUser()
        {
            string email = "vijay.nadar@capgemini.com";
            string username = "vijnadar";

            User user = new User();
            user.UserID = 1;
            user.UserName ="vijnadar";
            user.Email = email;

            user = userBO.AddUser(user);

            Assert.IsTrue(user != null, "User object is not null");
            Assert.IsTrue(user.UserID > 0, "User ID greater then zero.");
            Assert.AreEqual(user.UserName, username, "User name is valid");
            Assert.AreEqual(user.Email, email, "User name is valid");
        }

        [TestMethod]
        public void GetRoleMenuItem()
        {

            IEnumerable<MenuEntity> menuItems = userBO.GetRoleMenuItem(1);
            Assert.IsTrue(menuItems.Count() > 0, "Role Menu item count greater then zero");
            Assert.IsTrue(menuItems.First().MenuName.Length > 0, "Role Menu name is valid");
            Assert.IsTrue(menuItems.First().MenuOrder == 1, "Role Menu order is one");
        }

        [TestMethod]
        public void GetRoleAccessAll()
        {
            IEnumerable<RoleAccess> lstroleAccess = userBO.GetRoleAccessAll(1);
            Assert.IsTrue(lstroleAccess.Count() > 0, "Role access items greater then zero.");
            Assert.IsTrue(lstroleAccess.First().RoleIds.Length > 0, "Role Ids is not blank");           
        }
    }
}
