﻿using Capgemini.GroupProduction.Base.Entity;
using Capgemini.GroupProduction.VTF.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Base.Service.Tests.UserManagement
{
    public class MockUserManagementDO : IUserManagementDO
    {

        public User GetUser(string userName, string password)
        {
            User user = new User();
            user.UserID = 1;
            user.UserName = userName;
            user.Email = "test@capgemini.com";

            return user;
        }

        public Session GetSession(string sessionID)
        {
            Session session = new Session();
            session.SessionID = sessionID;
            session.Created = DateTime.Now;
            session.Expires = DateTime.Now.AddMinutes(10);
            return session;
        }

        public Session AddSession(Session sessionEntity)
        {
            return sessionEntity;
        }

        public IEnumerable<MenuEntity> GetMenuItem()
        {
            List<MenuEntity> menuItems = new List<MenuEntity>();

            MenuEntity menuItem = new MenuEntity();
            menuItem.MenuName = "Menu 1";
            menuItem.MenuOrder = 1;
            menuItem.Url = "WorkOrder/Test";
            menuItems.Add(menuItem);


            menuItem = new MenuEntity();
            menuItem.MenuName = "Menu 2";
            menuItem.MenuOrder = 2;
            menuItem.Url = "WorkOrder/Test1";
            menuItems.Add(menuItem);

            return menuItems;

        }

        public User AddUser(string userName, string Name, string Email)
        {
            User user = new User();
            user.UserID = 1;
            user.UserName = userName;
            user.Email = Email;

            return user;    
        }

        public IEnumerable<MenuEntity> GetRoleMenuItem(long UserID)
        {
            List<MenuEntity> menuItems = new List<MenuEntity>();

            MenuEntity menuItem = new MenuEntity();
            menuItem.MenuName = "Menu 1";
            menuItem.MenuOrder = 1;
            menuItem.Url = "WorkOrder/Test";
            menuItems.Add(menuItem);


            menuItem = new MenuEntity();
            menuItem.MenuName = "Menu 2";
            menuItem.MenuOrder = 2;
            menuItem.Url = "WorkOrder/Test1";
            menuItems.Add(menuItem);

            return menuItems;
        }

        public IEnumerable<RoleAccess> GetRoleAccess(long userID)
        {
            List<RoleAccess> lstroleAccess = new List<RoleAccess>();

            RoleAccess roleAccess = new RoleAccess();
            roleAccess.RoleIds = "1,2";
            roleAccess.Url = "WorkOrder/Test";
            roleAccess.UrlID = 1;
            lstroleAccess.Add(roleAccess);

            roleAccess = new RoleAccess();
            roleAccess.RoleIds = "1";
            roleAccess.Url = "WorkOrder/Test2";
            roleAccess.UrlID = 2;
            lstroleAccess.Add(roleAccess);

            return lstroleAccess;
        }
    }
}
