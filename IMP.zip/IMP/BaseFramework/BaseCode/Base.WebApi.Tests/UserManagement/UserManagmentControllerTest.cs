﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Capgemini.GroupProduction.Base.WebApi.Controllers.UserManagement;
using Capgemini.GroupProduction.VTF.Service;
using System.Net.Http;
using Capgemini.GroupProduction.Base.Entity;
using System.Collections.Generic;
using System.Web.Http;
using System.Net;
using System.Web.Http.Hosting;

namespace Base.WebApi.Tests
{
    [TestClass]
    public class UserManagmentControllerTest
    {
        private UserManagementController userMgmController;

        public UserManagmentControllerTest()
        {            
            IUserManagmentBO userBO = new MockUserManagementBO();
            userMgmController = new UserManagementController(userBO);
        }


        [TestMethod]
        public void GetAllMenu()
        {
           // var controller = new ProductsController(repository);
            userMgmController.Request = new HttpRequestMessage();
            userMgmController.Configuration = new HttpConfiguration();
            userMgmController.Request.Properties.Add(HttpPropertyKeys.HttpConfigurationKey, new HttpConfiguration());

            // Act
            var response = userMgmController.GetAllMenu();
            Assert.IsTrue(response.StatusCode == HttpStatusCode.OK, "Success response");
            // Assert
            List<MenuEntity> menuItems;
            Assert.IsTrue(response.TryGetContentValue<List<MenuEntity>>(out menuItems));
            Assert.AreEqual(2, menuItems.Count, "Menu count in equal");
        }

        [TestMethod]
        public void GetAllRoleAccess()
        {
            // var controller = new ProductsController(repository);
            HttpRequestMessage requestMessage = new HttpRequestMessage();

            // Act
            var response = userMgmController.GetAllRoleAccess(1);

            // Assert
            List<RoleAccess> roleaccess;
            Assert.IsTrue(response.TryGetContentValue<List<RoleAccess>>(out roleaccess));
            Assert.AreEqual(2, roleaccess.Count, "Role item count in equal");
        }

        [TestMethod]
        public void AddUser()
        {
            User user = new User();
            user.UserName = "vijnadar";

            // var controller = new ProductsController(repository);
            HttpRequestMessage requestMessage = new HttpRequestMessage();
           
            // Act
            var response = userMgmController.AddUser(user);

            // Assert           
            Assert.IsTrue(response.TryGetContentValue<User>(out user));
            Assert.AreEqual(1, user, "User added");
        }
    }
}
