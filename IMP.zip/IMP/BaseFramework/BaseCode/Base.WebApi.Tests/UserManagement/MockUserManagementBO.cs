﻿using Capgemini.GroupProduction.Base.Entity;
using Capgemini.GroupProduction.VTF.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Base.WebApi.Tests
{
    public class MockUserManagementBO : IUserManagmentBO
    {


        public User Authenticate(string userName, string password)
        {
            User user = new User();
            user.UserID = 1;
            user.UserName = userName;
            user.Email = "test@capgemini.com";

            return user;
        }

        public Session GenerateSession()
        {
            Session session = new Session();
            session.SessionID = "12121212121212";
            session.Created = DateTime.Now;
            session.Expires = DateTime.Now.AddMinutes(10);
            return session;
        }

        public bool ValidateSession(string sessionID)
        {
            return true;
        }

        public IEnumerable<MenuEntity> GetMenuItem()
        {
            List<MenuEntity> menuItems = new List<MenuEntity>();

            MenuEntity menuItem = new MenuEntity();
            menuItem.MenuName = "Menu 1";
            menuItem.MenuOrder = 1;
            menuItem.Url = "WorkOrder/Test";
            menuItem.Description = "";
            menuItems.Add(menuItem);


            menuItem = new MenuEntity();
            menuItem.MenuName = "Menu 2";
            menuItem.MenuOrder = 2;
            menuItem.Url = "WorkOrder/Test1";
            menuItem.Description = "";
            menuItems.Add(menuItem);

            return menuItems;
        }

        public User AddUser(User user)
        {
            user.UserID = 1;
           
            return user;
        }

        public IEnumerable<RoleAccess> GetRoleAccessAll(long userID)
        {
            List<RoleAccess> lstroleAccess = new List<RoleAccess>();

            RoleAccess roleAccess = new RoleAccess();
            roleAccess.RoleIds = "1,2";
            roleAccess.Url = "WorkOrder/Test";
            roleAccess.UrlID = 1;
            lstroleAccess.Add(roleAccess);

            roleAccess = new RoleAccess();
            roleAccess.RoleIds = "1";
            roleAccess.Url = "WorkOrder/Test2";
            roleAccess.UrlID = 2;
            lstroleAccess.Add(roleAccess);

            return lstroleAccess;
        }

        public IEnumerable<MenuEntity> GetRoleMenuItem(long userID)
        {
            List<MenuEntity> menuItems = new List<MenuEntity>();

            MenuEntity menuItem = new MenuEntity();
            menuItem.MenuName = "Menu 1";
            menuItem.MenuOrder = 1;
            menuItem.Url = "WorkOrder/Test";
            menuItems.Add(menuItem);


            menuItem = new MenuEntity();
            menuItem.MenuName = "Menu 2";
            menuItem.MenuOrder = 2;
            menuItem.Url = "WorkOrder/Test1";
            menuItems.Add(menuItem);

            return menuItems;
        }
    }
}
