﻿using Capgemini.GroupProduction.Base.Entity;
using Capgemini.GroupProduction.Base.Entity.Test;
using Capgemini.GroupProduction.VTF.Database.DBContext;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.VTF.Repository.Test
{
    public class TestDO : ITestDO
    {
       // private readonly VTFBaseContext m_VtfDataBaseContext;

        public TestDO()
        {
           
                 
        }

        public Student AddStudent(Student student)
        {
            using (StudentVTFBaseContext vtfDataBaseContext = new StudentVTFBaseContext())
            {
                var firstnameParameter = new SqlParameter("FirstName", student.FirstName);
                var lastnameParameter = new SqlParameter("LastName", student.LastName);
                string enrolleddate =  student.EnrolledDate.DateServerCulture.ToString("MM/dd/yyyy");
                var dateParameter = new SqlParameter("EnrolledDate", enrolleddate);

                return vtfDataBaseContext.Database.SqlQuery<Student>("sp_AddStudent @FirstName, @LastName, @EnrolledDate", firstnameParameter, lastnameParameter, dateParameter).FirstOrDefault();
            }
        }

        public List<Student> GetStudentList()
        {
            using (StudentVTFBaseContext vtfDataBaseContext = new StudentVTFBaseContext())
            {
                return vtfDataBaseContext.Database.SqlQuery<Student>("sp_GetStudentList").ToList();
            }

        }

        public Student EditStudent(Student student)
        {
            throw new NotImplementedException();
        }
    }
}
