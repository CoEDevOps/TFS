﻿using Capgemini.GroupProduction.Base.Entity.Test;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.VTF.Repository.Test
{
    public interface ITestDO
    {
        Student AddStudent(Student student);
        List<Student> GetStudentList();
        Student EditStudent(Student student);
    }
}
