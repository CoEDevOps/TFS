﻿using Capgemini.GroupProduction.VTF.Database.DBContext;
using Capgemini.GroupProduction.Base.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.Base.Repository
{
    /// <summary>
    /// Common bussiness components
    /// </summary>
    public class CommonDO : ICommonDO
    {
        private readonly VTFBaseContext m_VtfDataBaseContext;

        public CommonDO()
        {
            m_VtfDataBaseContext = new VTFBaseContext();                
        }

        /// <summary>
        /// Get the message by key. 
        /// </summary>
        /// <param name="messageKey">message key name.</param>
        /// <returns>Custom message details fetched by key name.</returns>
        public CustomMessage GetMessage(string messageKey, string language)
        {
            var messageKeyParameter = new SqlParameter("MessageKey", messageKey);
            var languageKeyParameter = new SqlParameter("Language", language);

            return m_VtfDataBaseContext.Database.SqlQuery<CustomMessage>("[sp_GetMessage] @MessageKey, @Language", messageKeyParameter, languageKeyParameter).FirstOrDefault();
    

        }

        /// <summary>
        /// Get the message collection by group. 
        /// </summary>
        /// <param name="messageGroups">message groups.</param>
        /// <returns>Custom message colection fetched by groups.</returns>
        public CustomMessageList GetMessageByGroup(string messageGroups, string language)
        {
            var messageKeyParameter = new SqlParameter("MessageGroups", messageGroups);
            var languageKeyParameter = new SqlParameter("Language", language);

            var msgList = m_VtfDataBaseContext.Database.SqlQuery<CustomMessage>("[sp_GetMessageByGroups] @MessageGroups, @Language", messageKeyParameter, languageKeyParameter).ToList();
            CustomMessageList customMsgList = new CustomMessageList(msgList);
            return customMsgList;


        }
    }
}
