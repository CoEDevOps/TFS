﻿using System.Data.Entity;
using Capgemini.GroupProduction.Base.Common;
using System.Configuration;
using Capgemini.GroupProduction.Base.Entity.Test;
using Capgemini.GroupProduction.Base.Entity;

namespace Capgemini.GroupProduction.VTF.Database.DBContext
{
    /// <summary>
    /// Base conext class.
    /// </summary>
    /// <typeparam name="TContext"></typeparam>
    public class VTFBaseContext : DbContext
    {
        public VTFBaseContext()
            : base(ConfigurationManager.ConnectionStrings["VTFEntities"].ConnectionString)
        {
            // Set the intializer to null. Its is initialized as per 
            // connection string.
            System.Data.Entity.Database.SetInitializer<VTFBaseContext>(null);
        }        
        
    }

    /// <summary>
    /// Base conext class.
    /// </summary>
    /// <typeparam name="TContext"></typeparam>
    public class StudentVTFBaseContext : VTFBaseContext
    {       

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {

          // modelBuilder.ComplexType<Student>()
         //  .Property(p => p.EnrolledDate);
           



        }

    }
}
