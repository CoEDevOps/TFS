﻿using System.Data.Entity;
using Capgemini.GroupProduction.Base.Common;
using System.Configuration;

namespace Capgemini.GroupProduction.VTF.Database.DBContext
{
    /// <summary>
    /// Session Database conext class. Manages the operation with Session Database. 
    /// </summary>
    internal class SessionBaseContext : DbContext
    {
        internal SessionBaseContext()
            : base(ConfigurationManager.ConnectionStrings["SessionEntities"].ConnectionString)
        {            
            System.Data.Entity.Database.SetInitializer<SessionBaseContext>(null);
        }
    }
}
