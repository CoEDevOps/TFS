﻿using System.Collections.Generic;
using Capgemini.GroupProduction.Base.Entity;
using System;

namespace Capgemini.GroupProduction.VTF.Repository
{
    /// <summary>
    /// User management repository.
    /// </summary>
    public interface IUserManagementDO
    {
        /// <summary>
        /// Get user details from database.
        /// </summary>
        /// <param name="userName">User name</param>
        /// <param name="password">Password</param>
        /// <returns>User entity for the credentials provided.Null in case user not found</returns>
        User GetUser(string userName, string password);

        /// <summary>
        /// Get session details from database.
        /// </summary>
        /// <param name="sessionID">session id</param>
        /// <returns>Session entity for the particular SessionID</returns>
        Session GetSession(string sessionID);

        /// <summary>
        /// Add session entity in database.
        /// </summary>
        /// <param name="sessionEntity">Session entity.</param>
        /// <returns>Session entity added to database.</returns>
        Session AddSession(Session sessionEntity);        

        /// <summary>
        /// Get Menu Items
        /// </summary>
        /// <returns></returns>
        IEnumerable<MenuEntity> GetMenuItem();

        /// <summary>
        /// Add new User.
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="Name"></param>
        /// <param name="Email"></param>
        /// <returns></returns>
        User AddUser(string userName, string Name, string Email);

        /// <summary>
        /// Get menu items based on the role of the user.
        /// </summary>
        /// <param name="userID">User id.</param>       
        /// <returns>Menu items based on user role.</returns>
        IEnumerable<MenuEntity> GetRoleMenuItem(Int64 UserID);

        /// <summary>
        /// Get role access item based on the role of the user.
        /// </summary>
        /// <param name="userID">User id.</param>       
        /// <returns>RoleAccess items based on user role.</returns>
        IEnumerable<RoleAccess> GetRoleAccess(Int64 userID);
        
    }
}
