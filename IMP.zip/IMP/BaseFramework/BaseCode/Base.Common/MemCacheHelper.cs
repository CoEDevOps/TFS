﻿using Capgemini.GroupProduction.Base.Common;
using Capgemini.GroupProduction.Base.Entity;
using Memcached.ClientLibrary;
using System;
using System.Collections.Generic;
using System.Web;

namespace Capgemini.GroupProduction.Base.Common
{
    /// <summary>
    /// Singleton class for configuration of the application.
    /// There is only one instance of the SysAppConfig in the application.
    /// Single instance created in the thread safe way.
    /// </summary>
    public class MemCacheHelper
    {
        static MemCacheHelper()
        {
            /*Initialize the memcache server*/
            SockIOPool pool = SockIOPool.GetInstance();
            pool.SetServers(new string[] { System.Configuration.ConfigurationManager.AppSettings["MemcacheServer"].ToString() });                               
        }     

       
        /// <summary>
        /// Get all the role master data from the WebAPi. 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public static IEnumerable<RoleAccess> GetAllRoleAccess(Int64 userID, IMasterData masterData)
        {
            MemcachedClient memcacheClient = new MemcachedClient();
            //In case the cache is null then get the all the role access.
            if (memcacheClient.Get("BaseRoleAccessMaster") == null)
            {
                IEnumerable<RoleAccess> roleAccess = masterData.GetRoleAccess(userID);
                memcacheClient.Add("BaseRoleAccessMaster", roleAccess, DateTime.Now.AddHours(5));
                
                return roleAccess;
            }

            return (IEnumerable<RoleAccess>)memcacheClient.Get("RoleAccessMaster");
        }


    }

}