﻿
namespace Capgemini.GroupProduction.Base.Common
{
    /// <summary>
    /// Message groups string. 
    /// </summary>
    public class MessageGroups
    {
        public const string WorkOrder = "WorkOrder";
        public const string Common = "Common";
        public const string Service = "Service";
        public const string FileUpload = "FileUpload";
        public const string Session = "Session";
    }
}
