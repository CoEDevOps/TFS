﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Net.Http;
using System.Web;
using System.Net;

namespace Capgemini.GroupProduction.Base.Common
{
    public class HttpClientCookie
    {          
        private string m_aspNetCookie = "ASP.NET_SessionId";
        private string m_userTokenCookie = "usertoken";

        public HttpClientCookie()
        {
                      
        }

        public string GetSessionCookie(HttpRequestHeaders requestHeader)
        {
            var cookieHeaders = requestHeader.GetCookies(m_aspNetCookie);
            if (cookieHeaders.Count == 0)
            {
                return string.Empty;
            }

           CookieState sessionCookie = cookieHeaders[0].Cookies.FirstOrDefault(x => x.Name == m_aspNetCookie);

           return HttpUtility.HtmlDecode(sessionCookie.Value);
        }


        public string GetUserTokenCookie(HttpRequestHeaders requestHeader)
        {
            var cookieHeaders = requestHeader.GetCookies(m_userTokenCookie);
            if (cookieHeaders.Count == 0)
            {
                return string.Empty;
            }

            CookieState userTokenCookie = cookieHeaders[0].Cookies.FirstOrDefault(x => x.Name == m_userTokenCookie);

            return HttpUtility.HtmlDecode(userTokenCookie.Value);
        }

        public Cookie CreateSessionCookie(string sessionId, string domain)
        {
            Encoding iso = Encoding.GetEncoding("iso-8859-9");//may be utf-8
            sessionId = System.Web.HttpUtility.UrlEncode(sessionId, iso);

            Cookie moCookie = new Cookie(m_aspNetCookie, sessionId); 
            moCookie.Domain = domain;
            moCookie.HttpOnly = true;
            return moCookie;
        }

        public System.Web.HttpCookie CreateUserTokenCookie(string userToken, string domain)
        {
            Encoding iso = Encoding.GetEncoding("iso-8859-9");//may be utf-8
            userToken = System.Web.HttpUtility.UrlEncode(userToken, iso);

            System.Web.HttpCookie moCookie = new System.Web.HttpCookie(m_userTokenCookie, userToken);
            moCookie.Domain = domain;
            moCookie.HttpOnly = true;
            return moCookie;
        }

        public Cookie CreateApiUserTokenCookie(string userToken, string domain)
        {
            Encoding iso = Encoding.GetEncoding("iso-8859-9");//may be utf-8
            userToken = System.Web.HttpUtility.UrlEncode(userToken, iso);

            Cookie moCookie = new Cookie(m_userTokenCookie, userToken);
            moCookie.Domain = domain;
            moCookie.HttpOnly = true;
            return moCookie;
        }

    }
}
