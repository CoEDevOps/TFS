﻿using Capgemini.GroupProduction.Base.Common;
using Capgemini.GroupProduction.Base.Entity;
using System;
using System.Linq;
using System.Collections.Generic;

namespace Capgemini.GroupProduction.Base.Common
{
    /// <summary>
    /// User authorization.
    /// </summary>
    public class UserAuthorization
    {
        private User m_User;
        private string[] m_roleIds;


        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="roleIds"></param>
        public UserAuthorization(User user)
        {
            m_User = user;
            m_roleIds = user.RoleIds != null ? user.RoleIds.Split(',') : new string[0];
        }

        /// <summary>
        /// Compare the userroleid with the cmproleIds and check if the 
        /// usre roleid exists.
        /// </summary>
        /// <param name="cmproleIds">compare role ids.</param>
        /// <returns></returns>
        private bool HasRole(string[] cmproleIds)
        {

            foreach (string roleID in m_roleIds)
            {
                foreach (string cmproleID in cmproleIds)
                {
                    if (roleID.Trim() == cmproleID.Trim())
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary>
        /// Check if the url is autorized for the role.
        /// </summary>
        /// <param name="controllerName">controller name.</param>
        /// <param name="actionName">action name.</param>
        /// <returns>True if authorized user.</returns>
        public bool IsUrlAuthorized(string url, IEnumerable<RoleAccess> urlAccess)
        {
            if (m_roleIds.Length == 0) return false;

            using (var sequenceEnum = urlAccess.GetEnumerator())
            {
                while (sequenceEnum.MoveNext())
                {
                    if (!(sequenceEnum.Current.Url.ToUpper() == url.ToUpper()))
                    {
                        continue;
                    }

                    if (this.HasRole(sequenceEnum.Current.RoleIds.Split(',')))
                    {
                        return true;
                    }

                    // Do something with sequenceEnum.Current.
                }
            }

            return false;
        }

        /// <summary>
        /// Checks if user is factory maanger and return true.
        /// </summary>
        /// <returns>true if user is factory manager.</returns>
        public bool IsFactoryManager()
        {
            foreach (string role in m_roleIds)
            {
                int roleID = int.Parse(role);

                if (roleID == (int)UserRole.Factory_Manager)
                    return true;
            }

            return false;
        }

    }
}