﻿using Capgemini.GroupProduction.Base.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.Base.Common
{
    public interface IMasterData
    {
        IEnumerable<RoleAccess> GetRoleAccess(Int64 userID);
    }
}
