﻿using System;
using System.IO;
using System.Web.Mvc;
using System.Collections.Generic;
using System.Linq;


namespace Capgemini.GroupProduction.Base.Grid
{
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class HtmlGrid<T> : IGrid where T : class
    {

        public string GridViewName { get; set; }
        private readonly ViewContext _viewContext;
        private List<object> m_Items;
        internal GridCollection<T> m_GridCollection;

        public HtmlGrid(ViewContext viewContext, IEnumerable<T> items, string viewName)            
        {
            _viewContext = viewContext;
            GridViewName = viewName;
            m_Items = new List<object>();
            if (items != null)
            {
                foreach (var item in items)
                {
                    m_Items.Add(items.Cast<object>());
                }
                m_GridCollection = new GridCollection<T>();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<IGridColumn> GetColumns()
        {          
            return m_GridCollection.GridColumns();
        }

        public List<object> Items
        {
             
            get{                
                return m_Items;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="columnBuilder"></param>
        /// <returns></returns>
        public HtmlGrid<T> Columns(Action<GridCollection<T>> columnBuilder)
        {
            columnBuilder(m_GridCollection);
            return this;
        }
       
       /// <summary>
       /// 
       /// </summary>
       /// <returns></returns>
        public string ToHtmlString()
        {
            if (string.IsNullOrEmpty(GridViewName))
                throw new ArgumentException("viewName");

            var context = new ControllerContext(_viewContext.RequestContext, _viewContext.Controller);
            using (var sw = new StringWriter())
            {
                ViewEngineResult viewResult = ViewEngines.Engines.FindPartialView(context, GridViewName);
                if (viewResult.View == null)
                    throw new InvalidDataException(
                        string.Format("Specified view name for Grid.Mvc not found. ViewName: {0}", GridViewName));
                var newViewContext = new ViewContext(context, viewResult.View, _viewContext.ViewData,
                                                     _viewContext.TempData, sw)
                {
                    ViewData =
                    {
                        Model = this
                    }
                };
                viewResult.View.Render(newViewContext, sw);
                return sw.GetStringBuilder().ToString();
            }
        }

      
    }
}
