﻿using System.Collections.Generic;
using System.Web;

namespace Capgemini.GroupProduction.Base.Grid
{
    /// <summary>
    /// 
    /// </summary>
    public interface IGrid : IHtmlString
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IEnumerable<IGridColumn> GetColumns();

        /// <summary>
        /// 
        /// </summary>
        List<object> Items { get;}
       
    }
}
