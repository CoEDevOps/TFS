﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using System.Web.WebPages;

namespace Capgemini.GroupProduction.Base.Grid
{
    /// <summary>
    /// 
    /// </summary>
    public static class GridExtensions
    {
        internal const string DefaultPartialViewName = "_Grid";

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="helper"></param>
        /// <param name="items"></param>
        /// <returns></returns>
        public static HtmlGrid<T> Grid<T>(this HtmlHelper helper, IEnumerable<T> items)
           where T : class
        {
            return new HtmlGrid<T>(helper.ViewContext, items, DefaultPartialViewName);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="column"></param>
        /// <param name="constraint"></param>
        /// <returns></returns>
        public static IGridColumn<T> RenderValueAs<T>(this IGridColumn<T> column,
                                                      Func<T, int, Func<string, HelperResult>> constraint) where T : class
        {
            Func<T, int, string> valueContraint = (a, i) => constraint(a, i)(null).ToHtmlString();
            return column.RenderValueAs(valueContraint);
           // return column;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="column"></param>
        /// <param name="constraint"></param>
        /// <returns></returns>
        public static IGridColumn<T> RenderValueAs<T>(this IGridColumn<T> column, Func<T, int, IHtmlString> constraint) where T: class
        {
            Func<T, int, string> valueContraint = (a, i) => constraint(a, i).ToHtmlString();
            return column.RenderValueAs(valueContraint);
        }
    }
}
