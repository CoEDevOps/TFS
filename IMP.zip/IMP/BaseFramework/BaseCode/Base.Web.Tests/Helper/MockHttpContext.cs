﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Base.Web.Tests.Helper
{
    public class MockSession : HttpSessionStateBase
    {
        private Dictionary<string, object> obj = new Dictionary<string, object>();

        public override object this[string name]
        {
            get
            {
                if (obj.ContainsKey(name))
                {
                    return obj[name];
                }

                return null;
            }
            set
            {

                obj[name] = value;
            }
        }
    }
    public class MockHttpContext : HttpContextBase
    {
        private HttpSessionStateBase m_Session;

        public override HttpSessionStateBase Session
        { 
            get 
            {
                if (m_Session == null)
                {
                    m_Session = new MockSession();
                }
                return m_Session;
            } 
        }

        private readonly IPrincipal _user = new GenericPrincipal(
                 new GenericIdentity("someUser"), null /* roles */);

        public override IPrincipal User
        {
            get
            {
                return _user;
            }
            set
            {
                base.User = value;
            }
        }
    }
}
