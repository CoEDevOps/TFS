﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Capgemini.GroupProduction.Base.Web.Controllers;
using Base.Web.Tests.UserManagement;
using System.Web.Mvc;
using System.Web.Routing;
using Base.Web.Tests.Helper;

namespace Base.Web.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void UnAuthorizedUser()
        {
            UserManagementController controller = new UserManagementController(new MockUserClientHelper());
            controller.ControllerContext = new ControllerContext()
            {
                Controller = controller,
                RequestContext = new RequestContext(new MockHttpContext(), new RouteData())
            };
           
            var result = controller.Login("2") as ViewResult;

            Assert.AreEqual("Unauthorized", result.ViewName);
        }


        [TestMethod]
        public void AuthorizedUser()
        {
            UserManagementController controller = new UserManagementController(new MockUserClientHelper());
            controller.ControllerContext = new ControllerContext()
            {
                Controller = controller,
                RequestContext = new RequestContext(new MockHttpContext(), new RouteData())
            };

            //controller.ControllerContext.RequestContext.HttpContext.Session["UserName"] = "vijandar";
            controller.Session["UserName"] = "vijandar";

            var result = controller.Login("1") as ViewResult;
           
            Assert.AreEqual("1", controller.Session["UserID"].ToString());
        }
    }
}
