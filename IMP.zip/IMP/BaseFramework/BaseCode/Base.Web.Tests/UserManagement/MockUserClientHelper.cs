﻿using Capgemini.GroupProduction.Base.Entity;
using Capgemini.GroupProduction.Base.Web;
using System;
using System.Net.Http;

namespace Base.Web.Tests.UserManagement
{
    public class MockUserClientHelper : IHttpClientHelper
    {
        public string BaseApiDomainName
        {
            get { return "localhost"; }
        }

        public HttpResponseMessage GetDataFromApi(string url, bool appendSession = true)
        {
            throw new NotImplementedException();
        }

        public T GetDataFromApi<T>(string url, bool appendSession = true) where T: class
        {
            string[] urls = url.Split('\\');

            if(urls.Length == 2)
            {
                if(urls[1] == "AddUser")
                {
                    User user = new User();
                    user.UserName = "vijnadar";
                    user.UserID = 1;
                    user.Name = "Vijay";
                    return user as T;
                }  
                else
                {
                    return null;
                }
            }

            return null;
        }

        public T GetDataFromAbsoulteUrl<T>(string url, bool appendSession = true) where T: class 
        {
            throw new NotImplementedException();
        }

        public HttpResponseMessage PostDataToApi<PType>(string url, PType postData, bool appendSession = true) where PType : class
        {
            throw new NotImplementedException();
        }

        public T PostDataToApi<PType, T>(string url, PType postData, bool appendSession = true) where T : class
        {
            string[] urls = url.Split('/');

            if (urls.Length == 4)
            {
                if (urls[2] == "AddUser")
                {
                    User user =  postData as User;
                   // user.UserName = "vijnadar";
                    user.UserID = 1;
                    user.Name = "Vijay";
                    user.RoleIds = "1,2";
                    return user as T;
                }
                else
                {
                    return null;
                }
            }

            return null;
        }
    }

    
}
