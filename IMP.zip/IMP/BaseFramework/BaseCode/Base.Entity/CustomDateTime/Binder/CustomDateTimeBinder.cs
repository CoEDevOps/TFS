﻿using Capgemini.GroupProduction.Base.Entity;
using Capgemini.GroupProduction.Base.Entity.LocalResource.Test;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;

namespace Capgemini.GroupProduction.Base.Entity.Binders
{
    public class CustomDateTimeModelBinder : IModelBinder
    {
        public object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            var value = bindingContext.ValueProvider.GetValue(bindingContext.ModelName);

            CustomDateTime customDateTime =  new CustomDateTime(value.AttemptedValue);
          
            if (!customDateTime.IsValidDate)
            {
                bindingContext.ModelState.AddModelError(bindingContext.ModelName, StudentResource.InvalidDate);
               // return DateTime.UtcNow.Date;
                return customDateTime;
            }

            return customDateTime;
        }
    }
}