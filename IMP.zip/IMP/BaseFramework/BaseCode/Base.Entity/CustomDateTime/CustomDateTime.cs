﻿using Capgemini.GroupProduction.Base.Entity.Binders;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web.Http.ModelBinding;

namespace Capgemini.GroupProduction.Base.Entity
{
    
    public struct CustomDateTime 
    {
        private string m_value;
      

        public CustomDateTime(string value)
        {
            this.m_value = value; 
        }

        public static implicit operator CustomDateTime(string value)
        {
            return new CustomDateTime(value);
        }

        public static string CurrentDateUICulture
        {
            get
            {
                var date = DateTime.Now.ToString(Thread.CurrentThread.CurrentUICulture.DateTimeFormat.ShortDatePattern);
                date = date.Replace("-", "/");
                return date;                
            }
        }

        public override string ToString()
        {
            return m_value;
        }
      

        public bool IsValidDate
        {
            get
            {
                DateTime serverDateTime;
                return this.ValidateDate(out serverDateTime);
            }
        }

        public string Value
        {
            set
            {
                m_value = value;
            }
            get
            {
                return m_value;
            }
        }
        public string DateUICulture
        {
            get
            {
                var date = DateServerCulture.ToString(Thread.CurrentThread.CurrentUICulture.DateTimeFormat.ShortDatePattern);
                date = date.Replace("-", "/");
                return date;
            }
        }

        public DateTime DateServerCulture
        {
            get
            {
                DateTime serverDateTime;
                this.ValidateDate(out serverDateTime);
                return serverDateTime;
            }
        }

        private bool ValidateDate(out  DateTime serverDateTime)
        {
            /* Validate the date as per the UI culture set.
             * In case the date is not valid then the isValidDate variable is set to false.
             * That means the client has send the invalid date.
             * When the date is valid then the date is initilized as per the server culture.
             */
            DateTime dateTime;
            bool isValidDate = DateTime.TryParse(m_value, Thread.CurrentThread.CurrentUICulture, DateTimeStyles.None, out dateTime);
           
            DateTime minDate = new DateTime(1953, 1, 1);
            serverDateTime = minDate;

            if (!isValidDate)
                return false;

            //In case the datetime is less then min date then is considered is not validdate.
            if (dateTime < minDate)                           
                return false;

            // When the date is valid then the date is initilized as per the server  culture.
            serverDateTime = new DateTime(dateTime.Year, dateTime.Month, dateTime.Day);
            return true;
        }
    }
}
