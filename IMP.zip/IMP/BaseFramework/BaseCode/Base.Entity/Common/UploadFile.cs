﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.Base.Entity.Common
{
    /// <summary>
    /// UploadFile
    /// </summary>
    public class UploadFile
    {
        public string FileName { get; set; }

        public string DisplayFileName { get; set; }

        public int FileSize { get; set; }

        public string FileType { get; set; }
    }
}
