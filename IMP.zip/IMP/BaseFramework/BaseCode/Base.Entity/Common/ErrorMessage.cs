﻿using Capgemini.GroupProduction.VTF.Common;

namespace Capgemini.GroupProduction.VTF.Entity
{
    /// <summary>
    /// User information is persisted in the user entity.
    /// </summary>
    public class ErrorMessage
    {
        /// <summary>
        /// Message type. Wheater a System or Unhandled message.
        /// </summary>
        public int MessageType { get; set; }

        /// <summary>
        /// Message to display the user .
        /// </summary>
        public string Message { get; set; }
    }
}
