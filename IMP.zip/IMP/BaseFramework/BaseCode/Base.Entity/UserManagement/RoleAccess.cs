﻿
using System;
namespace Capgemini.GroupProduction.Base.Entity
{   
    /// <summary>
    ///  RoleAccess
    /// </summary>
    /// 
    [Serializable]
    public class RoleAccess
    {
        /// <summary>
        /// User ID. 
        /// </summary>
        public int UrlID { get; set; }

        /// <summary>
        /// User name.
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// User name.
        /// </summary>
       // public string ActionName { get; set; }


        /// <summary>
        /// User name.
        /// </summary>
        public string RoleIds { get; set; }
    }
}
