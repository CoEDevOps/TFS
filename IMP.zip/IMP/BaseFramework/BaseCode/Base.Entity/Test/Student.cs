﻿using Capgemini.GroupProduction.Base.Entity.LocalResource.Test;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Resources;
using System.Linq;
using System.Text;


namespace Capgemini.GroupProduction.Base.Entity.Test
{
    public class Student
    {
        private string m_enrolledDate;

        public int StudentID { get; set; }

        [Display(Name = "FirstName", ResourceType = typeof(StudentResource))]  
        public string FirstName { get; set; }

        [Display(Name = "LastName", ResourceType = typeof(StudentResource))]  
        public string LastName { get; set; }

      //  public CustomDateTime CntEnrolledDate { get; set; }

        public CustomDateTime EnrolledDate { get; set; }

        public string EnrolledDateDB
        {
            get
            {
                return m_enrolledDate;
            } 
            set {
                m_enrolledDate = value;
                if (m_enrolledDate != null)
                {
                    EnrolledDate = m_enrolledDate;
                }
            }
        }
    }

    public class PostStudent
    {
        public int StudentID { get; set; }      
        public string FirstName { get; set; }       
        public string LastName { get; set; }
        public string EnrolledDate { get; set; }
    }
}
