﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Capgemini.GroupProduction.Base.Entity.Test.ValueObject
{
    public class StudentVO
    {
        public Student Student { get; set; }
        public CustomMessageList CustomMessages { get; set; }
    }
}
