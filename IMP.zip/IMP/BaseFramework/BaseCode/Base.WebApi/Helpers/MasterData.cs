﻿using Capgemini.GroupProduction.Base.Common;
using Capgemini.GroupProduction.Base.Repository;
using Capgemini.GroupProduction.VTF.Service;
using System.Collections.Generic;

namespace Capgemini.GroupProduction.Base.WebApi
{
    public class MasterData : IMasterData
    {
        public IEnumerable<Entity.RoleAccess> GetRoleAccess(long userID)
        {
            IUserManagmentBO m_userService = new UserManagmentBO(new UserManagementDO());
             return m_userService.GetRoleAccessAll(userID);
        }
    }
}