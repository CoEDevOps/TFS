﻿using Capgemini.GroupProduction.Base.WebApi.Filters;
using Capgemini.GroupProduction.VTF.Service;
using Capgemini.GroupProduction.Base.Repository;
using System.Web.Http;
using Microsoft.Practices.Unity;
using Capgemini.GroupProduction.VTF.Repository;
using Base.WebApi.Helpers;
using Capgemini.GroupProduction.Base.Service;
using Capgemini.GroupProduction.VTF.Repository.Test;
using System.Web.Http.ModelBinding.Binders;
using Capgemini.GroupProduction.Base.Entity.Binders;
using Capgemini.GroupProduction.Base.Entity;
using System.Web.Http.ModelBinding;

namespace Base.WebApi
{
    public static class WebApiConfig
    {
        /// <summary>
        /// Api routing
        /// </summary>
        /// <param name="config"></param>
        public static void Register(HttpConfiguration config)
        {
            // To handle routes like `/api/VTRouting/route`
            config.Routes.MapHttpRoute(
                name: "Default",
                routeTemplate: "api/{controller}/{action}/{id}/{sender}",
                defaults: new { id = RouteParameter.Optional, sender = RouteParameter.Optional }
            );

            config.Filters.Add(new UnhandledExceptionFilter());

            var provider = new SimpleModelBinderProvider(
            typeof(CustomDateTime), new CustomDateTimeModelBinderApi());

            config.Services.Insert(typeof(ModelBinderProvider), 0, provider);

            var container = new UnityContainer();
            container.RegisterType<IUserManagmentBO, UserManagmentBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IUserManagementDO, UserManagementDO>(new HierarchicalLifetimeManager());
            container.RegisterType<ICommonDO, CommonDO>(new HierarchicalLifetimeManager());
            container.RegisterType<ICommonBO, CommonBO>(new HierarchicalLifetimeManager());
            container.RegisterType<ITestBO, TestBO>(new HierarchicalLifetimeManager());
            container.RegisterType<ITestDO, TestDO>(new HierarchicalLifetimeManager());
            config.DependencyResolver = new UnityResolver(container);

        }
    }
}