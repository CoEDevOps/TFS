﻿using Capgemini.GroupProduction.Base.Entity;
using Capgemini.GroupProduction.Base.Entity.Binders;
using System.Linq;
using System.Web.Http;
using System.Web.Http.ModelBinding.Binders;

namespace Base.WebApi
{
    public class Global : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            WebApiConfig.Register(GlobalConfiguration.Configuration);

            //Define Formatters
            var formatters = GlobalConfiguration.Configuration.Formatters;
           // var jsonFormatter = formatters.JsonFormatter;
           // var settings = jsonFormatter.SerializerSettings;
            //settings.Formatting = Formatting.Indented;

            var appXmlType = formatters.XmlFormatter.SupportedMediaTypes.FirstOrDefault(t => t.MediaType == "application/xml");
            formatters.XmlFormatter.SupportedMediaTypes.Remove(appXmlType);

            //Add CORS Handler
            GlobalConfiguration.Configuration.MessageHandlers.Add(new CorsHandler());

           // var provider = new SimpleModelBinderProvider(
            //typeof(CustomDateTime), new CustomDateTimeModelBinderApi());

          //  ModelBinders.Binders.Add(typeof(CustomDateTime), new CustomDateTimeModelBinderApi());  
        }
    }
}