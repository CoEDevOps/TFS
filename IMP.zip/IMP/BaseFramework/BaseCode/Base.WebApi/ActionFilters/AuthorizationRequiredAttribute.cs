﻿using System.Net;
using System.Net.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using Capgemini.GroupProduction.VTF.Service;
using Capgemini.GroupProduction.Base.Repository;
using System.Web;
using Capgemini.GroupProduction.Base.Common;
using System;
using Capgemini.GroupProduction.Base.Entity;
using System.Collections.Generic;
using System.Web.Http.ModelBinding;

namespace Capgemini.GroupProduction.Base.WebApi.ActionFilters
{
    /// <summary>
    ///  The the authorization filter which executes before every action is executed.
    /// </summary>
    public class AuthorizationRequiredAttribute : ActionFilterAttribute
    {
        private bool m_onlyAuthenticate; 

        public AuthorizationRequiredAttribute(bool onlyAuthenticate = false)
        {
            m_onlyAuthenticate = onlyAuthenticate; 
        }

        /// <summary>
        /// Validates the user is authenticated user by validating the session cookie.
        /// In case the user is not authenticated then sends 401 Status code for 
        /// Unauthorized response. In case the user is authenticated and model state is
        /// not valid then send 400 Status code for Badrequest. 
        /// </summary>
        /// <param name="filterContext"></param>
        public override void OnActionExecuting(HttpActionContext filterContext)
        {           

            base.OnActionExecuting(filterContext);

            //Authenticate weather the session token is valid.
            if (!this.IsAuthenticated(filterContext))
            {
                var responseMessage = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "Invalid Request" };
                filterContext.Response = responseMessage;
                return;
            }

            //Only authentication no authorization
            if (m_onlyAuthenticate)
                return;

            //Check the user is authorized.
            if(!this.IsAuthorized(filterContext))
            {
                var responseMessage = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "Invalid Request" };
                filterContext.Response = responseMessage;
                return;
            }

            ModelStateDictionary modelStates = new ModelStateDictionary();

            if (!this.IsValidModelState(filterContext, modelStates))
            {
                filterContext.Response = filterContext.Request.CreateErrorResponse(
                       HttpStatusCode.BadRequest, modelStates);
            }

            
        }

        private bool IsAuthorized(HttpActionContext filterContext)
        {
            HttpClientCookie httpCookie = new HttpClientCookie();
            string userToken = httpCookie.GetUserTokenCookie(filterContext.Request.Headers);

            if (string.IsNullOrEmpty(userToken))
            {              
                return false;
            }

            string userTokenDecrypt = EncyrptDecrypt.Decrypt(userToken, false);

            string[] userTokenArray = userTokenDecrypt.Split('_');

            if (userTokenArray.Length != 2)
            {              
                return false;
            }

            HttpContext.Current.Items.Add("UserId", userTokenArray[0]);

            //string[] roleIDs = userTokenArray[1].Split(',');

            string actionName = filterContext.ActionDescriptor.ActionName;
            string controllerName = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;

            User user = new User();
            user.UserID = Convert.ToInt64(userTokenArray[0]);
            user.RoleIds = userTokenArray[1];
            UserAuthorization controllerActionRole = new UserAuthorization(user);           
            IEnumerable<RoleAccess> roleAccess = MemCacheHelper.GetAllRoleAccess(user.UserID, new MasterData());

            string url = string.Format(@"api/{0}/{1}", controllerName, actionName);

            if (!controllerActionRole.IsUrlAuthorized(url, roleAccess))
            {               
                return false;
            }

            return true;
           
        }

        private bool IsValidModelState(HttpActionContext filterContext, ModelStateDictionary modelStates)
        {
            if (filterContext.ModelState.IsValid)
            {
                return true;
            }

            foreach (var state in filterContext.ModelState)
            {
                string keyName = state.Key;
                if (keyName.IndexOf(".") != -1)
                {
                    keyName = keyName.Substring(keyName.IndexOf(".") + 1);
                }

                modelStates.Add(keyName, state.Value);
            }

            return false;
        }

        private bool IsAuthenticated(HttpActionContext filterContext)
        {
            //Dependancy resolver here
            IUserManagmentBO provider = new UserManagmentBO(new UserManagementDO());

            HttpClientCookie httpCookie = new HttpClientCookie();
            string sessionID = httpCookie.GetSessionCookie(filterContext.Request.Headers);

            if (string.IsNullOrEmpty(sessionID))
            {               
                return false;
            }

            // Validate Token
            if (provider != null && !provider.ValidateSession(sessionID))
            {               
                return false;
            }

            return true;
        }
    }
}