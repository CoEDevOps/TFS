﻿using Capgemini.GroupProduction.Base.Entity;
using Capgemini.GroupProduction.Base.Entity.Test;
using Capgemini.GroupProduction.Base.Entity.Test.ValueObject;
using Capgemini.GroupProduction.Base.Service;
using Capgemini.GroupProduction.Base.WebApi.ActionFilters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Web;
using System.Web.Http;

namespace Base.WebApi.Controllers.Test
{
    [AuthorizationRequiredAttribute(true)]
    public class TestController : ApiController
    {
        #region Private variable.
        

        private readonly ICommonBO m_commonBO;

        private readonly ITestBO m_testBO;

        #endregion

        #region Public Constructor

        /// <summary>
        /// Public constructor to initialize product service instance
        /// </summary>
        public TestController(ICommonBO commonBO, ITestBO testBO)
        {
            m_commonBO = commonBO;
            m_testBO = testBO;
        }

       
        #endregion

        /// <summary>
        /// Get default menu items
        /// </summary>
        /// <returns></returns>
        [ActionName("GetStudentInfo")]
        public HttpResponseMessage GetStudentInfo()
        {  
            string msgGroups = "Student";
            string language = Thread.CurrentThread.CurrentUICulture.Name;

            CustomMessageList lstMessages = m_commonBO.GetMessageByGroup(msgGroups, language);

            StudentVO studenVO = new StudentVO();
            studenVO.CustomMessages = lstMessages;

            return Request.CreateResponse(HttpStatusCode.OK, studenVO);
        }


        /// <summary>
        /// Get default menu items
        /// </summary>
        /// <returns></returns>
        [ActionName("SaveStudentInfo")]
        [HttpPost]
        public HttpResponseMessage SaveStudentInfo(Student student)
        { 
            Student std =  m_testBO.AddStudent(student);

            return Request.CreateResponse(HttpStatusCode.OK, std);
        }

        /// <summary>
        /// Get default menu items
        /// </summary>
        /// <returns></returns>
        [ActionName("GetStudentList")]
        public HttpResponseMessage GetStudentList()
        {           
            List<Student> stdLst = m_testBO.GetStudentList();

            return Request.CreateResponse(HttpStatusCode.OK, stdLst);
        }
    }
}