﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Collections.Generic;
using Capgemini.GroupProduction.VTF.Service;
using Capgemini.GroupProduction.Base.Repository;
using Capgemini.GroupProduction.Base.Entity;
using System.Linq;
using System;
using Capgemini.GroupProduction.Base.WebApi.ActionFilters;


namespace Capgemini.GroupProduction.Base.WebApi.Controllers.UserManagement
{
    [AuthorizationRequiredAttribute(true)]
    public class UserManagementController : ApiController
    {
        #region Private variable.
        

        private readonly IUserManagmentBO m_userService;

        #endregion

        #region Public Constructor

        /// <summary>
        /// Public constructor to initialize product service instance
        /// </summary>
        public UserManagementController(IUserManagmentBO userService)
        {            
            m_userService = userService;
        }

       
        #endregion

        /// <summary>
        /// Get default menu items
        /// </summary>
        /// <returns></returns>
        [ActionName("AllMenu")]
        public HttpResponseMessage GetAllMenu()
        {
            IEnumerable<MenuEntity> menu = m_userService.GetMenuItem();
            if (menu.Any())
                return Request.CreateResponse(HttpStatusCode.OK, menu);
            return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Menu not found");
        }

        /// Get default menu items
        /// </summary>
        /// <returns></returns>
        [ActionName("AllRoleMenu")]
        public HttpResponseMessage GetAllRoleMenu(Int64 id)
        {
            IEnumerable<MenuEntity> menu = m_userService.GetRoleMenuItem(id);
            if (menu.Any())
                return Request.CreateResponse(HttpStatusCode.OK, menu);
            return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Menu not found");
        }


        /// <summary>
        /// Get default menu items
        /// </summary>
        /// <returns></returns>
        [ActionName("AllRoleAccess")]
        public HttpResponseMessage GetAllRoleAccess(Int64 id)
        {
            IEnumerable<RoleAccess> roleAccess = m_userService.GetRoleAccessAll(id);

            return Request.CreateResponse(HttpStatusCode.OK, roleAccess);
        }

        /// <summary>
        /// Add user.
        /// </summary>
        /// <param name="user">User parameter</param>
        /// <returns>
        /// Added user information in case successfull.
        /// Unauthorized message in case the operation is not sucessful.
        /// </returns> 
        [HttpPost]
        [ActionName("AddUser")]
        public HttpResponseMessage AddUser(User user)
        {
            // var user = HttpContext.Current.Items["CurrentUser"];
            var addeduser = m_userService.AddUser(user);
            if (addeduser != null)
            {
                return Request.CreateResponse(HttpStatusCode.OK, (User)addeduser);
            }
            return new HttpResponseMessage(HttpStatusCode.Unauthorized); ;

        }
    }
}
