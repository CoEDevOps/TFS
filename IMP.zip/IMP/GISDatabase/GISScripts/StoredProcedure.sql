USE [GIS_DEV]
GO
/****** Object:  StoredProcedure [dbo].[spWorkOrderVsServiceReport]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[spWorkOrderVsServiceReport]
GO
/****** Object:  StoredProcedure [dbo].[spUpdateStage]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[spUpdateStage]
GO
/****** Object:  StoredProcedure [dbo].[spUpdateBUMaster]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[spUpdateBUMaster]
GO
/****** Object:  StoredProcedure [dbo].[spN2KLog]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[spN2KLog]
GO
/****** Object:  StoredProcedure [dbo].[spN2KData]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[spN2KData]
GO
/****** Object:  StoredProcedure [dbo].[spGetServiceNowInstanceAll]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[spGetServiceNowInstanceAll]
GO
/****** Object:  StoredProcedure [dbo].[spGetOrderReferanceStatus]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[spGetOrderReferanceStatus]
GO
/****** Object:  StoredProcedure [dbo].[spGetN2KDirInfo]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[spGetN2KDirInfo]
GO
/****** Object:  StoredProcedure [dbo].[spGetMenu]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[spGetMenu]
GO
/****** Object:  StoredProcedure [dbo].[spGetBUCode]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[spGetBUCode]
GO
/****** Object:  StoredProcedure [dbo].[spAddN2KHistory]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[spAddN2KHistory]
GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateWorkOrderStatus]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_UpdateWorkOrderStatus]
GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateWorkOrderServiceStatus]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_UpdateWorkOrderServiceStatus]
GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateWorkOrderReferenceIds]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_UpdateWorkOrderReferenceIds]
GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateServiceReferencIds]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_UpdateServiceReferencIds]
GO
/****** Object:  StoredProcedure [dbo].[sp_ResetWorkOrderReferencIds]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_ResetWorkOrderReferencIds]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetWorkOrdersbyWONumber]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetWorkOrdersbyWONumber]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetUserName]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetUserName]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetUser]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetUser]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetServiceNowServicesReference]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetServiceNowServicesReference]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetServiceNowInstance]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetServiceNowInstance]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetServiceMasterList]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetServiceMasterList]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetServiceMasterByIds]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetServiceMasterByIds]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetServiceByWorkOrderId]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetServiceByWorkOrderId]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetRoleMenu]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetRoleMenu]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetRoleControllerAction]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetRoleControllerAction]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetQueueWorkOrders]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetQueueWorkOrders]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetNewWorkOrderDetails]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetNewWorkOrderDetails]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetMyWorkOrders]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetMyWorkOrders]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetMessageByGroups]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetMessageByGroups]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetMessage]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetMessage]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetEngagementDetailsforWO]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetEngagementDetailsforWO]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetEngagementDetails]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetEngagementDetails]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAllCatalog]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_GetAllCatalog]
GO
/****** Object:  StoredProcedure [dbo].[sp_AddWorkOrderDetails]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_AddWorkOrderDetails]
GO
/****** Object:  StoredProcedure [dbo].[sp_AddWorkOrderAllServices]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_AddWorkOrderAllServices]
GO
/****** Object:  StoredProcedure [dbo].[sp_AddNewUser]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[sp_AddNewUser]
GO
/****** Object:  StoredProcedure [dbo].[ELMAH_LogError]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[ELMAH_LogError]
GO
/****** Object:  StoredProcedure [dbo].[ELMAH_GetErrorXml]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[ELMAH_GetErrorXml]
GO
/****** Object:  StoredProcedure [dbo].[ELMAH_GetErrorsXml]    Script Date: 02-09-2016 15:31:17 ******/
DROP PROCEDURE [dbo].[ELMAH_GetErrorsXml]
GO
/****** Object:  UserDefinedFunction [dbo].[BreakStringIntoRows]    Script Date: 02-09-2016 15:31:17 ******/
DROP FUNCTION [dbo].[BreakStringIntoRows]
GO
/****** Object:  UserDefinedFunction [dbo].[BreakStringIntoRows]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[BreakStringIntoRows] (@CommadelimitedString   varchar(1000))
RETURNS   @Result TABLE (Column1   VARCHAR(100))
AS
BEGIN
        DECLARE @IntLocation INT
        WHILE (CHARINDEX(',',    @CommadelimitedString, 0) > 0)
        BEGIN
              SET @IntLocation =   CHARINDEX(',',    @CommadelimitedString, 0)      
              INSERT INTO   @Result (Column1)
              --LTRIM and RTRIM to ensure blank spaces are   removed
              SELECT RTRIM(LTRIM(SUBSTRING(@CommadelimitedString,   0, @IntLocation)))   
              SET @CommadelimitedString = STUFF(@CommadelimitedString,   1, @IntLocation,   '') 
        END
        INSERT INTO   @Result (Column1)
        SELECT RTRIM(LTRIM(@CommadelimitedString))--LTRIM and RTRIM to ensure blank spaces are removed
        RETURN 
END


GO
/****** Object:  StoredProcedure [dbo].[ELMAH_GetErrorsXml]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		VTF Team, Auto generated
-- Create date: 20 April 2106
-- Description:	get Elmah XML error 
-- =============================================

CREATE PROCEDURE [dbo].[ELMAH_GetErrorsXml]
(
    @Application NVARCHAR(60),
    @PageIndex INT = 0,
    @PageSize INT = 15,
    @TotalCount INT OUTPUT
)
AS 

    SET NOCOUNT ON

	BEGIN TRY 

		DECLARE @FirstTimeUTC DATETIME
		DECLARE @FirstSequence INT
		DECLARE @StartRow INT
		DECLARE @StartRowIndex INT

		SELECT 
			@TotalCount = COUNT(1) 
		FROM 
			[ELMAH_Error]
		WHERE 
			[Application] = @Application

		-- Get the ID of the first error for the requested page

		SET @StartRowIndex = @PageIndex * @PageSize + 1

		IF @StartRowIndex <= @TotalCount
		BEGIN

			SET ROWCOUNT @StartRowIndex

			SELECT  
				@FirstTimeUTC = [TimeUtc],
				@FirstSequence = [Sequence]
			FROM 
				[ELMAH_Error]
			WHERE   
				[Application] = @Application
			ORDER BY 
				[TimeUtc] DESC, 
				[Sequence] DESC

		END
		ELSE
		BEGIN

			SET @PageSize = 0

		END

		-- Now set the row count to the requested page size and get
		-- all records below it for the pertaining application.

		SET ROWCOUNT @PageSize

		SELECT 
			errorId     = [ErrorId], 
			application = [Application],
			host        = [Host], 
			type        = [Type],
			source      = [Source],
			message     = [Message],
			[user]      = [User],
			statusCode  = [StatusCode], 
			time        = CONVERT(VARCHAR(50), [TimeUtc], 126) + 'Z'
		FROM 
			[ELMAH_Error] error
		WHERE
			[Application] = @Application
		AND
			[TimeUtc] <= @FirstTimeUTC
		AND 
			[Sequence] <= @FirstSequence
		ORDER BY
			[TimeUtc] DESC, 
			[Sequence] DESC
		FOR
			XML AUTO

	END TRY

	BEGIN CATCH  

	   DECLARE @error INT, @message VARCHAR(4000), @state INT, @severity INT
	   SELECT @error = ERROR_NUMBER(),@message = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY();   	
	   RAISERROR ('ELMAH_GetErrorsXml: %d: %s', @severity, @state, @error, @message) ;    
   	
	END CATCH


GO
/****** Object:  StoredProcedure [dbo].[ELMAH_GetErrorXml]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		VTF Team, Auto generated
-- Create date: 20 April 2106
-- Description:	get Elmah XML error 
-- =============================================

CREATE PROCEDURE [dbo].[ELMAH_GetErrorXml]
(
    @Application NVARCHAR(60),
    @ErrorId UNIQUEIDENTIFIER
)
AS

    SET NOCOUNT ON

	BEGIN TRY
		SELECT 
			[AllXml]
		FROM 
			[ELMAH_Error]
		WHERE
			[ErrorId] = @ErrorId
		AND
			[Application] = @Application
	END TRY
	BEGIN CATCH  
	   DECLARE @error INT, @message VARCHAR(4000), @state INT, @severity INT
	   SELECT @error = ERROR_NUMBER(),@message = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
	   RAISERROR ('ELMAH_GetErrorXml: %d: %s', @severity, @state, @error, @message)      	
	END CATCH
	

GO
/****** Object:  StoredProcedure [dbo].[ELMAH_LogError]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		VTF Team, Auto generated
-- Create date: 20 April 2106
-- Description:	log error 
-- =============================================

CREATE PROCEDURE [dbo].[ELMAH_LogError]
(
    @ErrorId UNIQUEIDENTIFIER,
    @Application NVARCHAR(60),
    @Host NVARCHAR(30),
    @Type NVARCHAR(100),
    @Source NVARCHAR(60),
    @Message NVARCHAR(500),
    @User NVARCHAR(50),
    @AllXml NTEXT,
    @StatusCode INT,
    @TimeUtc DATETIME
)
AS

    SET NOCOUNT ON

	BEGIN TRY

		INSERT
		INTO
			[ELMAH_Error]
			(
				[ErrorId],
				[Application],
				[Host],
				[Type],
				[Source],
				[Message],
				[User],
				[AllXml],
				[StatusCode],
				[TimeUtc]
			)
		VALUES
			(
				@ErrorId,
				@Application,
				@Host,
				@Type,
				@Source,
				@Message,
				@User,
				@AllXml,
				@StatusCode,
				@TimeUtc
			)
	END TRY
	BEGIN CATCH  
	   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
	   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
	   RAISERROR ('ELMAH_LogError: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH


GO
/****** Object:  StoredProcedure [dbo].[sp_AddNewUser]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		VTF Team, Rony Lobo
-- Create date: 20 April 2106
-- Description:	Add New User Details
-- =============================================
CREATE PROCEDURE [dbo].[sp_AddNewUser]( 
	@username NVARCHAR(50),
	@name NVARCHAR(50) ,
	@email NVARCHAR(100) 
	)
AS
BEGIN
   SET NOCOUNT ON;

   BEGIN TRY
	   IF not exists (SELECT UserId FROM dbo.[tblUser] WHERE UserName = @username)
			BEGIN	
				BEGIN TRANSACTION trans
					BEGIN TRY	 
						INSERT INTO dbo.[tblUser](UserName, Name,Email) VALUES (@username,@name,@email)

						DECLARE @UserID int;
						SELECT @UserID = @@IDENTITY

						-- insert engagment role by default
						INSERT INTO dbo.[tblUserRole](UserID, RoleID) VALUES (@UserID, 3)

						IF @@TRANCOUNT > 0
						BEGIN 
							COMMIT TRANSACTION trans
						END
					END TRY
					BEGIN CATCH
						IF @@TRANCOUNT > 0
							BEGIN 
								ROLLBACK TRANSACTION trans
							END
					END CATCH 
			END
	
	   SELECT UserId,UserName,Name,Email,
	  (SELECT  STUFF((SELECT ', ' + CAST(RoleID AS VARCHAR(10)) [text()]
			 FROM dbo.tblUserRole 
			 WHERE dbo.tblUserRole.UserID = usrRole.UserID
			 FOR XML PATH(''), TYPE)
			.value('.','NVARCHAR(MAX)'),1,2,' ') RoleID
		FROM dbo.tblUserRole usrRole
		WHERE usrRole.UserID = dbo.[tblUser].UserId
		GROUP BY UserID) as RoleIds   
		FROM  dbo.[tblUser] WHERE UserName = @username
	
	END TRY
	BEGIN CATCH  
	   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
	   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
	   RAISERROR ('sp_AddNewUser: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END





GO
/****** Object:  StoredProcedure [dbo].[sp_AddWorkOrderAllServices]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		VTF Team, Rony Lobo
-- Create date: 06 May 2016
-- Description:	Add Work Order Services
-- =============================================
CREATE  PROCEDURE [dbo].[sp_AddWorkOrderAllServices]( 
	@Services AS VARCHAR(MAX),	
	@Message varchar(500) OUTPUT, 
	@Transaction int OUTPUT,
	@WorkOrderNumber varchar(10) OUTPUT	
	)
AS
BEGIN
    SET NOCOUNT ON;

	BEGIN TRY

		DECLARE @XML AS XML
		DECLARE @WorkOrderID int;	
		DECLARE @FactoryID int;

		SELECT @XML = @Services
		SET @Transaction = 0;
		SET @Message = '';

		SELECT @WorkOrderID = M.Item.query('./WorkOrderID').value('.','bigint')
		FROM @XML.nodes('/ArrayOfWorkOrderService/WorkOrderService') AS M(Item);

		INSERT INTO dbo.tblWorkOrderServices (WorkOrderId, ServiceId, StartDate, 
		EndDate, [FileName], [DisplayFileName], [Status], [CreatedBy],[Remarks])
			SELECT M.Item.query('./WorkOrderID').value('.','bigint') WorkOrderId,
				   M.Item.query('./ServiceId').value('.','bigint') ServiceId,
				   M.Item.query('./StartDate').value('.','DateTime') StartDate,
				   M.Item.query('./EndDate').value('.','DateTime') [FileName],
				   M.Item.query('./FileName').value('.','nvarchar(200)') [FileName],  
				   M.Item.query('./DisplayFileName').value('.','nvarchar(200)') DisplayFileName,     
				   0 [Status],  -- Default status AnalyzeRequirement  
				   M.Item.query('./UserID').value('.','bigint') [CreatedBy],
				   M.Item.query('./Remarks').value('.','nvarchar(250)') Remarks
			FROM @XML.nodes('/ArrayOfWorkOrderService/WorkOrderService') AS M(Item)

		SET @Transaction = 1;

		--SELECT @Message = [MessageValue] FROM dbo.tblMessage WHERE MessageKey = 'WorkOrderServiceSuccess';
		--SET @Message = 'Your Work Order is Created Sucessfully ';

		SET @WorkOrderNumber =  'WO' + RIGHT('00000000' + CONVERT(varchar(10), @WorkOrderID ) , 8);	
	
		--SET @Message = 'Your Work Order (#'+ @WorkOrderNumber +') is Created Sucessfully ';

		SELECT @Message = [Message] FROM dbo.tblMessage WHERE MessageKey = 'WorkOrderNumber';
    
		SELECT @Message = REPLACE(@Message,'@WorkOrderNumber',@WorkOrderNumber); 

		 -- Factory selection logic will come
		SET @FactoryID = 1;

		UPDATE dbo.tblWorkOrder
		SET WorkOrderNumber = @WorkOrderNumber,
			FactoryID = @FactoryID
		WHERE WorkOrderId = @WorkOrderID;
        
		--SELECT WorkOrderId, ServiceId, StartDate, 
		--EndDate, [FileName], [Status], [CreatedBy] FROM 
		--dbo.tblWorkOrderServices WHERE WorkOrderId = @WorkOrderID

		SELECT 1;

	END TRY
	BEGIN CATCH  
	   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
	   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
	   RAISERROR ('sp_AddWorkOrderAllServices: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END







GO
/****** Object:  StoredProcedure [dbo].[sp_AddWorkOrderDetails]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		VTF Team, Rony Lobo
-- Create date: 06 May 2016
-- Description:	Add New User Details
-- =============================================
CREATE PROCEDURE [dbo].[sp_AddWorkOrderDetails]( 
	--@WorkOrderNumber varchar(100) ,
	@EngagementCode VARCHAR(50),
	@Priority INT,
	@StartDate DATE,
	@EndDate DATE,
	@Status INT,
	@User INT
	
	)
AS
BEGIN
    SET NOCOUNT ON;
	DECLARE @WOId bigint;
		
	BEGIN TRANSACTION trans
	BEGIN TRY	 
		INSERT INTO dbo.[tblWorkOrder](
			--WorkOrderNumber,
			EngagementCode,
			[Priority],
			StartDate,
			EndDate,
			[Status],
			CreatedBy,
			CreatedDate			
			) VALUES (
			--@WorkOrderNumber,
			@EngagementCode,
			@Priority,
			@StartDate,
			@EndDate,
			@Status,
			@User,
			GETDATE()
			)

		SELECT @WOId = @@IDENTITY

		IF @@TRANCOUNT > 0
		BEGIN 
			COMMIT TRANSACTION trans
		END
	END TRY
	BEGIN CATCH
		SET @WOId = 0;
		IF @@TRANCOUNT > 0
			BEGIN 
				ROLLBACK TRANSACTION trans
			END
	END CATCH 
	
 
	select @WOId	
END




GO
/****** Object:  StoredProcedure [dbo].[sp_GetAllCatalog]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		VTF Team, Vijay Nadar
-- Create date: 20 April 2106
-- Description:	Get all Catalogs
-- =============================================

CREATE PROCEDURE [dbo].[sp_GetAllCatalog]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT CatalogID, [Name], [Status] FROM dbo.tblCatalog;
END



GO
/****** Object:  StoredProcedure [dbo].[sp_GetEngagementDetails]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		VTF Team, Rony Lobo
-- Create date: 20 April 2106
-- Description:	Fetch the engagement details 
--based on keyword entered
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetEngagementDetails]( 
	@code VARCHAR(30) 
	)
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		SELECT TOP 10
			ProjectCode AS EngagementCode, 
			ProjectName AS EngagementName 
			FROM [dbo].[tblN2KData] WITH (NOLOCK) 
		WHERE ProjectCode LIKE '%' + @code + '%' 
		OR 
		ProjectName LIKE '%' + @code + '%'
	END TRY
	BEGIN CATCH  
	   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
	   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
	   RAISERROR ('sp_GetEngagementDetails: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END





GO
/****** Object:  StoredProcedure [dbo].[sp_GetEngagementDetailsforWO]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		VTF Team, Rony Lobo
-- Create date: 03 May 2106
-- Description:	Get Engagement Details required for work order
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetEngagementDetailsforWO]( 
	@code VARCHAR(30),
	@WorkOrderId BIGINT  = null
	)
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
		DECLARE @FactoryServiceInstanceID int;
		DECLARE @IsServiceInstanceAvailable bit

		DECLARE @workOrder table(
		 WorkOrderId bigint,
		 WorkOrderNumber varchar(100),
		 EngagementCode varchar(50),
		 ProjectManager nvarchar(120),
		 EngagementName nvarchar(120),
		 CustomerName nvarchar(120),
		 [Priority] int,
		 StartDate datetime,
		 EndDate datetime,	 
		 FactoryID int,
		 [Status] int 
		);
	
		SET @IsServiceInstanceAvailable = 0;

		IF (@WorkOrderId is null OR @WorkOrderId = 0)
		--Get Engagement Details for new work order
			BEGIN	
				INSERT INTO @workOrder(	WorkOrderId,WorkOrderNumber,
				 EngagementCode, ProjectManager, EngagementName,
				 CustomerName, [Priority], StartDate ,
				 EndDate, [Status])
				SELECT 
					null AS WorkOrderId, 
					null AS WorkOrderNumber,
					ProjectCode AS EngagementCode, 
					EngagementManager AS ProjectManager,
					ProjectName AS EngagementName,					
					CustomerName AS CustomerName,
					0 AS [Priority],
					null AS StartDate,
					null AS EndDate,
					0			
				FROM [dbo].[tblN2KData] WITH (NOLOCK) 
				WHERE ProjectCode = @code
			END
    
		ELSE
			--Get Engagement Details along with work order details for new work order
			BEGIN
			  INSERT INTO @workOrder(WorkOrderId, WorkOrderNumber,
				 EngagementCode, ProjectManager, EngagementName,
				 CustomerName, [Priority], StartDate ,
				 EndDate, FactoryID, [Status] )
				SELECT 
					w.WorkOrderId AS WorkOrderId, 
					w.WorkOrderNumber AS WorkOrderNumber,
					e.ProjectCode AS EngagementCode, 
					e.EngagementManager AS ProjectManager,
					e.ProjectName AS EngagementName,					
					e.CustomerName AS CustomerName,
					w.Priority AS [Priority],
					w.StartDate AS StartDate,
					w.EndDate AS EndDate,
					w.FactoryID,
					w.[Status]
				FROM [dbo].[tblN2KData] e WITH (NOLOCK) 
				INNER JOIN [dbo].[tblWorkOrder] w WITH (NOLOCK)
				ON e.ProjectCode = w.EngagementCode
				WHERE w.WorkOrderId = @WorkOrderId;			

				SELECT @FactoryServiceInstanceID = dbo.tblSnowInstance.InstanceId  
				FROM @workOrder wrkOrder
				INNER JOIN dbo.tblSnowInstance ON 
				dbo.tblSnowInstance.FactoryID = wrkOrder.FactoryID
				AND dbo.tblSnowInstance.Active = 1;
			
				--PRINT 'PRINT'
				--PRINT @FactoryServiceInstanceID
				IF @FactoryServiceInstanceID > 0 
				BEGIN 
				  SET @IsServiceInstanceAvailable = 1;
				END 
			END


			SELECT WorkOrderId,WorkOrderNumber,
						 EngagementCode, ProjectManager, EngagementName,
						 CustomerName, [Priority], StartDate ,
						 EndDate , @IsServiceInstanceAvailable as IsServiceInstanceAvailable, [Status]
			FROM @workOrder;
	  END TRY
	  BEGIN CATCH  
	   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
	   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
	   RAISERROR ('sp_GetEngagementDetailsforWO: %d: %s', @severity, @state, @error, @errmessage)      	
	  END CATCH
END







GO
/****** Object:  StoredProcedure [dbo].[sp_GetMessage]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetMessage]
	-- Add the parameters for the stored procedure here
	@MessageKey varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY
		-- Insert statements for procedure here
		SELECT MessageKey, MessageType, [Message] FROM dbo.tblMessage
		WHERE MessageKey = @MessageKey;
	END TRY
	BEGIN CATCH  
	   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
	   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
	   RAISERROR ('sp_GetMessage: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END



GO
/****** Object:  StoredProcedure [dbo].[sp_GetMessageByGroups]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetMessageByGroups]
	-- Add the parameters for the stored procedure here
	@MessageGroups varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY
		-- Insert statements for procedure here
		SELECT MessageKey, MessageType, [Message] FROM dbo.tblMessage
		WHERE MessageGroup IN (SELECT Column1 FROM dbo.BreakStringIntoRows(@MessageGroups));
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('sp_GetMessageByGroups: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END



GO
/****** Object:  StoredProcedure [dbo].[sp_GetMyWorkOrders]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		VTF Team, Rony Lobo
-- Create date: 19 May 2106
-- Description:	Get My Work Orders
-- =============================================
CREATE  PROCEDURE [dbo].[sp_GetMyWorkOrders]( 	
	@User BIGINT  = null
	)
AS
BEGIN
	SET NOCOUNT ON;	
	BEGIN TRY
		IF (@User is null OR @User = 0)
		
			--Get All Work Order Details
			BEGIN				
				SELECT 
					wo.WorkOrderId,
					wo.WorkOrderNumber,
					wo.WorkOrderReferenceNo,
					wo.EngagementCode,
					wo.Priority,
					wo.StartDate,
					wo.EndDate,
					wo.Status,
					n2k.ProjectName as EngagementName,
					n2k.CustomerName								
				FROM [dbo].[tblWorkOrder] wo WITH (NOLOCK) 
				INNER JOIN [dbo].[tblN2KData] n2k WITH (NOLOCK) 
				ON wo.EngagementCode = n2k.ProjectCode
				WHERE wo.WorkOrderNumber IS NOT NULL 
				ORDER BY wo.CreatedDate DESC
			END
    
		ELSE
			--Get Work order details for user
			BEGIN 
				SELECT 
					wo.WorkOrderId,
					wo.WorkOrderNumber,
					wo.WorkOrderReferenceNo,
					wo.EngagementCode,
					wo.Priority,
					wo.StartDate,
					wo.EndDate,
					wo.Status,
					n2k.ProjectName  as EngagementName,
					n2k.CustomerName							
				FROM [dbo].[tblWorkOrder] wo WITH (NOLOCK) 
				INNER JOIN [dbo].[tblN2KData] n2k WITH (NOLOCK) 
				ON wo.EngagementCode = n2k.ProjectCode
				WHERE wo.WorkOrderNumber IS NOT NULL AND wo.CreatedBy = @User
				ORDER BY wo.CreatedDate DESC
			END
		END TRY
		BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('sp_GetMyWorkOrders: %d: %s', @severity, @state, @error, @errmessage)      	
		END CATCH
END





GO
/****** Object:  StoredProcedure [dbo].[sp_GetNewWorkOrderDetails]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		VTF Team, Rony Lobo
-- Create date: 20 May 2106
-- Description:	Get New Work Order Details for Email
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetNewWorkOrderDetails]( 
	@workorderId BIGINT 
	)
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY

		DECLARE @ServiceList VARCHAR(MAX)
		select @ServiceList = COALESCE(ltrim(rtrim(@ServiceList)) + ', ', '') + sm.ServiceName	
		from [dbo].[tblServiceMaster] sm
		INNER JOIN [dbo].[tblWorkOrderServices] wos
		ON sm.ServiceId = wos.ServiceId
		WHERE wos.WorkOrderId = @WorkOrderId

		DECLARE @workOrder TABLE(
		WorkOrderId bigint,
		WorkOrderNumber varchar(100),
		EngagementCode nvarchar(120),
		EngagementName nvarchar(120),
		ProjectManager nvarchar(120),
		CustomerName nvarchar(120),
		FactoryID int,
		[Priority] int,
		StartDate DateTime,
		EndDate DateTime,
		Services varchar(max),
		[User] nvarchar(100),
		[Status] INT,
		UserEmail varchar(100)
		);

		INSERT INTO @workOrder(WorkOrderId, WorkOrderNumber, EngagementCode, 
		 EngagementName, ProjectManager, CustomerName, FactoryID, [Priority], StartDate,
		  EndDate, Services,[User], [Status],UserEmail)
		SELECT 		
			w.WorkOrderId,
			w.WorkOrderNumber,
			e.ProjectCode, 
			e.ProjectName,
			e.EngagementManager,		
			e.CustomerName,
			w.FactoryID,
			w.Priority,
			w.StartDate,
			w.EndDate,
			@ServiceList,
			u.Name,
			w.Status,
			u.Email
		FROM [dbo].[tblN2KData] e WITH (NOLOCK) 
		INNER JOIN [dbo].[tblWorkOrder] w WITH (NOLOCK)	
		ON e.ProjectCode = w.EngagementCode
		INNER JOIN [dbo].[tblUser] u WITH (NOLOCK)
		ON u.UserId = w.CreatedBy 
		WHERE WorkOrderNumber is not NULL AND w.WorkOrderId = @WorkOrderId
	
		DECLARE @factoryManagerEmailIds varchar(250)
		SET @factoryManagerEmailIds = ''

		SELECT  @factoryManagerEmailIds = @factoryManagerEmailIds + dbo.tblUser.Email + ', ' FROM dbo.tblFactoryUser
		INNER JOIN dbo.tblFactoryMaster ON 
		dbo.tblFactoryMaster.FactoryID = dbo.tblFactoryUser.FactoryID
		INNER JOIN dbo.tblUserRole ON 
		dbo.tblFactoryUser.UserID = dbo.tblUserRole.UserID
		AND  dbo.tblUserRole.RoleID = 2 
		INNER JOIN dbo.tblUser ON
		dbo.tblFactoryUser.UserID = dbo.tblUser.UserId
		WHERE dbo.tblFactoryMaster.FactoryID IN(SELECT FactoryID FROM 
		@workOrder);

		SELECT  @factoryManagerEmailIds = SUBSTRING(@factoryManagerEmailIds, 0, LEN(@factoryManagerEmailIds))


		SELECT WorkOrderId, WorkOrderNumber, EngagementCode, 
		EngagementName, ProjectManager, CustomerName, @factoryManagerEmailIds as FactoryManagerEmailIDs, [Priority], StartDate,
		EndDate, Services,[User],FactoryID,[Status],UserEmail
		FROM @workOrder
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('sp_GetNewWorkOrderDetails: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[sp_GetQueueWorkOrders]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		VTF Team, Rony Lobo
-- Create date: 19 May 2106
-- Description:	Get My Work Orders
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetQueueWorkOrders]( 	
	@User BIGINT  = null
	)
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		--Get Work order details for user
		BEGIN 
			SELECT 
				wo.WorkOrderId,
				wo.WorkOrderNumber,
				wo.WorkOrderReferenceNo,
				wo.EngagementCode,
				wo.Priority,
				wo.StartDate,
				wo.EndDate,
				wo.Status,
				n2k.ProjectName  as EngagementName,
				n2k.CustomerName							
			FROM [dbo].[tblWorkOrder] wo WITH (NOLOCK) 
			INNER JOIN [dbo].[tblN2KData] n2k WITH (NOLOCK) 
			ON wo.EngagementCode = n2k.ProjectCode
			WHERE wo.WorkOrderNumber IS NOT NULL And 
			wo.FactoryID IN (SELECT FactoryID
		FROM dbo.tblFactoryUser 
		WHERE UserID = @User)
	    ORDER BY wo.CreatedDate DESC
		END
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('sp_GetQueueWorkOrders: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END





GO
/****** Object:  StoredProcedure [dbo].[sp_GetRoleControllerAction]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetRoleControllerAction]
	-- Add the parameters for the stored procedure here
	@UserID bigint
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY
		IF @UserID > 0 
		BEGIN 
			--DECLARE @RoleID varchar(200);		

			/* SELECT @RoleID = STUFF((SELECT ', ' + CAST(RoleID AS VARCHAR(10)) [text()]
			 FROM dbo.tblUserRole 
			 WHERE dbo.tblUserRole.UserID = usrRole.UserID
			 FOR XML PATH(''), TYPE)
			.value('.','NVARCHAR(MAX)'),1,2,' ')
			FROM dbo.tblUserRole usrRole
			WHERE usrRole.UserID = @UserID
			GROUP BY UserID*/

			-- Insert statements for procedure here
			SELECT UrlID, Url,
			  (SELECT  STUFF((SELECT ', ' + CAST(RoleID AS VARCHAR(10)) [text()]
				 FROM dbo.tblRoleAccess 
				 WHERE dbo.tblRoleAccess.UrlID = roleAccess.UrlID
				 FOR XML PATH(''), TYPE)
				.value('.','NVARCHAR(MAX)'),1,2,' ') RoleID
			FROM dbo.tblRoleAccess roleAccess
			WHERE roleAccess.UrlID = cntmaster.UrlID 
			GROUP BY UrlID) as RoleIds
			FROM dbo.tblUrlMaster cntmaster
			WHERE cntmaster.UrlID IN (SELECT UrlID
			FROM dbo.tblRoleAccess 
			INNER JOIN dbo.tblUserRole ON UserID = @UserID
			AND dbo.tblRoleAccess.RoleID  = dbo.tblUserRole.RoleID  
			)

			/*SELECT ControllerActionID,ControllerName,ActionName, @RoleID as RoleIds  FROM dbo.tblControllerActionMaster
			WHERE  ControllerActionID IN(
			SELECT ControllerActionID
			FROM dbo.tblRoleAccess
			WHERE RoleID = @RoleID);*/
		END
		ELSE 
		BEGIN
		 /* SELECT ControllerActionID,ControllerName,ActionName,
		  (SELECT  STUFF((SELECT ', ' + CAST(RoleID AS VARCHAR(10)) [text()]
			 FROM dbo.tblRoleAccess 
			 WHERE dbo.tblRoleAccess.ControllerActionID = roleAccess.ControllerActionID
			 FOR XML PATH(''), TYPE)
			.value('.','NVARCHAR(MAX)'),1,2,' ') RoleID
		FROM dbo.tblRoleAccess roleAccess
		WHERE roleAccess.ControllerActionID = cntmaster.ControllerActionID 
		GROUP BY ControllerActionID) as RoleIds
		FROM dbo.tblControllerActionMaster cntmaster*/


		SELECT UrlID, Url,
		  COALESCE((SELECT  STUFF((SELECT ', ' + CAST(RoleID AS VARCHAR(10)) [text()]
			 FROM dbo.tblRoleAccess 
			 WHERE dbo.tblRoleAccess.UrlID = roleAccess.UrlID
			 FOR XML PATH(''), TYPE)
			.value('.','NVARCHAR(MAX)'),1,2,' ') RoleID
		FROM dbo.tblRoleAccess roleAccess
		WHERE roleAccess.UrlID = cntmaster.UrlID 
		GROUP BY UrlID), '') as RoleIds
		FROM dbo.tblUrlMaster cntmaster


		END
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('sp_GetRoleControllerAction: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH

END


GO
/****** Object:  StoredProcedure [dbo].[sp_GetRoleMenu]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetRoleMenu] 
	-- Add the parameters for the stored procedure here
	@UserID bigint
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY
		DECLARE @RoleID int;

		/*SELECT @RoleID = userRole.RoleID
		FROM dbo.tblUserRole userRole 
		Where UserID = @UserID
		*/
	
		SELECT MenuName,
		   [Description],
		   cntrMaster.Url,		   
		   MenuOrder
		FROM dbo.tblMenu menu
		INNER JOIN dbo.tblUrlMaster cntrMaster ON
		menu.UrlID = cntrMaster.UrlID
		WHERE ID IN(
		SELECT Distinct menu.ID 
		FROM dbo.tblRoleMenuAccess roleMenu 	
		INNER JOIN dbo.tblMenu menu ON roleMenu.MenuID = menu.ID
		Where RoleID 
		IN
		(SELECT RoleID FROm tblUserRole WHERE UserID =@UserID) 
		)
		Order By MenuOrder ASC
    END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('sp_GetRoleMenu: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END


GO
/****** Object:  StoredProcedure [dbo].[sp_GetServiceByWorkOrderId]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetServiceByWorkOrderId] 
	-- Add the parameters for the stored procedure here
	@WorkOrderID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY
		SELECT WorkOrderId, wrkser.ServiceId, wrkser.WorkOrderServiceId, sermas.ServiceName, StartDate, 
		EndDate, [FileName], [DisplayFileName], wrkser.ServiceReferenceNumber, [Status], wrkser.[CreatedBy],
		wrkser.Remarks,wrkser.Comments,wrkser.URL,wrkser.CreatedDate,sermas.InputFilePath 
		FROM dbo.tblWorkOrderServices wrkser
		INNER JOIN dbo.tblServiceMaster sermas ON
		wrkser.ServiceID =  sermas.ServiceID
		WHERE WorkOrderId = @WorkOrderID
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('sp_GetServiceByWorkOrderId: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END


GO
/****** Object:  StoredProcedure [dbo].[sp_GetServiceMasterByIds]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetServiceMasterByIds]
   @serviceIds  as varchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
		DECLARE @XML AS XML
		SET @XML = @serviceIds	

		SELECT	ServiceId, 
					ServiceName, 
					ShortDescription, 
					Features 
				FROM [dbo].[tblServiceMaster] WITH (NOLOCK) 
				WHERE ServiceId IN( 
				 SELECT M.Item.query('.').value('.','int') 
				 FROM @XML.nodes('/ArrayOfInt/int') AS M(Item)			
				) AND Active=1  
		ORDER BY ServiceName ASC
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('sp_GetServiceMasterByIds: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END
END


GO
/****** Object:  StoredProcedure [dbo].[sp_GetServiceMasterList]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		VTF Team, Rony Lobo
-- Create date: 03 May 2106
-- Description:	Get Service Master List
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetServiceMasterList] (
@serviceId int
)
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
	IF (@serviceId <> 0)
		BEGIN
			SELECT
				ServiceId, 
				ServiceName,
				ServiceShortName, 
				ShortDescription, 
				Features,
				Eligibility,
				EligibilityDescription,
                Pricing,
				Support,
				InputFilePath,
				OutputFilePath 
			FROM [dbo].[tblServiceMaster] WITH (NOLOCK) 
			WHERE ServiceId = @serviceId AND Active=1  
			ORDER BY ServiceName ASC
		END
	ELSE
		BEGIN
			SELECT
				ServiceId, 
				ServiceName, 
				ServiceShortName,
				ShortDescription, 
				Features,
				Eligibility,
				EligibilityDescription,
                Pricing, 
				Support,
				InputFilePath,
				OutputFilePath 
			FROM [dbo].[tblServiceMaster] WITH (NOLOCK) 
			WHERE Active=1 
			ORDER BY ServiceName ASC
		END
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('sp_GetServiceMasterList: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END


GO
/****** Object:  StoredProcedure [dbo].[sp_GetServiceNowInstance]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		VTF Team, Rony Lobo
-- Create date: 14 Jun 2106
-- Description:	Get Service Now Instance Details
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetServiceNowInstance](
	@factoryId INT,
	@WorkOrderId BIGINT = NULL
)
AS
BEGIN
	SET NOCOUNT ON;
	
	IF @WorkOrderId IS NOT NULL		
		BEGIN		
			SELECT @factoryId = factoryId FROM [dbo].[tblWorkOrder] WHERE workorderid = @WorkOrderId			
		END	
	BEGIN TRY
		SELECT 
			InstanceId,
			Name,
			FactoryId,
			Url as SnowUrl,
			Username as SnowUserName,
			Password as SnowPassword,
			TimeDifference as TimeDiff,
			Active	
			FROM [dbo].[tblSnowInstance] WITH (NOLOCK)
			WHERE factoryId =  @factoryId
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('sp_GetServiceNowInstance: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END


GO
/****** Object:  StoredProcedure [dbo].[sp_GetServiceNowServicesReference]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		VTF Team, Rony Lobo
-- Create date: 14 Jun 2106
-- Description:	Get Service Now Catalog Service Mapping Ids
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetServiceNowServicesReference](
	@serviceId  INT,
	@instanceId INT
)
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
		SELECT 
			InstanceId,
			ServiceId,
			ServiceCatalogId,
			ServiceCatalogItemId as ServiceCatagoryItemId
			FROM [dbo].[tblSnowServices] WITH (NOLOCK)
			WHERE ServiceId = @serviceId AND InstanceId = @instanceId
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('sp_GetServiceNowServicesReference: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END


GO
/****** Object:  StoredProcedure [dbo].[sp_GetUser]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		VTF Team, Vijay Nadar
-- Create date: 20 April 2106
-- Description:	Get user details
-- =============================================

CREATE PROCEDURE [dbo].[sp_GetUser] 
	-- Add the parameters for the stored procedure here
	@userName varchar(100),
	@password varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY
		-- Insert statements for procedure here
		SELECT UserId,UserName,[Password], Name FROM  dbo.[tblUser] where UserName = @userName AND [Password] = @password;
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('sp_GetUser: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[sp_GetUserName]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		VTF Team, Vinit Jaiswal
-- Create date: 11 Aug 2106
-- Description:	Get User Name 
-- =============================================

CREATE PROCEDURE [dbo].[sp_GetUserName] 
	-- Add the parameters for the stored procedure here
	@UserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY
		-- Insert statements for procedure here
		SELECT Name,UserName FROM  dbo.[tblUser] where UserId = @UserID;
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('sp_GetUser: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[sp_GetWorkOrdersbyWONumber]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		VTF Team, Rony Lobo
-- Create date: 18 Aug 2016
-- Description:	Get Work order based on Work Order number
-- =============================================
CREATE  PROCEDURE [dbo].[sp_GetWorkOrdersbyWONumber]( 	
	@WorkOrderNumber varchar(50)
	)
AS
BEGIN
	SET NOCOUNT ON;	
	
		SELECT 
			wo.WorkOrderId,
			wo.WorkOrderNumber,
			wo.WorkOrderReferenceNo,
			wo.EngagementCode,
			wo.Priority,
			wo.StartDate,
			wo.EndDate,
			wo.Status,
			n2k.ProjectName as EngagementName,
			n2k.CustomerName,
			wos.WorkOrderServiceId,
			wos.ServiceId
											
		FROM [dbo].[tblWorkOrder] wo WITH (NOLOCK) 
		INNER JOIN [dbo].[tblN2KData] n2k WITH (NOLOCK) 		
		ON wo.EngagementCode = n2k.ProjectCode
		INNER JOIN [dbo].[tblWorkOrderServices] wos WITH (NOLOCK)
		ON wo.WorkOrderId = wos.WorkOrderId
		WHERE wo.WorkOrderNumber  = @WorkOrderNumber
END





GO
/****** Object:  StoredProcedure [dbo].[sp_ResetWorkOrderReferencIds]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		VTF Team, Rony Lobo
-- Create date: 06 Jun 2016
-- Description:	Reset Work Order NUmber and Other reference Ids if SNOW push fails
-- =============================================
CREATE PROCEDURE [dbo].[sp_ResetWorkOrderReferencIds]( 	
	@WorkOrderId BIGINT	
	)
AS
BEGIN
    SET NOCOUNT ON;	
	BEGIN TRANSACTION trans
		BEGIN TRY	
			--Reset Work Order NUmber and reference Ids	
			UPDATE [dbo].[tblWorkOrder] SET WorkOrderReferenceId =NULL, WorkOrderReferenceNo=NULL,UpdatedBy=0, UpdatedDate = GETDATE() WHERE workOrderId = @WorkOrderId		
			UPDATE [dbo].[tblWorkOrderServices] SET ServiceReferenceId =NULL , serviceReferenceNumber = NULL,UpdatedBy=0, UpdatedDate = GETDATE() WHERE workOrderId = @WorkOrderId
		IF @@TRANCOUNT > 0
			BEGIN 
				COMMIT TRANSACTION trans
			END
		END TRY
		BEGIN CATCH		
			IF @@TRANCOUNT > 0
				BEGIN 
					ROLLBACK TRANSACTION trans
				END
			DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		    SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		    RAISERROR ('sp_ResetWorkOrderReferencIds: %d: %s', @severity, @state, @error, @errmessage)    
		END CATCH 
	SELECT @@ROWCOUNT
END






GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateServiceReferencIds]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		VTF Team, Rony Lobo
-- Create date: 03 Jun 2016
-- Description:	Update work order reference Ids from SNOW to VTF 
-- =============================================
CREATE PROCEDURE [dbo].[sp_UpdateServiceReferencIds]( 	
	@ServiceRequestId VARCHAR(200),
	@ServiceRequestNumber VARCHAR(100),
	@WorkOrderId BIGINT,
	@ServiceId INT	
	)
AS
BEGIN
    SET NOCOUNT ON;	
	BEGIN TRY
		--Update Work Order services reference details from SNOW
		UPDATE [dbo].[tblWorkOrderServices] SET ServiceReferenceId =@ServiceRequestId , serviceReferenceNumber = @ServiceRequestNumber, UpdatedBy=0, UpdatedDate = GETDATE() WHERE WorkOrderId = @WorkOrderId and ServiceId = @serviceId
		SELECT @@ROWCOUNT
	END TRY
	BEGIN CATCH
		DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		RAISERROR ('sp_UpdateServiceReferencIds: %d: %s', @severity, @state, @error, @errmessage)    
	END CATCH
END





GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateWorkOrderReferenceIds]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_UpdateWorkOrderReferenceIds]( 	
	@RequestId VARCHAR(200),
	@RequestNumber VARCHAR(100),
	@WorkOrderId BIGINT	
	)
AS
BEGIN
    SET NOCOUNT ON;	
	BEGIN TRY
		--Update Work Order reference details from SNOW
		UPDATE [dbo].[tblWorkOrder] SET WorkOrderReferenceId =@RequestId, WorkOrderReferenceNo=@RequestNumber,UpdatedBy=0, UpdatedDate = GETDATE() WHERE workOrderId = @WorkOrderId		
		SELECT @@ROWCOUNT
	END TRY
	BEGIN CATCH
		DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		RAISERROR ('sp_UpdateWorkOrderReferenceIds: %d: %s', @severity, @state, @error, @errmessage)    
	END CATCH
END
GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateWorkOrderServiceStatus]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_UpdateWorkOrderServiceStatus]
	-- Add the parameters for the stored procedure here
	@WorkOrderServiceID bigint,
	@Status int,
	@Comments nvarchar(500) = null,
	@Url nvarchar(500) = null,
	@UserID bigint
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY
		DECLARE @Message nvarchar(100);

		-- Insert statements for procedure here
		UPDATE dbo.tblWorkOrderServices
		SET Status = @Status,
		UpdatedBy = @UserID,
		UpdatedDate = getdate(),
		Comments = @Comments,
		Url = @Url
		WHERE WorkOrderServiceId = @WorkOrderServiceID;
	

		SELECT WorkOrderServiceId, [Status],WorkOrderId  FROM dbo.tblWorkOrderServices
		WHERE WorkOrderServiceId = @WorkOrderServiceID;
	 END TRY
	 BEGIN CATCH
		DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		RAISERROR ('sp_UpdateWorkOrderServiceStatus: %d: %s', @severity, @state, @error, @errmessage)    
	END CATCH
END


GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateWorkOrderStatus]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_UpdateWorkOrderStatus]
	-- Add the parameters for the stored procedure here
	@WorkOrderID bigint,
	@Status int,
	@UserID bigint
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY
		DECLARE @Message nvarchar(100);

		-- Insert statements for procedure here
		UPDATE dbo.tblWorkOrder
		SET Status = @Status,
		UpdatedBy = @UserID
		WHERE WorkOrderId = @WorkOrderID;
	

		SELECT WorkOrderId, [Status]  FROM dbo.tblWorkOrder
		WHERE WorkOrderId = @WorkOrderID;
	 END TRY
	 BEGIN CATCH
		DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		RAISERROR ('sp_UpdateWorkOrderStatus: %d: %s', @severity, @state, @error, @errmessage)    
	END CATCH
END


GO
/****** Object:  StoredProcedure [dbo].[spAddN2KHistory]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		VTF Team, Vinit Jaiswal
-- Create date: 
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[spAddN2KHistory] (
	@DirectoryName NVARCHAR(120), 
	@DirectoryPath NVARCHAR(200), 
	@CreatedDateTime DATETIME, 
	@CurrentDateTime DATETIME
	) 
AS

BEGIN
	BEGIN TRY
		INSERT INTO dbo.tblN2KHistory(
			DirectoryName,
			DirectoryPath,
			CreatedDateTime,
			CurrentDateTime)
		VALUES (
			@DirectoryName,
			@DirectoryPath,
			@CreatedDateTime,
			@CurrentDateTime)
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('spAddN2KHistory: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END

GO
/****** Object:  StoredProcedure [dbo].[spGetBUCode]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		VTF Team, Vinit Jaiswal
-- Create date: 
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[spGetBUCode](
	@BUCode NVARCHAR(50)
) 

AS
BEGIN
	BEGIN TRY
		SELECT BUCodeId
		FROM tblBUMaster
		WHERE BUCode = @BUCode
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('spGetBUCode: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END





GO
/****** Object:  StoredProcedure [dbo].[spGetMenu]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		VTF Team, Vinit Jaiswal
-- Create date: 
-- Description:	
-- =============================================

CREATE PROCEDURE [dbo].[spGetMenu] AS

BEGIN
	BEGIN TRY
		SELECT MenuName,
			   Description,
			   cntrMaster.Url,
			   MenuOrder
		FROM dbo.tblMenu menu
		INNER JOIN dbo.tblUrlMaster cntrMaster ON
		menu.UrlID =cntrMaster.UrlID
		Order By MenuOrder ASC
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('spGetMenu: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END

GO
/****** Object:  StoredProcedure [dbo].[spGetN2KDirInfo]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		VTF Team, Vinit Jaiswal
-- Create date: 
-- Description:	
-- =============================================

CREATE PROCEDURE [dbo].[spGetN2KDirInfo] (
	@DirectoryName NVARCHAR(100),
	@DirectoryPath NVARCHAR (200), 
	@CreatedDateTime DATETIME
) 
AS

BEGIN
	BEGIN TRY
		SELECT COUNT(Id)
		FROM tblN2KHistory
		WHERE DirectoryName = @DirectoryName
		  AND DirectoryPath = @DirectoryPath
		  AND CreatedDateTime = @CreatedDateTime
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('spGetN2KDirInfo: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[spGetOrderReferanceStatus]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================================================================
-- Author:	VTF Team, Vinit Jaiswal
-- Create date: 23 Jun 2016
-- Description:	Check the WorkOrderReferenceId exist  for Perticualr Factory ID and update the service now flag status
-- ======================================================================================================================

CREATE PROCEDURE [dbo].[spGetOrderReferanceStatus]
(
 @FactoryID nvarchar(10),
 @WorkOrderRefId nvarchar(50),
 @RecordCount int output
)
AS 
BEGIN
  SET NOCOUNT ON;
  
  select @RecordCount = COUNT(WorkOrderId) from tblWorkOrder
  where WorkOrderReferenceId = @WorkOrderRefId 
  AND FactoryID = @FactoryID
  
  Select @RecordCount
Return 
END 



GO
/****** Object:  StoredProcedure [dbo].[spGetServiceNowInstanceAll]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ==========================================================================================
-- Author:	VTF Team, Vinit Jaiswal
-- Create date: 23 Jun 2016
-- Description:	Select all service now instance 
-- ==========================================================================================

CREATE PROCEDURE [dbo].[spGetServiceNowInstanceAll]
AS
BEGIN
	BEGIN TRY
	  Select Url,Username,[Password],FactoryId from tblSnowInstance
	  Where  Active = 1
	END  TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('spGetServiceNowInstanceAll: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END



GO
/****** Object:  StoredProcedure [dbo].[spN2KData]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ==========================================================================================
-- Author:	VTF Team, Vinit Jaiswal
-- Create date: 
-- Description:	
-- ==========================================================================================

CREATE PROCEDURE [dbo].[spN2KData]
(
	@BUCodeId INT, 
	@UnitCode NVARCHAR(120), 
	@UnitName NVARCHAR(120), 
	@ProjectCode NVARCHAR(120), 
	@ProjectName NVARCHAR(120), 
	@EngagementManager NVARCHAR(120), 
	@AccountExecutive NVARCHAR(120), 
	@AgreementType NVARCHAR(120), 
	@ProjectType NVARCHAR(120), 
	@StartDate DATETIME, 
	@EndDate DATETIME, 
	@TransversalServiceline NVARCHAR(120), 
	@Technology NVARCHAR(120), 
	@DeliveryModel NVARCHAR(120), 
	@EngagementType NVARCHAR(120), 
	@Deliverable NVARCHAR(120), 
	@AgreementStatus NVARCHAR(120), 
	@ProjectStatus NVARCHAR(120),
	@CustomerName NVARCHAR(120),
	@DateStatus INT
)

AS 
BEGIN
	BEGIN TRY
		IF EXISTS
		  (SELECT Id
		   FROM dbo.tblN2KData
		   WHERE [Projectcode]= @ProjectCode AND [BUCodeId] = @BUCodeId) BEGIN
		UPDATE dbo.tblN2KData
		SET [UnitCode] = @Unitcode,
			[UnitName] = @UnitName,
			[ProjectName] = @ProjectName,
			[EngagementManager] =@EngagementManager,
			[AccountExecutive] = @AccountExecutive,
			[AgreementType] = @AgreementType,
			[ProjectType] =@ProjectType,
			[StartDate] =@StartDate,
			[EndDate] =@EndDate,
			[TransversalServiceline] =@TransversalServiceline,
			[Technology] =@Technology,
			[DeliveryModel] =@DeliveryModel,
			[EngagementType] =@EngagementType,
			[Deliverable] =@Deliverable,
			[AgreementStatus]=@AgreementStatus,
			[ProjectStatus] =@ProjectStatus,
			[CustomerName] = @CustomerName,
			[DateStatus] = @DateStatus
		WHERE ProjectCode =@ProjectCode AND BUCodeId=@BUCodeId END ELSE BEGIN
		  INSERT INTO dbo.tblN2KData (BUCodeId,UnitCode,UnitName,ProjectCode,ProjectName,EngagementManager,AccountExecutive,AgreementType,ProjectType,StartDate,EndDate,TransversalServiceline,Technology,DeliveryModel,EngagementType,Deliverable,AgreementStatus,ProjectStatus,CustomerName,DateStatus)
		  VALUES(@BUCodeId,
				 @UnitCode,
				 @UnitName,
				 @ProjectCode,
				 @ProjectName,
				 @EngagementManager,
				 @AccountExecutive,
				 @AgreementType,
				 @ProjectType,
				 @StartDate,
				 @EndDate,
				 @TransversalServiceline,
				 @Technology,
				 @DeliveryModel,
				 @EngagementType,
				 @Deliverable,
				 @AgreementStatus,
				 @ProjectStatus,
				 @CustomerName,
				 @DateStatus) 
		END 
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('spN2KData: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END

GO
/****** Object:  StoredProcedure [dbo].[spN2KLog]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ==========================================================================================
-- Author:	VTF Team, Vinit Jaiswal
-- Create date: 
-- Description:	
-- ==========================================================================================

CREATE PROCEDURE [dbo].[spN2KLog] (
	@BUCode NVARCHAR(50), 
	@FilePath NVARCHAR(150), 
	@FUnitCode NVARCHAR(50), 
	@FProjCode NVARCHAR (50), 
	@Status INT, 
	@Description NVARCHAR(250), 
	@DateTime DATETIME
) 
AS 
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		INSERT INTO tblN2KLog(BUCode, FilePath, FUnitCode,ProjCode, Status, Description, datetime)
		VALUES(@BUCode,
			   @FilePath,
			   @FUnitCode,
			   @FProjCode,
			   @Status,
			   @Description,
			   @DateTime) 
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('spN2KLog: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END







GO
/****** Object:  StoredProcedure [dbo].[spUpdateBUMaster]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ==========================================================================================
-- Author:	VTF Team, Vinit Jaiswal
-- Create date: 
-- Description:	
-- ==========================================================================================

CREATE PROCEDURE [dbo].[spUpdateBUMaster] ( 
@BUCode NVARCHAR(50)
) 
AS 
BEGIN 
	BEGIN TRY
		IF NOT EXISTS(SELECT BUCodeId FROM tblBUMaster WHERE BUCode = @BUCode) 
		BEGIN
			INSERT INTO tblBUMaster(BUCode)	VALUES(@BUCode) 
		END 
	END TRY
	BEGIN CATCH  
		   DECLARE @error INT, @errmessage VARCHAR(4000), @state INT, @severity INT
		   SELECT @error = ERROR_NUMBER(),@errmessage = ERROR_MESSAGE(), @state = ERROR_STATE(), @severity= ERROR_SEVERITY()	
		   RAISERROR ('spUpdateBUMaster: %d: %s', @severity, @state, @error, @errmessage)      	
	END CATCH
END



GO
/****** Object:  StoredProcedure [dbo].[spUpdateStage]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ==========================================================================================
-- Author:	VTF Team, Vinit Jaiswal
-- Create date: 09 Jun 2016
-- Description:	Update status of tblWorkOrder and tblWorkOrderStatus from SNOW to VTF 
-- ==========================================================================================

CREATE PROCEDURE [dbo].[spUpdateStage]  
(  
@RequestSysId NVARCHAR(50),  
@ItemSysId NVARCHAR(50),  
@RequestStage INT ,   
@ItemStage INT,
@ReqFactoryId INT,  
@UpdReqCount INT OUTPUT,  
@UpdItemCount INT OUTPUT   
)  
  
AS BEGIN  
SET NOCOUNT ON;  
DECLARE @ReqCount int, @ItemCount int  
  
SELECT @ReqCount = count(*)  
FROM tblWorkOrder  
WHERE WorkOrderReferenceId = @RequestSysId AND FactoryID = @ReqFactoryId
    
IF(@ReqCount = 1)  
    BEGIN  
       IF NOT EXISTS (Select 1 FROM tblWorkOrder WHERE WorkOrderReferenceId= @RequestSysId 
          AND Status= @RequestStage AND FactoryID = @ReqFactoryId)  
          BEGIN  
              UPDATE tblWorkOrder  
              SET Status = @RequestStage WHERE WorkOrderReferenceId = @RequestSysId AND 
              FactoryID = @ReqFactoryId;  
              SET @UpdReqCount = 1;  
          END  
       ELSE  
         BEGIN  
           SET @UpdReqCount = 0;  
         END  
     END  
ELSE  
    BEGIN  
      SET @UpdReqCount = 0;  
    END  
  
SELECT @ItemCount = count(*)  
FROM tblWorkOrderServices item, tblWorkOrder req 
WHERE ServiceReferenceId= @ItemSysId And req.WorkOrderId = item.WorkOrderId 
And req.FactoryId = @ReqFactoryId  
  
 IF(@ItemCount = 1)  
   BEGIN  
     IF NOT EXISTS (Select 1 From tblWorkOrderServices item,tblWorkOrder req 
        WHERE req.WorkOrderId = item.WorkOrderId AND item.ServiceReferenceId= @ItemSysId 
        AND item.Status= @ItemStage)  
         BEGIN  
              UPDATE tblWorkOrderServices  
              SET Status = @ItemStage WHERE ServiceReferenceId in
              (select item.ServiceReferenceId From tblWorkOrderServices item,tblWorkOrder req 
              WHERE req.WorkOrderId = item.WorkOrderId AND req.FactoryId = @ReqFactoryId AND
              item.ServiceReferenceId = @ItemSysId );  
             SET @UpdItemCount = 1;  
         END  
      ELSE  
         BEGIN  
          SET @UpdItemCount = 0;  
         END  
     END  
 ELSE  
    BEGIN  
      SET @UpdItemCount = 0;  
    END  
      
select @UpdReqCount,@UpdItemCount;  
  
End;   


GO
/****** Object:  StoredProcedure [dbo].[spWorkOrderVsServiceReport]    Script Date: 02-09-2016 15:31:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================  
-- Author:  <Vinit Jaiswal>  
-- Create date: <21-07-2016>  
-- Description: <show number of services created for last one month>  
-- =============================================  


CREATE PROCEDURE [dbo].[spWorkOrderVsServiceReport]
AS
SELECT count(wo.serviceId) ServiceCount ,sm.ServiceName as ServiceName 
FROM tblWorkOrderServices as wo ,tblServiceMaster as sm 
WHERE wo.ServiceId = sm.ServiceId 
GROUP BY wo.serviceId,sm.ServiceName




GO
