EXEC sp_rename 'AddNewProjectDetails',  'ProjectDetails'
EXEC sp_rename 'AddNewProjectTransaction',  'ProjectTechnologies'

EXEC sp_rename 'IAACustomizedCategoryTemplate',  'CustomTemplate'
EXEC sp_rename 'IAACustomizedParameters',  'CustomParameters'
EXEC sp_rename 'IAACustomizedParametersDescription',  'CustomParametersDescription'
EXEC sp_rename 'Master_Designation',  'MasterRoles'
EXEC sp_rename 'Master_ParameterDescription',  'MasterParametersDescription'
EXEC sp_rename 'MasterAssessmentParameters',  'MasterParameters'

EXEC sp_rename 'MasterEmployee',  'Users'
EXEC sp_rename 'MasterEmployeeDesignation',  'UserRoles'

EXEC sp_rename 'MasterTenologies',  'MasterTechnologies'
EXEC sp_rename 'ProjectAssessmentParameters',  'AssessmentParameters'

/****** Object:  Table [dbo].[IAAArchitectureAssignment]    Script Date: 01/15/2016 16:00:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IAAArchitectureAssignment]') AND type in (N'U'))
DROP TABLE [dbo].[IAAArchitectureAssignment]
GO
/****** Object:  Table [dbo].[SonarProjectMap]    Script Date: 01/15/2016 16:00:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SonarProjectMap]') AND type in (N'U'))
DROP TABLE [dbo].[SonarProjectMap]
GO
/****** Object:  Table [dbo].[SonarProjectName]    Script Date: 01/15/2016 16:00:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SonarProjectName]') AND type in (N'U'))
DROP TABLE [dbo].[SonarProjectName]
GO

GO	
ALTER TABLE [ProjectDetails]
  ADD CustomerAssessment bit null,
  CustomerEmailId varchar(50) null
GO

GO
ALTER TABLE [MasterIAALogin]
ALTER COLUMN [ExEmpUserID] VARCHAR(50) NOT NULL
GO

GO
ALTER TABLE [Users]
ALTER COLUMN [LoginID] VARCHAR(50) NOT NULL
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [dbo].[MasterAssessorAction]    Script Date: 10/21/2015 12:39:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MasterAssessorAction]') AND type in (N'U'))
DROP TABLE [dbo].[MasterAssessorAction]
GO

/****** Object:  Table [dbo].[MasterAssessorAction]    Script Date: 10/21/2015 11:54:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[MasterAssessorAction](
	[AssessorActionUID] [uniqueidentifier] NULL,
	[AssessorAction] [varchar](100) NULL,
	[SortOrder] [smallint] NULL,
	[Active] [bit] NULL
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[UserRequestedArchitectParameters]    Script Date: 01/14/2016 15:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserRequestedArchitectParameters](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [uniqueidentifier] NOT NULL,
	[ArchitectId] [uniqueidentifier] NOT NULL,
	[Status] [smallint] NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[ModifiedBy] [uniqueidentifier] NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,
 CONSTRAINT [PK_UserRequestArchitectParameters] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserFeatures]    Script Date: 01/14/2016 15:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[UserFeatures](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[UserId] [varchar](50) NOT NULL,
	[FeatureId] [int] NOT NULL,
 CONSTRAINT [PK_UserFeatures] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[SonarProjectName]    Script Date: 01/14/2016 15:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SonarProjectName](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SonarProjectMapID] [int] NULL,
	[SonarProjectName] [nvarchar](200) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SonarProjectMap]    Script Date: 01/14/2016 15:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SonarProjectMap](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ProjectID] [int] NULL,
	[SonarProjectID] [int] NULL,
	[SonarSnapshotID] [int] NULL,
	[User] [nvarchar](200) NULL,
	[Status] [int] NULL,
	[FolderName] [nvarchar](200) NULL,
	[ExecutionMessage] [nvarchar](1000) NULL,
	[ZipFileName] [nvarchar](200) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MasterFeatures]    Script Date: 01/14/2016 15:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MasterFeatures](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Feature] [varchar](100) NOT NULL,
 CONSTRAINT [PK_MasterFeatures] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ArchitectTechnologies]    Script Date: 01/14/2016 15:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ArchitectTechnologies](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[EmployeeId] [varchar](50) NOT NULL,
	[TechnologyId] [varchar](50) NOT NULL,
 CONSTRAINT [PK_ArchitectTechnology] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[SonarProjectName]    Script Date: 01/15/2016 15:09:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SonarProjectName](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SonarProjectMapID] [int] NULL,
	[SonarProjectName] [nvarchar](200) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SonarProjectMap]    Script Date: 01/15/2016 15:09:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SonarProjectMap](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ProjectID] [int] NULL,
	[SonarProjectID] [int] NULL,
	[SonarSnapshotID] [int] NULL,
	[User] [nvarchar](200) NULL,
	[Status] [int] NULL,
	[FolderName] [nvarchar](200) NULL,
	[ExecutionMessage] [nvarchar](1000) NULL,
	[ZipFileName] [nvarchar](100) NULL
) ON [PRIMARY]
GO