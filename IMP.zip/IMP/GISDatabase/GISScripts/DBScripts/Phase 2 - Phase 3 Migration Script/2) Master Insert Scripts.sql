
/****** Object:  Table [dbo].[MasterFeatures]    Script Date: 01/13/2016 19:02:10 ******/
SET IDENTITY_INSERT [dbo].[MasterFeatures] ON
INSERT [dbo].[MasterFeatures] ([Id], [Feature]) VALUES (1, N'Add Project')
INSERT [dbo].[MasterFeatures] ([Id], [Feature]) VALUES (2, N'Upload Project')
INSERT [dbo].[MasterFeatures] ([Id], [Feature]) VALUES (3, N'Architecture Custom Parameters')
SET IDENTITY_INSERT [dbo].[MasterFeatures] OFF

SET ANSI_PADDING OFF
GO

GO
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('473F5E92-871F-494B-A6C9-5D9C0F5C3B04','Start Self Assessment','1','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('CC2E2C60-97C3-410E-B8A5-C5FCFEF49601','Resume Self Assessment','2','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('571EB9BD-CBE0-43FA-ACAA-34A7CD7DCC02','View Self Assessment','3','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('57E35544-C987-41A7-B00A-E1A281B7A5A0','View Self-Custom Report','4','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('9128D113-A094-4658-A29D-A1F8F0C6F738','Request for Architect Assessment','5','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('B7340606-AD46-424E-A48F-F397C772C852','Start Architect Assessment','6','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('BD039122-B3C3-4246-9136-AD05B88232C9','Resume Architect Assessment','7','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('1D085D93-EC76-4AAB-848E-19242923D03A','View Architect''s Assessment','8','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('895F6535-F0B5-410D-B010-ED7EC62D313C','View Architect''s Custom Report','9','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('0AA9CB4E-FDA0-4957-B3F6-2DDE51DCD0C2','Request for Customer Assessment','10','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('B9DD4FFD-944B-4CD9-B0BB-F5D5ABB35AD9','Resume Customer Assessment','11','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('5A18D5D1-1C6A-4CA8-9342-8D877B78F2F2','View Customer''s Assessment','12','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('58A5F9BB-65AE-4934-A69D-0DB03DCC733B','View Customer''s Custom Report','13','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('DF69FD10-BB1A-4FAF-AC74-BFDE4BEEDB80','Approve','14','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('19DE812C-7AA2-456C-A9CC-E1515AB5E112','Deny','15','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('2FF28E9D-C025-47E8-B7DC-98F3AE75FB16','View Reason','16','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('2397D04E-4795-46E7-92A3-658220448FFB','Allocate/De-allocate','17','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('A5A4D252-17C8-4C4A-BBE8-1ACC3282A717','Upload Source Code','18','1');
INSERT INTO [MasterAssessorAction] (AssessorActionUID,AssessorAction,SortOrder,Active) VALUES ('BC9C7E5C-AFAB-44FA-B76B-E12EBC63951B','View Analyzer Report','19','1');
GO

TRUNCATE TABLE [MasterMainMenu]

/****** Object:  Table [dbo].[MasterMainMenu]    Script Date: 01/13/2016 19:02:10 ******/
INSERT [dbo].[MasterMainMenu] ([MainMenuID], [MainMenuDescription], [MainMenuURL], [ParentID]) VALUES (6, N'Authorize External User', N'~/AuthorizeExternalUser.aspx', 4)
INSERT [dbo].[MasterMainMenu] ([MainMenuID], [MainMenuDescription], [MainMenuURL], [ParentID]) VALUES (2, N'Customized Parameters', N'~/CustomizedParameters.aspx', 0)
INSERT [dbo].[MasterMainMenu] ([MainMenuID], [MainMenuDescription], [MainMenuURL], [ParentID]) VALUES (1, N'Architecture Assessor', N'~/ArchitectureAssessor.aspx', 0)
INSERT [dbo].[MasterMainMenu] ([MainMenuID], [MainMenuDescription], [MainMenuURL], [ParentID]) VALUES (3, N'View Project', N'~/ViewProjectDetails.aspx', 0)
INSERT [dbo].[MasterMainMenu] ([MainMenuID], [MainMenuDescription], [MainMenuURL], [ParentID]) VALUES (4, N'Admin', N'', 0)
INSERT [dbo].[MasterMainMenu] ([MainMenuID], [MainMenuDescription], [MainMenuURL], [ParentID]) VALUES (5, N'Approve AA Request', N'~/ApproveAARequest.aspx', 4)
INSERT [dbo].[MasterMainMenu] ([MainMenuID], [MainMenuDescription], [MainMenuURL], [ParentID]) VALUES (7, N'User Management', N'~/UserManagement.aspx', 4)
