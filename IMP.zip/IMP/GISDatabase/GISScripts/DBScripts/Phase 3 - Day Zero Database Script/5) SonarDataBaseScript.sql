USE [master]
GO

/****** Object:  Database [sonar]    Script Date: 01/15/2016 11:07:09 ******/
IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'sonar')
DROP DATABASE [sonar]
GO

USE [master]
GO

CREATE DATABASE [sonar]
 COLLATE SQL_Latin1_General_CP1_CS_AS
GO