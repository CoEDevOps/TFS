DECLARE @Employeeid varchar(100)

SET @Employeeid = NEWID()

INSERT INTO [Users]
           ([EmployeeGUID]
           ,[LoginID]
           ,[EmployeeID]
           ,[EmpLastName]
           ,[EmpFirstName]
           ,[EmpBU]
           ,[Title]
           ,[EmailID]
           ,[Designation]
           ,[Tecnologies]
           ,[ReportingTo]
           ,[Gender]
           ,[DBO]
           ,[Domain]
           ,[Address]
           ,[City]
           ,[CreatedDate])
     VALUES
           (@Employeeid
           ,'admin'
           ,'External User'
           ,'Administrator'
           ,' '
           ,NULL
           ,NULL
           ,NULL
           ,NULL
           ,NULL
           ,NULL
           ,NULL
           ,NULL
           ,NULL
           ,NULL
           ,NULL
           ,GETDATE())



INSERT INTO [UserRoles]
           ([DesignationUID]
           ,[EmployeeUID]
           ,[DesignationID]
           ,[Active])
     VALUES
           (NEWID()
           ,@Employeeid
           ,'02B9C667-A974-40E5-A9AB-EF72B3681882'
           ,1)
           
INSERT INTO [MasterIAALogin]
           ([ExEmpGuid]
           ,[ExEmpUserID]
           ,[ExEmpPassword]
           ,[Active]
           ,[CreatedDate]
           ,[CreatedBy])
     VALUES
           (@Employeeid
           ,'admin'
           ,'admin'
           ,1
           ,GETDATE()
           ,@Employeeid)
GO