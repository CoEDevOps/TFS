﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq.Expressions;

namespace Capgemini.GroupProduction.VTF.Grid
{
    /// <summary>
    /// Grid column collection. 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class GridCollection<T> : KeyedCollection<string, IGridColumn<T>>, IEnumerable<IGridColumn<T>>  where T :class
    {
        private List<IGridColumn<T>> m_gridCollection;

        public GridCollection()
        {           
            m_gridCollection = new List<IGridColumn<T>>();
        }

        /// <summary>
        /// Add grid columns in the collection.
        /// </summary>
        /// <typeparam name="TKey">Return type of the expression.</typeparam>
        /// <param name="constraint">Expression to be executed for each grid column.</param>
        /// <returns>Return the grid column of type.</returns>
        public IGridColumn<T> Add<TKey>(Expression<Func<T, TKey>> constraint)
        {
            var gridColumn = new GridColumn<T, TKey>(constraint);           

            m_gridCollection.Add(gridColumn);

            return gridColumn;
        }

        /// <summary>
        /// Add grid columns in the collection.
        /// </summary>
        /// <returns></returns>
        public IGridColumn<T> Add()
        {
            var gridColumn = new GridColumn<T, string>(null);

            m_gridCollection.Add(gridColumn);

            return gridColumn;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        protected override string GetKeyForItem(IGridColumn<T> item)
        {
            return item.ToString();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<IGridColumn<T>> GridColumns()
        {
            return m_gridCollection;
        }
       
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return m_gridCollection.GetEnumerator();
        }
    }
}
