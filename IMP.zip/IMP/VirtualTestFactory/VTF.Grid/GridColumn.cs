﻿using System;
using System.Linq.Expressions;
using System.Web.Mvc;

namespace Capgemini.GroupProduction.VTF.Grid
{
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <typeparam name="TDataType"></typeparam>
    public class GridColumn<T, TDataType> : IGridColumn<T>, IGridColumn where T : class
    {
        private Func<T,int, string> ValueConstraint;
        /// <summary>
        ///     Expression to member, used for this column
        /// </summary>
        private readonly Func<T, TDataType> m_constraint;        
        private int m_Width;
        private string m_Title;      
        private bool m_EncodeEnabled;
        private string m_Css;      

        public GridColumn(Expression<Func<T, TDataType>> expression)
        {
            
            #region Setup defaults

            m_EncodeEnabled = true;           

           
            #endregion

            if (expression != null)
            {
                var expr = expression.Body as MemberExpression;
                if (expr == null)
                    throw new ArgumentException(
                        string.Format("Expression '{0}' must be a member expression", expression),
                        "expression");

                m_constraint = expression.Compile();
                
                //Generate unique column name:
               // m_Name = PropertiesHelper.BuildColumnNameFromMemberExpression(expr);
               // Title = Name; //Using the same name by default
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="title"></param>
        /// <returns></returns>
        public IGridColumn<T> Titled(string title)
        {
            m_Title = title;
            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="encode"></param>
        /// <returns></returns>
        public IGridColumn<T> Encoded(bool encode)
        {
            m_EncodeEnabled = encode;
            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="width"></param>
        /// <returns></returns>
        public IGridColumn<T> SetWidth(int width)
        {
            m_Width = width;
            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="constraint"></param>
        /// <returns></returns>
        public IGridColumn<T> RenderValueAs(Func<T, int, string> constraint)
        {
            ValueConstraint = constraint;
            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cssClasses"></param>
        /// <returns></returns>
        public IGridColumn<T> Css(string cssClasses)
        {
            if (string.IsNullOrEmpty(cssClasses))
                return this;
            m_Css = cssClasses;

            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="instance"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        private string GetValue(T instance, int index)
        {

            string textValue = string.Empty;

             if (ValueConstraint != null)
             {
                 return ValueConstraint(instance, index);
             }
             
            TDataType value = default(TDataType);

            if (m_constraint == null)
            {
                throw new InvalidOperationException("You need to specify render expression using RenderValueAs");
            }                 

            if(value == null)
            {
                return string.Empty;
            }
            return value.ToString();
             

             
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="instance"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public MvcHtmlString RenderCell(object instance, int index)
        {
            T objType = instance as T;
            return RenderCell(objType, index);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="instance"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public MvcHtmlString RenderCell(T instance, int index)
        {
            string cssStyles = string.Empty;
            string cssClass = m_Css;

            var builder = new TagBuilder("td");
            if (!string.IsNullOrWhiteSpace(cssClass))
                builder.AddCssClass(cssClass);
            if (!string.IsNullOrWhiteSpace(cssStyles))
                builder.MergeAttribute("style", cssStyles);
           // builder.MergeAttribute("data-name", m_Name);

            builder.InnerHtml = GetValue(instance, index).ToString();

            return MvcHtmlString.Create(builder.ToString());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public MvcHtmlString RenderHeader()
        {
            string cssStyles = string.Empty;            

            if (m_Width > 0)
                cssStyles = string.Concat(cssStyles, " width:", m_Width, ";").Trim();

            var builder = new TagBuilder("th");
           
            if (!string.IsNullOrWhiteSpace(m_Title))
                builder.InnerHtml = m_Title;
            //else
               // builder.InnerHtml = m_Name;
            

            return MvcHtmlString.Create(builder.ToString());
        }


      
    }
}
