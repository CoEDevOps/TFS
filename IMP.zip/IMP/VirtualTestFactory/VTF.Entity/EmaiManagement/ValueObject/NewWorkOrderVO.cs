﻿using Capgemini.GroupProduction.VTF.Common;
using System;
using System.ComponentModel.DataAnnotations;

namespace Capgemini.GroupProduction.VTF.ValueObject
{
    /// <summary>
    /// New Work Order
    /// </summary>
    public class NewWorkOrderVO
    {
        /// <summary>
        /// Work Order Number
        /// </summary>
        public Int64 WorkOrderId { get; set; }

        /// <summary>
        /// Work Order Number
        /// </summary>
        public string WorkOrderNumber { get; set; }

        /// <summary>
        /// Engagement Code
        /// </summary>
        public string EngagementCode { get; set; }

        /// <summary>
        /// Engagement Name
        /// </summary>
        public string EngagementName { get; set; }

        /// <summary>
        /// Project Manager
        /// </summary>
        public string ProjectManager { get; set; }

        /// <summary>
        /// Customer Name
        /// </summary>
        public string CustomerName { get; set; }


        public string FactoryManagerEmailIDs { get; set; }

        /// <summary>
        /// Priority
        /// </summary>
        public int? Priority
        {
            get
            {
                return (int)this.PriorityType;
            }
            set
            {
                PriorityType = (WorkorderPriority)value;
            }
        }
        [EnumDataType(typeof(WorkorderPriority))]
        public WorkorderPriority PriorityType { get; set; }

        /// <summary>
        /// Expected Start Date
        /// </summary>        
        public Nullable<DateTime> StartDate { get; set; }

        /// <summary>
        /// Expected End Date
        /// </summary>        
        public Nullable<DateTime> EndDate { get; set; }

        /// <summary>
        /// Services (Service Names in CSV format)
        /// </summary>
        public string Services { get; set; }

        /// <summary>
        ///  (Work Order Reference Number SNOW)
        /// </summary>
        public string WorkOrderReferenceNo { get; set; }

        /// <summary>
        /// User Name
        /// </summary>
        public string User { get; set; }

        /// <summary>
        /// Factory Id
        /// </summary>
        public int FactoryId { get; set; }

        /// <summary>
        /// Error Message
        /// </summary>
        public string Message { get; set; }
    }
}
