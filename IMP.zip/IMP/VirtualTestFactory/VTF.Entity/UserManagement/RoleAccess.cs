﻿
namespace Capgemini.GroupProduction.VTF.Entity
{   
    /// <summary>
    ///  RoleAccess
    /// </summary>
    public class RoleAccess
    {
        /// <summary>
        /// User ID. 
        /// </summary>
        public int ControllerActionID { get; set; }

        /// <summary>
        /// User name.
        /// </summary>
        public string ControllerName { get; set; }

        /// <summary>
        /// User name.
        /// </summary>
        public string ActionName { get; set; }


        /// <summary>
        /// User name.
        /// </summary>
        public string RoleIds { get; set; }
    }
}
