﻿using Newtonsoft.Json;

namespace Capgemini.GroupProduction.VTF.ServiceNow.Entity
{
    /// <summary>
    /// Service Request Item
    /// </summary>
    public class ServiceRequestItem
    {
        /// <summary>
        /// Catalog Link::Value
        /// </summary>
        [JsonProperty(PropertyName = "sc_catalog")]
        public string CatalogId { get; set; }

        /// <summary>
        /// Start Date
        /// </summary>
        [JsonProperty(PropertyName = "expected_start")]
        public string StartDate { get; set; }        

        /// <summary>
        /// Impact
        /// </summary>
        [JsonProperty(PropertyName = "impact")]
        public string Impact { get; set; }

        /// <summary>
        /// Urgency
        /// </summary>
        [JsonProperty(PropertyName = "urgency")]
        public string Urgency { get; set; }

        /// <summary>
        /// Description
        /// </summary>
        [JsonProperty(PropertyName = "description")]
        public string Description { get; set; }

        /// <summary>
        /// Priority
        /// </summary>
        [JsonProperty(PropertyName = "priority")]
        public string Priority { get; set; }

        /// <summary>
        /// Service Request , Link :: Value
        /// </summary>
        [JsonProperty(PropertyName = "request")]
        public string ServiceRequestId { get; set; }

        /// <summary>
        /// Quantity
        /// </summary>
        [JsonProperty(PropertyName = "quantity")]
        public string Quantity { get; set; }

        /// <summary>
        /// work notes
        /// </summary>
        [JsonProperty(PropertyName = "work_notes_list")]
        public string FileList { get; set; }

        /// <summary>
        /// estimated delivery
        /// </summary>
        [JsonProperty(PropertyName = "estimated_delivery")]
        public string EndDate { get; set; }

        /// <summary>
        /// number
        /// </summary>
        [JsonProperty(PropertyName = "number")]
        public string RequestItemNumber { get; set; }

        /// <summary>
        /// Category Item, Link :: Value
        /// </summary>
        [JsonProperty(PropertyName = "cat_item")]
        public string CategoryItemId { get; set; }

        /// <summary>
        /// price
        /// </summary>
        [JsonProperty(PropertyName = "price")]
        public string Price { get; set; }

        /// <summary>
        /// active
        /// </summary>
        [JsonProperty(PropertyName = "active")]
        public string Active { get; set; }

        /// <summary>
        /// due date
        /// </summary>
        [JsonProperty(PropertyName = "due_date")]
        public string DueDate { get; set; }

        /// <summary>
        /// state
        /// </summary>
        [JsonProperty(PropertyName = "state")]
        public string State { get; set; }

        /// <summary>
        /// stage
        /// </summary>
        [JsonProperty(PropertyName = "stage")]
        public string Stage { get; set; }

        /// <summary>
        /// sys_id
        /// </summary>
        [JsonProperty(PropertyName = "sys_id")]
        public string ServiceRequestItemId { get; set; }

        /// <summary>
        /// comments
        /// </summary>
        [JsonProperty(PropertyName = "comments")]
        public string Comments { get; set; }
    }
}
