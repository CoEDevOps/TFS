﻿using Capgemini.GroupProduction.VTF.ServiceNow.Entity;
using Newtonsoft.Json;

namespace Capgemini.GroupProduction.VTF.ServiceNow.ValueObject
{
    public class FileUploadVO
    {
        [JsonProperty(PropertyName = "result")]
        public FileUpload SnowFile { get; set; }
    }
}
