﻿using System.Collections.Generic;
using Capgemini.GroupProduction.VTF.ServiceNow.Entity;
using Newtonsoft.Json;

namespace Capgemini.GroupProduction.VTF.ServiceNow.ValueObject
{
    /// <summary>
    /// Category Get 
    /// </summary>
    public class CategoryItemVO
    {
        /// <summary>
        /// Category List
        /// </summary>
        [JsonProperty(PropertyName = "result")]
        public List<CategoryItem> CategoryItemList { get; set; }
    }
}
