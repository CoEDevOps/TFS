﻿using Capgemini.GroupProduction.VTF.ServiceNow.Entity;
using Newtonsoft.Json;

namespace Capgemini.GroupProduction.VTF.ServiceNow.ValueObject
{
    /// <summary>
    /// New Service Request
    /// </summary>
    public class ServiceRequestVO
    {
        /// <summary>
        /// New Service Request
        /// </summary>
        [JsonProperty(PropertyName = "result")]
        public ServiceRequest serviceRequest { get; set; }
    }
}
