﻿using Newtonsoft.Json;

namespace Capgemini.GroupProduction.VTF.ServiceNow.Entity
{
    /// <summary>
    /// Category
    /// </summary>
    public class Category
    {
        /// <summary>
        /// Catalog
        /// </summary>
        [JsonProperty(PropertyName = "sc_catalog")]
        public object CatalogId { get; set; }

        /// <summary>
        /// Title
        /// </summary>
        [JsonProperty(PropertyName = "title")]
        public string CategoryTitle { get; set; }

        /// <summary>
        /// Description
        /// </summary>
        [JsonProperty(PropertyName = "description")]
        public string CategoryDescription { get; set; }

        /// <summary>
        /// Name
        /// </summary>
        [JsonProperty(PropertyName = "sys_name")]
        public string CategoryName { get; set; }

        /// <summary>
        /// Id Pk
        /// </summary>
        [JsonProperty(PropertyName = "sys_id")]
        public string CategoryId { get; set; }

        /// <summary>
        /// Active
        /// </summary>
        [JsonProperty(PropertyName = "active")]
        public string Active { get; set; }
    }
}
