﻿
namespace Capgemini.GroupProduction.VTF.ServiceNow.Entity
{
    /// <summary>
    /// Key Value Pair
    /// </summary>
    public class KeyVal
    {
        /// <summary>
        /// link
        /// </summary>
        public string link { get; set; }

        /// <summary>
        /// value
        /// </summary>
        public string value { get; set; }
    }
}
