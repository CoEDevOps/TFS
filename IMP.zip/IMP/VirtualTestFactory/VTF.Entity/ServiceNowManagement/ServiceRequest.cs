﻿using Newtonsoft.Json;

namespace Capgemini.GroupProduction.VTF.ServiceNow.Entity
{
    /// <summary>
    /// Service Request Class
    /// </summary>
    public class ServiceRequest
    {
        /// <summary>
        /// Impact
        /// </summary>
        [JsonProperty(PropertyName = "impact")]
        public string Impact { get; set; }

        /// <summary>
        /// Urgency
        /// </summary>
        [JsonProperty(PropertyName = "urgency")]
        public string Urgency { get; set; }

        /// <summary>
        /// description
        /// </summary>
        [JsonProperty(PropertyName = "description")]
        public string Description { get; set; }

        /// <summary>
        /// priority
        /// </summary>
        [JsonProperty(PropertyName = "priority")]
        public string Priority { get; set; }

        /// <summary>
        /// work notes
        /// </summary>
        [JsonProperty(PropertyName = "work_notes_list")]
        public string FileList { get; set; }

        /// <summary>
        /// number
        /// </summary>
        [JsonProperty(PropertyName = "number")]
        public string RequestNumber { get; set; }

        /// <summary>
        /// price
        /// </summary>        
        [JsonProperty(PropertyName = "price")]
        public string Price { get; set; }

        /// <summary>
        /// due date
        /// </summary>
        [JsonProperty(PropertyName = "due_date")]
        public string EndDate { get; set; }

        /// <summary>
        /// expected start
        /// </summary>
        [JsonProperty(PropertyName = "expected_start")]
        public string StartDate { get; set; }

        /// <summary>
        /// active
        /// </summary>
        [JsonProperty(PropertyName = "active")]
        public string Active { get; set; }

        /// <summary>
        /// state
        /// </summary>
        [JsonProperty(PropertyName = "state")]
        public string State { get; set; }

        /// <summary>
        /// stage
        /// </summary>
        [JsonProperty(PropertyName = "stage")]
        public string Stage { get; set; }

        /// <summary>
        /// short description
        /// </summary>
        [JsonProperty(PropertyName = "short_description")]
        public string ShortDescription { get; set; }

        /// <summary>
        /// id Pk
        /// </summary>
        [JsonProperty(PropertyName = "sys_id")]
        public string RequestId { get; set; } 
       
        /// <summary>
        /// Requested for
        /// </summary>
        [JsonProperty(PropertyName = "requested_for")]
        public KeyVal CreatedBy { get; set; }

        /// <summary>
        /// Engagement Code
        /// </summary>
        [JsonProperty(PropertyName = "u_engagementcode")]
        public string EngagementCode { get; set; }

        /// <summary>
        /// Engagement name
        /// </summary>
        [JsonProperty(PropertyName = "u_engagementname")]
        public string EngagementName { get; set; }

        /// <summary>
        /// customer name
        /// </summary>
        [JsonProperty(PropertyName = "u_customername")]
        public string CustomerName { get; set; }

        /// <summary>
        /// work order
        /// </summary>
        [JsonProperty(PropertyName = "u_workorder")]
        public string WorkOrderNumber { get; set; }

        /// <summary>
        /// project manager
        /// </summary>
        [JsonProperty(PropertyName = "u_projectmanager")]
        public string ProjectManager { get; set; }

    }
}
