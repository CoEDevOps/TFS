﻿using Newtonsoft.Json;

namespace Capgemini.GroupProduction.VTF.ServiceNow.Entity
{
    //Service Now Catalog
    public class Catalog
    {
        /// <summary>
        /// Name
        /// </summary>
        [JsonProperty(PropertyName = "sys_name")]
        public string CatalogName { get; set; }

        /// <summary>
        /// ID Pk
        /// </summary>
        [JsonProperty(PropertyName = "sys_id")]
        public string CatalogId { get; set; }

        /// <summary>
        /// Title
        /// </summary>
        [JsonProperty(PropertyName = "title")]
        public string CatlogTitle { get; set; }

        /// <summary>
        /// Description
        /// </summary>
        [JsonProperty(PropertyName = "description")]
        public string CatalogDescription { get; set; }

        /// <summary>
        /// Active
        /// </summary>
        [JsonProperty(PropertyName = "active")]
        public string Active { get; set; }
    }
}
