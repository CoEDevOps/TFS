﻿
namespace Capgemini.GroupProduction.VTF.Entity
{
    /// <summary>
    /// Custom messages to be displayed.
    /// </summary>
    public class CustomMessage
    {
        public int MessageType { get; set; }
        /// <summary>
        /// Message to display the user .
        /// </summary>
        public string MessageKey { get; set; }

        public string Message { get; set; }
    }
}
