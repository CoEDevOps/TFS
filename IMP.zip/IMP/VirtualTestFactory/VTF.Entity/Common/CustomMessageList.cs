﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;

namespace Capgemini.GroupProduction.VTF.Entity
{
    public class CustomMessageList 
    {
        public List<CustomMessage> m_lstMessage;

        public CustomMessageList(List<CustomMessage> lstMessages)
        {
            m_lstMessage = lstMessages;
        }

        public override string ToString()
        {
            var serializer = new JavaScriptSerializer();
            string outputOfMesssages = serializer.Serialize(m_lstMessage);

            return outputOfMesssages;
        }
        
    }
}
