﻿using System.ComponentModel.DataAnnotations;

namespace Capgemini.GroupProduction.VTF.ValueObject
{
    /// <summary>
    /// Engagement Code Search details
    /// </summary>
    public class EngagementCodeVO
    {
        /// <summary>
        /// Engagement Code
        /// </summary>
        public string EngagementCode { get; set; }

        /// <summary>
        /// Engagement Name
        /// </summary>
        public string EngagementName { get; set; }
    }
}
