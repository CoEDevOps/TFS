﻿using Capgemini.GroupProduction.VTF.Common;
using System;
using System.ComponentModel.DataAnnotations;

namespace Capgemini.GroupProduction.VTF.ValueObject
{
    /// <summary>
    /// Work Order Details
    /// </summary>
    public class WorkOrderDetailsVO
    {
        /// <summary>
        /// Work Order Id
        /// </summary>
        public Int64? WorkOrderId { get; set; }

        /// <summary>
        /// Work Order Number
        /// </summary>
        public string WorkOrderNumber { get; set; }

        /// <summary>
        /// Engagement Code
        /// </summary>
        public string EngagementCode { get; set; }

        /// <summary>
        /// Engagement Name
        /// </summary>
        public string EngagementName { get; set; }

        /// <summary>
        /// Project Manager
        /// </summary>
        public string ProjectManager { get; set; }

        /// <summary>
        /// Customer Name
        /// </summary>
        public string CustomerName { get; set; }

        public bool IsServiceInstanceAvailable { get; set; }

        public int Status { get; set; }

        /// <summary>
        /// Priority
        /// </summary>
        public int? Priority
        {
            get
            {
                return (int)this.PriorityType;
            }
            set
            {
                PriorityType = (WorkorderPriority)value;
            }
        }
        [EnumDataType(typeof(WorkorderPriority))]
        public WorkorderPriority PriorityType { get; set; }

        /// <summary>
        /// Expected Start Date
        /// </summary>
        [DataType(DataType.Date), DisplayFormat( DataFormatString="{0:dd/MM/yyyy}")]
        public Nullable<DateTime> StartDate { get; set; }

        /// <summary>
        /// Expected End Date
        /// </summary>
        [DataType(DataType.Date), DisplayFormat( DataFormatString="{0:dd/MM/yyyy}")]
        public Nullable<DateTime> EndDate { get; set; }

        public string Message { get; set; }

        public Int64 UserID { get; set; }
    }
}
