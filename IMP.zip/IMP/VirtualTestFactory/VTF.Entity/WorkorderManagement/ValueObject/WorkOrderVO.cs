﻿using System.Collections.Generic;

namespace Capgemini.GroupProduction.VTF.ValueObject
{
    /// <summary>
    /// WorkOrderVO
    /// </summary>
    public class WorkOrderVO
    {
        public WorkOrderDetailsVO WorkOrder { get; set; }

        public List<WorkOrderServiceVO> WorkOrderService { get; set; }
       
    }
}
