﻿using Capgemini.GroupProduction.VTF.Entity;
using System;

namespace Capgemini.GroupProduction.VTF.ValueObject
{
    /// <summary>
    /// Work Order Services
    /// </summary>
    /// 
    public class WorkOrderServiceVO
    {

        /// <summary>
        /// Service Id
        /// </summary>
        ///          
        public long WorkOrderID { get; set; }

        public long WorkOrderServiceId { get; set; }

        /// <summary>
        /// Service Id
        /// </summary>
        /// 
        ///          
        public int ServiceId { get; set; }

        public string ServiceReferenceNumber { get; set; }

        /// <summary>
        /// Service Name
        /// </summary>
        ///         
        public string ServiceName { get; set; }

        /// <summary>
        /// Service Short Description
        /// </summary>
        ///         
        public Nullable<DateTime> StartDate { get; set; }

        /// <summary>
        /// Service Long Decsription
        /// </summary>
        ///       
        public Nullable<DateTime> EndDate { get; set; }

        /// <summary>
        /// Service Long Decsription
        /// </summary>
        ///        
        public string FileName { get; set; }
        public string DisplayFileName { get; set; }
        
        public Int64 UserID { get; set; }

        public int Status { get; set; }

        public CustomMessage Message { get; set; }
    }
}
