﻿
namespace Capgemini.GroupProduction.VTF.ValueObject
{
    /// <summary>
    /// Service Master Details
    /// </summary>
    public class ServiceMasterVO
    {
        /// <summary>
        /// Service Id
        /// </summary>
        public int ServiceId { get; set; }

        /// <summary>
        /// Service Name
        /// </summary>
        public string ServiceName { get; set; }

        /// <summary>
        /// Service Short Description
        /// </summary>
        public string ShortDescription { get; set; }

        /// <summary>
        /// Service Long Decsription
        /// </summary>
        public string LongDescription { get; set; }
        
    }
}
