﻿using Capgemini.GroupProduction.VTF.Common;
using Capgemini.GroupProduction.VTF.ValueObject;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Capgemini.GroupProduction.VTF.Entity
{
    /// <summary>
    /// Work Order Entity
    /// </summary>
    public class WorkOrder
    {
        /// <summary>
        /// Work Order Is
        /// </summary>
        public Int64? WorkOrderId { get; set; }

        /// <summary>
        /// Work Order Number - User Friendly Number
        /// </summary>
        public string WorkOrderNumber { get; set; }

        /// <summary>
        /// Work Order Reference Number - Service Now
        /// </summary>
        public string WorkOrderReferenceNo { get; set; }

        /// <summary>
        /// Engagement Code (Project Code)
        /// </summary>
        public string EngagementCode { get; set; }

        /// <summary>
        /// Engagement Name
        /// </summary>
        public string EngagementName { get; set; }

        /// <summary>
        /// Project Manager
        /// </summary>
        public string ProjectManager { get; set; }

        /// <summary>
        /// Customer Name
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// Priority
        /// </summary>
        public int? Priority
        {
            get
            {
                return (int)this.PriorityType;
            }
            set
            {
                PriorityType = (WorkorderPriority)value;
            }
        }

        [EnumDataType(typeof(WorkorderPriority))]
        public WorkorderPriority PriorityType { get; set; }

        /// <summary>
        /// Start Date
        /// </summary>
        /// 
        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End Date
        /// </summary>
        /// 
        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// End Date
        /// </summary>
        public int Status
        {
            get
            {
                return (int)this.StatusType;
            }
            set
            {
                StatusType = (WorkorderStatus)value;
            }
        }
        [EnumDataType(typeof(WorkorderStatus))]
        public WorkorderStatus StatusType { get; set; }

        /// <summary>
        /// Created By / Updated By
        /// </summary>
        public Int64? UserId { get; set; }
       

        /// <summary>
        /// Error Message
        /// </summary>
        public CustomMessageList CustomMessageList { get; set; }

        /// <summary>
        /// Work Order Service List
        /// </summary>
        public List<ServiceMasterVO> ServiceList { get; set; }

    }
}
