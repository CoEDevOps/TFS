﻿using System.Collections.Generic;
using Capgemini.GroupProduction.VTF.ValueObject;

namespace Capgemini.GroupProduction.VTF.Entity
{
    public class WorkOrderServiceDetails
    {
        public WorkOrderDetailsVO WorkOrder { get; set; }

        public List<WorkOrderService> WorkOrderService { get; set; }

        public string Message { get; set; }

        public int Transaction { get; set; }

        public CustomMessageList CustomMessageList { get; set; }
    }
}
