﻿using System.Configuration;

namespace Capgemini.GroupProduction.VTF.Common
{
    /// <summary>
    /// System coniguration
    /// </summary>
    public class SysAppConfig
    {
        private string m_VTFConn;
        private string m_SQlSessionConn;
        private string m_JSVersion;

        private static SysAppConfig m_SystemAppConfig;

        private SysAppConfig()
        {
            this.m_VTFConn = ConfigurationManager.ConnectionStrings["VTFEntities"].ConnectionString;
            this.m_SQlSessionConn = ConfigurationManager.ConnectionStrings["SessionEntities"].ConnectionString;
            this.m_JSVersion = ConfigurationManager.AppSettings["JSVersion"] != null ? ConfigurationManager.AppSettings["JSVersion"].ToString() 
                : string.Empty;
        }

        /// <summary>
        /// Singleton instance of the class.
        /// </summary>
        /// <returns></returns>
        public static SysAppConfig GetInstance()
        {
            if (m_SystemAppConfig == null)
            {
                m_SystemAppConfig = new SysAppConfig();
            }

            return m_SystemAppConfig;
        }

        /// <summary>
        /// VTF connection string.
        /// </summary>
        public string VTFConn
        {
            get
            {
                return m_VTFConn;
            }
        }

        /// <summary>
        /// SQL session conection
        /// </summary>
        public string SQlSessionConn
        {
            get
            {
                return m_SQlSessionConn;
            }
        }

        /// <summary>
        /// SQL session conection
        /// </summary>
        public string JSVersion
        {
            get
            {
                return m_JSVersion;
            }
        }
       
    }
}
