﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;

namespace Capgemini.GroupProduction.VTF.Common
{
    /// <summary>
    /// Send email utility
    /// </summary>
    public class Email
    {
        /// <summary>
        /// Send email to recipient.
        /// </summary>
        /// <param name="To">Email ID to sent.</param>
        /// <param name="Subject">Email subject.</param>
        /// <param name="TemplatePath">Templath path.</param>
        /// <param name="MatchArr">Match the array string.</param>
        /// <returns></returns>
        public bool SendMail(string To, string Subject, string TemplatePath, string[] MatchArr)
        {
            //Match String Variable with Array Variable
            string TemplateTextString = File.ReadAllText(TemplatePath);
            int VarCount = countTrue(TemplateTextString);
            if (MatchArr.Length != VarCount)
                return false;
            //Read HTML string line by line and replace the template variable with user string
            StringBuilder sb = new StringBuilder();
            string[] TemplateArr = File.ReadAllLines(TemplatePath);
            int j = 0;
            for (int i = 0; i < TemplateArr.Length; i++)
            {
                string line = TemplateArr[i];
                StringBuilder MatchingString = new StringBuilder();
                if (line.Contains("#@Variable*#"))
                {
                    string TempStr = "";
                    string[] SubStr = line.Split('#');
                    for (int k = 0; k < SubStr.Length; k++)
                    {
                        if (SubStr[k].Contains("@Variable*"))
                        {
                            TempStr = SubStr[k].Replace("@Variable*", MatchArr[j]);
                            j++;
                        }
                        else
                        {
                            TempStr = SubStr[k];
                        }
                        MatchingString.Append(TempStr);
                    }
                    line = MatchingString.ToString();

                }
                sb.AppendLine(line);
            }

            SmtpClient serv = new SmtpClient();
            MailMessage msg = new MailMessage();
            msg.To.Add(To);
            msg.From = new MailAddress(ConfigurationManager.AppSettings["FromMailId"]);
            msg.Body = sb.ToString();
            msg.Subject = Subject;
            msg.BodyEncoding = System.Text.Encoding.ASCII;
            msg.IsBodyHtml = true;
#if DEBUG

            serv.DeliveryMethod = SmtpDeliveryMethod.SpecifiedPickupDirectory;
#else
            serv.DeliveryMethod = SmtpDeliveryMethod.SpecifiedPickupDirectory;
            //serv.DeliveryMethod = SmtpDeliveryMethod.Network;
            //serv.Host = ConfigurationManager.AppSettings["SmtpHost"];
            //serv.Port = ConfigurationManager.AppSettings["SmtpPort"];
            //serv.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["SmtpServerUserName"], ConfigurationManager.AppSettings["SmtpServerPassword"]);
#endif
            serv.Send(msg);

            return true;
        }

        /// <summary>
        /// Count the variables.
        /// </summary>
        /// <param name="data">data string.</param>
        /// <returns>Total count of variable.</returns>
        #region Count Number of Variable in a string
        private static int countTrue(string data)
        {
            string[] splitdata = data.Split('#');

            var results = from p in splitdata
                          where p.Contains("@Variable*")
                          select p;

            return results.Count();
        }

        #endregion
    }
}
